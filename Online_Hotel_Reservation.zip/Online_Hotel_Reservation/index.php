<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Luxury Beyond Ordinary</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 (icons) -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts - Playfair Display for luxury feel -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY CAROUSEL ===== */
			#myCarousel {
				margin-top: 0 !important;
				position: relative;
				box-shadow: 0 15px 40px rgba(0,0,0,0.2);
				border-bottom: 3px solid var(--eksa-gold);
			}
			
			.carousel-inner {
				border-radius: 0 !important;
				overflow: hidden;
			}
			
			.carousel-inner .item img {
				height: 600px !important;
				width: 100%;
				object-fit: cover !important;
				filter: brightness(0.8) contrast(1.1);
				transition: transform 8s ease;
			}
			
			.carousel-inner .item.active img {
				transform: scale(1.05);
			}
			
			/* Add overlay with hotel name on carousel */
			.carousel-inner::before {
				content: '';
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: linear-gradient(to right, rgba(10,28,47,0.7), rgba(10,28,47,0.3));
				z-index: 1;
				pointer-events: none;
			}
			
			/* Hotel Eksa watermark on carousel */
			.carousel-inner::after {
				content: 'HOTEL EKSA';
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				color: var(--eksa-gold);
				font-family: 'Playfair Display', serif;
				font-size: 5rem;
				font-weight: 900;
				text-shadow: 3px 3px 10px rgba(0,0,0,0.5);
				letter-spacing: 8px;
				z-index: 2;
				opacity: 0.9;
				white-space: nowrap;
				border: 3px solid var(--eksa-gold);
				padding: 20px 50px;
				border-radius: 10px;
				background: rgba(10,28,47,0.3);
				backdrop-filter: blur(5px);
				pointer-events: none;
				animation: fadeIn 1.5s ease-out;
			}
			
			/* Add tagline */
			.carousel-caption-custom {
				position: absolute;
				bottom: 50px;
				left: 0;
				right: 0;
				text-align: center;
				color: var(--eksa-white);
				z-index: 3;
				font-size: 1.2rem;
				letter-spacing: 5px;
				text-transform: uppercase;
				font-weight: 300;
			}
			
			/* Carousel indicators */
			.carousel-indicators {
				bottom: 30px;
				z-index: 10;
			}
			
			.carousel-indicators li {
				width: 12px !important;
				height: 12px !important;
				border-radius: 50% !important;
				background: var(--eksa-white) !important;
				border: 2px solid var(--eksa-gold) !important;
				margin: 0 8px !important;
				opacity: 0.7;
				transition: all 0.3s ease;
			}
			
			.carousel-indicators li.active {
				background: var(--eksa-gold) !important;
				border-color: var(--eksa-white) !important;
				transform: scale(1.3);
				opacity: 1;
			}
			
			/* Carousel controls */
			.carousel-control {
				background: linear-gradient(135deg, transparent, rgba(10,28,47,0.3)) !important;
				width: 8% !important;
				opacity: 0 !important;
				transition: all 0.3s ease !important;
				z-index: 5 !important;
			}
			
			#myCarousel:hover .carousel-control {
				opacity: 1 !important;
			}
			
			.carousel-control .glyphicon {
				color: var(--eksa-gold) !important;
				text-shadow: 2px 2px 5px rgba(0,0,0,0.5) !important;
				font-size: 30px !important;
			}
			
			/* ===== LUXURY WELCOME SECTION ===== */
			.welcome-section {
				text-align: center;
				padding: 60px 5%;
				background: linear-gradient(135deg, var(--eksa-white), var(--eksa-cream));
				position: relative;
			}
			
			.welcome-section h2 {
				font-size: 3rem;
				color: var(--eksa-navy);
				margin-bottom: 20px;
				position: relative;
				display: inline-block;
			}
			
			.welcome-section h2::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2.5rem;
			}
			
			.welcome-section h2::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2.5rem;
			}
			
			.welcome-section p {
				font-size: 1.2rem;
				color: var(--eksa-navy-light);
				max-width: 800px;
				margin: 0 auto;
				line-height: 1.8;
			}
			
			/* ===== LUXURY FEATURE CARDS ===== */
			.feature-container {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
				gap: 30px;
				padding: 50px 5%;
				background: var(--eksa-white);
			}
			
			.feature-card {
				background: var(--eksa-white);
				padding: 40px 30px;
				text-align: center;
				border-radius: 20px;
				box-shadow: 0 10px 30px var(--eksa-shadow);
				transition: all 0.4s ease;
				border: 1px solid transparent;
				position: relative;
				overflow: hidden;
			}
			
			.feature-card:hover {
				transform: translateY(-15px);
				border-color: var(--eksa-gold);
				box-shadow: 0 20px 50px var(--eksa-shadow-dark);
			}
			
			.feature-card::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(90deg, transparent, rgba(196,164,132,0.1), transparent);
				transition: left 0.6s ease;
			}
			
			.feature-card:hover::before {
				left: 100%;
			}
			
			.feature-card i {
				font-size: 3.5rem;
				color: var(--eksa-gold);
				margin-bottom: 20px;
			}
			
			.feature-card h3 {
				font-size: 1.5rem;
				color: var(--eksa-navy);
				margin-bottom: 15px;
			}
			
			.feature-card p {
				color: var(--eksa-navy-light);
				font-size: 0.95rem;
				line-height: 1.6;
			}
			
			/* ===== LUXURY ROOM PREVIEW ===== */
			.room-preview {
				padding: 60px 5%;
				background: linear-gradient(135deg, var(--eksa-cream), var(--eksa-white));
				text-align: center;
			}
			
			.room-preview h2 {
				font-size: 2.8rem;
				color: var(--eksa-navy);
				margin-bottom: 50px;
				position: relative;
			}
			
			.room-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
				gap: 30px;
				margin-top: 30px;
			}
			
			.room-item {
				background: var(--eksa-white);
				border-radius: 15px;
				overflow: hidden;
				box-shadow: 0 10px 25px var(--eksa-shadow);
				transition: all 0.4s ease;
			}
			
			.room-item:hover {
				transform: translateY(-10px);
				box-shadow: 0 20px 40px var(--eksa-shadow-dark);
			}
			
			.room-item img {
				width: 100%;
				height: 220px;
				object-fit: cover;
				transition: transform 0.6s ease;
			}
			
			.room-item:hover img {
				transform: scale(1.1);
			}
			
			.room-info {
				padding: 25px;
			}
			
			.room-info h3 {
				color: var(--eksa-navy);
				font-size: 1.4rem;
				margin-bottom: 10px;
			}
			
			.room-info .price {
				color: var(--eksa-gold-dark);
				font-size: 1.3rem;
				font-weight: 700;
				margin-bottom: 15px;
			}
			
			.room-info .btn-book {
				background: transparent;
				border: 2px solid var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 10px 25px;
				border-radius: 40px;
				font-weight: 600;
				transition: all 0.3s ease;
				display: inline-block;
				text-decoration: none;
			}
			
			.room-info .btn-book:hover {
				background: var(--eksa-gold);
				color: var(--eksa-navy-dark);
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== ANIMATIONS ===== */
			@keyframes fadeIn {
				from {
					opacity: 0;
					transform: translate(-50%, -40%);
				}
				to {
					opacity: 0.9;
					transform: translate(-50%, -50%);
				}
			}
			
			/* ===== RESPONSIVE DESIGN ===== */
			@media (max-width: 768px) {
				.carousel-inner::after {
					font-size: 2rem;
					padding: 15px 30px;
					letter-spacing: 4px;
					white-space: normal;
					width: 90%;
				}
				
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li {
					margin: 3px 0;
				}
				
				#menu li:not(:last-child)::after {
					content: "";
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.welcome-section h2 {
					font-size: 2rem;
				}
				
				.welcome-section h2::before,
				.welcome-section h2::after {
					font-size: 1.8rem;
				}
			}
			
			@media (max-width: 480px) {
				.carousel-inner::after {
					font-size: 1.2rem;
					padding: 10px 20px;
				}
				
				.feature-container {
					grid-template-columns: 1fr;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> Admin Login</a></li>
		<li><a href = "user_login.php"><i class="fas fa-book me-2"></i> User Login</a></li>
	</ul>
	
	<!-- LUXURY CAROUSEL -->
	<div id="myCarousel" class="carousel slide container-fluid" data-ride="carousel">
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
			<li data-target="#myCarousel" data-slide-to="3"></li>
			<li data-target="#myCarousel" data-slide-to="4"></li>
			<li data-target="#myCarousel" data-slide-to="5"></li>
			<li data-target="#myCarousel" data-slide-to="6"></li>
		</ol>
		
		<div style = "margin:auto;" class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="images/a.jpg" style = "width:100%; height:450px;" />
			</div>
			<div class="item">
				<img src="images/b.jpg" style = "width:100%; height:450px;"  />
			</div>
			<div class="item">
				<img src="images/c.jpg" style = "width:100%; height:450px;" />
			</div>
			<div class="item">
				<img src="images/d.jpg" style = "width:100%; height:450px;" />
			</div>
			<div class="item">
				<img src="images/e.jpg" style = "width:100%; height:450px;" />
			</div>
			<div class="item">
				<img src="images/f.jpeg" style = "width:100%; height:450px;" />
			</div>
			<div class="item">
				<img src="images/g.png" style = "width:100%; height:450px;" />
			</div>
		</div>
		
		<div class="carousel-caption-custom">
			<span>LUXURY • ELEGANCE • COMFORT</span>
		</div>
		
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
	</div>
	
	<!-- WELCOME SECTION -->
	<div class="welcome-section">
		<h2>Welcome to Hotel Eksa</h2>
		<p>Experience unparalleled luxury and comfort in the heart of the city. Where every moment becomes a cherished memory.</p>
	</div>
	
	<!-- FEATURE CARDS -->
	<div class="feature-container">
		<div class="feature-card">
			<i class="fas fa-wifi"></i>
			<h3>Free Premium WiFi</h3>
			<p>High-speed internet access throughout the hotel, complimentary for all guests</p>
		</div>
		<div class="feature-card">
			<i class="fas fa-utensils"></i>
			<h3>Fine Dining</h3>
			<p>Exquisite cuisine prepared by award-winning chefs in our elegant restaurant</p>
		</div>
		<div class="feature-card">
			<i class="fas fa-spa"></i>
			<h3>Luxury Spa</h3>
			<p>Rejuvenate your senses with our signature treatments and wellness programs</p>
		</div>
		<div class="feature-card">
			<i class="fas fa-concierge-bell"></i>
			<h3>24/7 Concierge</h3>
			<p>Round-the-clock service to cater to your every need and desire</p>
		</div>
	</div>
	
	<!-- ROOM PREVIEW -->
	<div class="room-preview">
		<h2>≼ Our Signature Rooms ≽</h2>
		<div class="room-grid">
			<div class="room-item">
				<img src="images/a.jpg" alt="Executive Suite">
				<div class="room-info">
					<h3>Executive Suite</h3>
					<div class="price">$400/night</div>
					<a href="reservation.php" class="btn-book">
						<i class="fas fa-calendar-check me-2"></i> Book Now
					</a>
				</div>
			</div>
			<div class="room-item">
				<img src="images/b.jpg" alt="Deluxe Room">
				<div class="room-info">
					<h3>Deluxe Room</h3>
					<div class="price">$280/night</div>
					<a href="reservation.php" class="btn-book">
						<i class="fas fa-calendar-check me-2"></i> Book Now
					</a>
				</div>
			</div>
			<div class="room-item">
				<img src="images/c.jpg" alt="Standard Room">
				<div class="room-info">
					<h3>Standard Room</h3>
					<div class="price">$200/night</div>
					<a href="reservation.php" class="btn-book">
						<i class="fas fa-calendar-check me-2"></i> Book Now
					</a>
				</div>
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Created by Pujan Pathak <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script>
	// Add active class to current menu item
	document.addEventListener('DOMContentLoaded', function() {
		var currentPage = window.location.pathname.split('/').pop();
		var menuItems = document.querySelectorAll('#menu li a');
		
		menuItems.forEach(function(item) {
			if (item.getAttribute('href') === currentPage) {
				item.style.background = 'var(--eksa-gold)';
				item.style.color = 'var(--eksa-navy)';
			}
		});
	});
</script>
</html>