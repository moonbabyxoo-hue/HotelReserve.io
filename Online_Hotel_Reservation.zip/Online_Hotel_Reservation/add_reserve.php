<?php
// ==================== START SESSION AT THE VERY TOP ====================
// NO WHITESPACE, NO HTML, NO OUTPUT BEFORE THIS
session_start();

// Get room_id from URL
$room_id = isset($_GET['room_id']) ? $_GET['room_id'] : 0;

// Get room details from database
require_once 'admin/connect.php';
$query = $conn->query("SELECT * FROM `room` WHERE `room_id` = '$room_id'") or die(mysqli_error($conn));
$fetch = $query->fetch_array();
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Complete Your Reservation</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Bootstrap -->
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
				--eksa-danger: #dc3545;
				--eksa-success: #28a745;
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				padding-bottom: 100px;
			}
			
			.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 40px !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				font-weight: 700;
				font-family: 'Playfair Display', serif;
			}
			
			.navbar-brand i {
				color: var(--eksa-gold);
				margin-right: 10px;
			}
			
			.container {
				max-width: 900px;
				margin: 0 auto;
				padding: 0 20px;
			}
			
			.reservation-card {
				background: var(--eksa-white);
				border-radius: 30px;
				padding: 40px;
				box-shadow: 0 30px 60px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.room-summary {
				display: flex;
				gap: 30px;
				margin-bottom: 40px;
				padding: 25px;
				background: rgba(196, 164, 132, 0.05);
				border-radius: 20px;
			}
			
			.room-image {
				width: 200px;
				height: 200px;
				border-radius: 15px;
				overflow: hidden;
				border: 3px solid var(--eksa-gold);
			}
			
			.room-image img {
				width: 100%;
				height: 100%;
				object-fit: cover;
			}
			
			.room-info h3 {
				color: var(--eksa-navy);
				font-size: 1.8rem;
				margin-bottom: 15px;
			}
			
			.price {
				color: var(--eksa-gold-dark);
				font-size: 2rem;
				font-weight: 800;
			}
			
			/* ===== FORM VALIDATION STYLES ===== */
			.form-section {
				margin-bottom: 30px;
			}
			
			.form-section h4 {
				color: var(--eksa-navy);
				margin-bottom: 25px;
				display: flex;
				align-items: center;
				gap: 10px;
			}
			
			.form-section h4 i {
				color: var(--eksa-gold);
			}
			
			.form-row {
				display: grid;
				grid-template-columns: 1fr 1fr;
				gap: 20px;
				margin-bottom: 20px;
			}
			
			.form-group {
				margin-bottom: 20px;
				position: relative;
			}
			
			.form-group label {
				display: block;
				margin-bottom: 8px;
				font-weight: 600;
				color: var(--eksa-navy);
			}
			
			.form-group label i {
				color: var(--eksa-gold);
				margin-right: 8px;
			}
			
			.form-group label .required {
				color: var(--eksa-danger);
				margin-left: 3px;
			}
			
			.form-control {
				width: 100%;
				padding: 12px 18px;
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 15px;
				font-size: 1rem;
				transition: all 0.3s ease;
			}
			
			.form-control:focus {
				outline: none;
				border-color: var(--eksa-gold);
				box-shadow: 0 0 0 5px var(--eksa-gold-glow);
			}
			
			.form-control.is-invalid {
				border-color: var(--eksa-danger);
				background: rgba(220, 53, 69, 0.05);
			}
			
			.form-control.is-valid {
				border-color: var(--eksa-success);
				background: rgba(40, 167, 69, 0.05);
			}
			
			.invalid-feedback {
				color: var(--eksa-danger);
				font-size: 0.85rem;
				margin-top: 5px;
				display: none;
			}
			
			.invalid-feedback.show {
				display: block;
			}
			
			.valid-feedback {
				color: var(--eksa-success);
				font-size: 0.85rem;
				margin-top: 5px;
				display: none;
			}
			
			.valid-feedback.show {
				display: block;
			}
			
			.validation-icon {
				position: absolute;
				right: 15px;
				top: 45px;
				font-size: 1.1rem;
				display: none;
			}
			
			.validation-icon.show {
				display: block;
			}
			
			.validation-icon.valid {
				color: var(--eksa-success);
			}
			
			.validation-icon.invalid {
				color: var(--eksa-danger);
			}
			
			.btn-submit {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border: 2px solid var(--eksa-white);
				padding: 16px 40px;
				border-radius: 50px;
				font-size: 1.1rem;
				font-weight: 700;
				width: 100%;
				transition: all 0.4s ease;
				position: relative;
				overflow: hidden;
			}
			
			.btn-submit:hover {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				color: var(--eksa-gold);
				border-color: var(--eksa-gold);
				transform: translateY(-3px);
			}
			
			.btn-submit:disabled {
				opacity: 0.6;
				cursor: not-allowed;
				transform: none;
			}
			
			/* ===== PASSWORD REQUIREMENTS ===== */
			.contact-requirements {
				margin-top: 8px;
				padding: 10px;
				background: rgba(196, 164, 132, 0.05);
				border-radius: 10px;
				font-size: 0.8rem;
				display: none;
			}
			
			.contact-requirements.show {
				display: block;
			}
			
			.requirement-item {
				display: flex;
				align-items: center;
				gap: 8px;
				margin-bottom: 5px;
				color: var(--eksa-navy-light);
			}
			
			.requirement-item i {
				font-size: 0.75rem;
			}
			
			.requirement-item.valid {
				color: var(--eksa-success);
			}
			
			.requirement-item.invalid {
				color: var(--eksa-danger);
			}
			
			@media (max-width: 768px) {
				.room-summary { flex-direction: column; }
				.room-image { width: 100%; height: 250px; }
				.form-row { grid-template-columns: 1fr; }
			}
		</style>
	</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark">
		<div class="container">
			<a class="navbar-brand" href="index.php">
				<i class="fas fa-h-square"></i> Hotel Eksa
			</a>
		</div>
	</nav>
	
	<div class="container">
		<div class="reservation-card">
			<h2 style="color: var(--eksa-navy); text-align: center; margin-bottom: 40px; font-family: 'Playfair Display', serif;">
				≼ Complete Your Reservation ≽
			</h2>
			
			<!-- Room Summary -->
			<div class="room-summary">
				<div class="room-image">
					<img src="photo/<?php echo $fetch['photo']; ?>" alt="<?php echo $fetch['room_type']; ?>">
				</div>
				<div class="room-info">
					<h3><?php echo $fetch['room_type']; ?></h3>
					<div style="display: flex; gap: 15px; margin-bottom: 15px;">
						<span style="background: rgba(196,164,132,0.1); padding: 5px 15px; border-radius: 50px;">
							<i class="fas fa-wifi"></i> Free WiFi
						</span>
						<span style="background: rgba(196,164,132,0.1); padding: 5px 15px; border-radius: 50px;">
							<i class="fas fa-snowflake"></i> AC
						</span>
					</div>
					<div class="price">Rs. <?php echo number_format($fetch['price'], 2); ?> <span style="font-size: 1rem; color: var(--eksa-navy-light);">/ night</span></div>
				</div>
			</div>
			
			<!-- Reservation Form with Validation -->
			<form method="POST" action="add_query_reserve.php" id="reservationForm" novalidate>
				<input type="hidden" name="room_id" value="<?php echo $room_id; ?>">
				
				<div class="form-section">
					<h4><i class="fas fa-user-circle"></i> Guest Information</h4>
					
					<div class="form-row">
						<!-- First Name -->
						<div class="form-group">
							<label>
								<i class="fas fa-user"></i> First Name 
								<span class="required">*</span>
							</label>
							<input type="text" class="form-control" name="firstname" id="firstname" 
								   placeholder="Enter first name" required 
								   minlength="2" maxlength="50"
								   pattern="[A-Za-z\s]+" 
								   title="First name should contain only letters and spaces">
							<span class="validation-icon" id="firstname-icon"></span>
							<div class="invalid-feedback" id="firstname-error"></div>
						</div>
						
						<!-- Middle Name -->
						<div class="form-group">
							<label><i class="fas fa-user"></i> Middle Name</label>
							<input type="text" class="form-control" name="middlename" id="middlename" 
								   placeholder="Enter middle name (optional)"
								   pattern="[A-Za-z\s]*"
								   title="Middle name should contain only letters">
							<span class="validation-icon" id="middlename-icon"></span>
							<div class="invalid-feedback" id="middlename-error"></div>
						</div>
					</div>
					
					<div class="form-row">
						<!-- Last Name -->
						<div class="form-group">
							<label>
								<i class="fas fa-user"></i> Last Name 
								<span class="required">*</span>
							</label>
							<input type="text" class="form-control" name="lastname" id="lastname" 
								   placeholder="Enter last name" required
								   minlength="2" maxlength="50"
								   pattern="[A-Za-z\s]+"
								   title="Last name should contain only letters and spaces">
							<span class="validation-icon" id="lastname-icon"></span>
							<div class="invalid-feedback" id="lastname-error"></div>
						</div>
						
						<!-- Address -->
						<div class="form-group">
							<label>
								<i class="fas fa-map-marker-alt"></i> Address 
								<span class="required">*</span>
							</label>
							<input type="text" class="form-control" name="address" id="address" 
								   placeholder="Enter complete address" required
								   minlength="5" maxlength="100">
							<span class="validation-icon" id="address-icon"></span>
							<div class="invalid-feedback" id="address-error"></div>
						</div>
					</div>
					
					<div class="form-row">
						<!-- Contact Number -->
						<div class="form-group">
							<label>
								<i class="fas fa-phone-alt"></i> Contact Number 
								<span class="required">*</span>
							</label>
							<input type="text" class="form-control" name="contactno" id="contactno" 
								   placeholder="e.g. 09123456789 or +639123456789" required
								   minlength="10" maxlength="15"
								   pattern="[0-9+\-\s]+"
								   title="Enter a valid phone number">
							<span class="validation-icon" id="contactno-icon"></span>
							<div class="invalid-feedback" id="contactno-error"></div>
							
							<!-- Contact Number Requirements -->
							<div class="contact-requirements" id="contact-requirements">
								<div class="requirement-item" id="req-length">
									<i class="fas fa-circle"></i> At least 10 digits
								</div>
								<div class="requirement-item" id="req-format">
									<i class="fas fa-circle"></i> Valid format (numbers, +, -, space)
								</div>
							</div>
						</div>
						
						<!-- Check-in Date -->
						<div class="form-group">
							<label>
								<i class="fas fa-calendar-alt"></i> Check-in Date 
								<span class="required">*</span>
							</label>
							<input type="date" class="form-control" name="date" id="checkin_date" 
								   min="<?php echo date('Y-m-d'); ?>" 
								   max="<?php echo date('Y-m-d', strtotime('+1 year')); ?>" 
								   required>
							<span class="validation-icon" id="date-icon"></span>
							<div class="invalid-feedback" id="date-error"></div>
							<small style="color: var(--eksa-navy-light);">Select your check-in date</small>
						</div>
					</div>
				</div>
				
				<!-- Terms and Conditions -->
				<div style="margin: 30px 0; padding: 20px; background: rgba(196,164,132,0.03); border-radius: 15px; border: 1px dashed var(--eksa-gold);">
					<div style="display: flex; align-items: center; gap: 15px;">
						<input type="checkbox" id="terms" required style="width: 20px; height: 20px; accent-color: var(--eksa-gold);">
						<label for="terms" style="color: var(--eksa-navy); font-weight: 500;">
							I agree to the <a href="#" style="color: var(--eksa-gold);">terms and conditions</a> and confirm that the information provided is correct.
							<span class="required">*</span>
						</label>
					</div>
					<div class="invalid-feedback" id="terms-error" style="margin-left: 35px;"></div>
				</div>
				
				<button type="submit" name="add_guest" class="btn-submit" id="submitBtn">
					<i class="fas fa-check-circle"></i> Confirm Reservation
					<i class="fas fa-arrow-right"></i>
				</button>
			</form>
		</div>
	</div>
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	
	<script>
		// ==================== FORM VALIDATION ====================
		document.addEventListener('DOMContentLoaded', function() {
			const form = document.getElementById('reservationForm');
			const submitBtn = document.getElementById('submitBtn');
			
			// Validation functions
			const validators = {
				// Name validation (letters and spaces only)
				name: function(value) {
					return /^[A-Za-z]{2,50}$/.test(value.trim());
				},
				
				// Optional name validation
				optionalName: function(value) {
					if (value.trim() === '') return true;
					return /^[A-Za-z]{0,50}$/.test(value.trim());
				},
				
				// Address validation
				address: function(value) {
					return value.trim().length >= 5 && value.trim().length <= 100;
				},
				
				// Contact number validation
				contact: function(value) {
					// Remove all non-digit characters
					const digits = value.replace(/\D/g, '');
					return digits.length >= 10 && digits.length <= 15;
				},
				
				// Date validation
				date: function(value) {
					if (!value) return false;
					const selectedDate = new Date(value);
					const today = new Date();
					today.setHours(0, 0, 0, 0);
					return selectedDate >= today;
				}
			};
			
			// Real-time validation for each field
			const fields = [
				{ id: 'firstname', validator: 'name', errorMsg: 'Please enter a valid first name (minimum 2 characters, letters only)' },
				{ id: 'middlename', validator: 'optionalName', errorMsg: 'Middle name can only contain letters', optional: true },
				{ id: 'lastname', validator: 'name', errorMsg: 'Please enter a valid last name (minimum 2 characters, letters only)' },
				{ id: 'address', validator: 'address', errorMsg: 'Please enter a valid address (minimum 5 characters)' },
				{ id: 'contactno', validator: 'contact', errorMsg: 'Please enter a valid contact number (10-15 digits)' },
				{ id: 'checkin_date', validator: 'date', errorMsg: 'Please select a valid future date' }
			];
			
			// Add validation listeners
			fields.forEach(field => {
				const input = document.getElementById(field.id);
				if (!input) return;
				
				input.addEventListener('input', function() {
					validateField(field);
				});
				
				input.addEventListener('blur', function() {
					validateField(field);
				});
			});
			
			// Contact number special validation with requirements
			const contactInput = document.getElementById('contactno');
			const contactRequirements = document.getElementById('contact-requirements');
			
			if (contactInput) {
				contactInput.addEventListener('focus', function() {
					contactRequirements.classList.add('show');
				});
				
				contactInput.addEventListener('blur', function() {
					if (!this.value.trim()) {
						contactRequirements.classList.remove('show');
					}
				});
				
				contactInput.addEventListener('input', function() {
					const value = this.value;
					const digits = value.replace(/\D/g, '');
					
					// Check length requirement
					const lengthReq = document.getElementById('req-length');
					if (digits.length >= 10) {
						lengthReq.innerHTML = '<i class="fas fa-check-circle"></i> At least 10 digits';
						lengthReq.classList.add('valid');
						lengthReq.classList.remove('invalid');
					} else {
						lengthReq.innerHTML = '<i class="fas fa-circle"></i> At least 10 digits';
						lengthReq.classList.remove('valid');
						lengthReq.classList.add('invalid');
					}
					
					// Check format requirement
					const formatReq = document.getElementById('req-format');
					if (/^[0-9+\-\s]+$/.test(value) || value === '') {
						formatReq.innerHTML = '<i class="fas fa-check-circle"></i> Valid format (numbers, +, -, space)';
						formatReq.classList.add('valid');
						formatReq.classList.remove('invalid');
					} else {
						formatReq.innerHTML = '<i class="fas fa-circle"></i> Valid format (numbers, +, -, space)';
						formatReq.classList.remove('valid');
						formatReq.classList.add('invalid');
					}
					
					validateField(fields[4]); // contact field
				});
			}
			
			// Validate individual field
			function validateField(field) {
				const input = document.getElementById(field.id);
				if (!input) return true;
				
				const value = input.value;
				const isValid = field.optional && !value.trim() ? true : validators[field.validator](value);
				
				// Update input styling
				if (isValid) {
					input.classList.remove('is-invalid');
					input.classList.add('is-valid');
				} else {
					input.classList.remove('is-valid');
					input.classList.add('is-invalid');
				}
				
				// Update icon
				const icon = document.getElementById(field.id + '-icon');
				if (icon) {
					icon.className = 'validation-icon show ' + (isValid ? 'valid' : 'invalid');
					icon.innerHTML = isValid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
				}
				
				// Update error message
				const error = document.getElementById(field.id + '-error');
				if (error) {
					error.textContent = isValid ? '' : field.errorMsg;
					error.classList.toggle('show', !isValid);
				}
				
				return isValid;
			}
			
			// Form submission validation
			form.addEventListener('submit', function(e) {
				let isValid = true;
				
				// Validate all required fields
				fields.forEach(field => {
					if (!validateField(field)) {
						isValid = false;
					}
				});
				
				// Validate terms checkbox
				const terms = document.getElementById('terms');
				const termsError = document.getElementById('terms-error');
				
				if (!terms.checked) {
					termsError.textContent = 'You must agree to the terms and conditions';
					termsError.classList.add('show');
					isValid = false;
				} else {
					termsError.classList.remove('show');
				}
				
				if (!isValid) {
					e.preventDefault();
					
					// Scroll to first error
					const firstError = document.querySelector('.is-invalid');
					if (firstError) {
						firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
					}
					
					// Show error message
					swal({
						title: 'Validation Error',
						text: 'Please fill in all fields correctly and agree to the terms.',
						icon: 'error',
						button: 'OK'
					});
					
					return false;
				}
				
				// Show success message before submit
				e.preventDefault();
				swal({
					title: 'Confirm Reservation?',
					text: 'Please verify your information before submitting.',
					icon: 'info',
					buttons: ['Cancel', 'Confirm'],
					dangerMode: false,
				}).then((willConfirm) => {
					if (willConfirm) {
						form.submit();
					}
				});
			});
			
			// Initial validation to set states
			fields.forEach(field => {
				validateField(field);
			});
		});
	</script>
</body>
</html>