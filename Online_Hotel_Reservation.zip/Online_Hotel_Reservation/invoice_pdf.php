<?php
// ==================== NO CSS, NO BOOTSTRAP, JUST PLAIN HTML ====================
require_once 'admin/connect.php';

$reservation_id = isset($_GET['reservation_id']) ? $_GET['reservation_id'] : 0;

if ($reservation_id == 0) {
    die("Invalid reservation");
}

$query = $conn->query("SELECT * FROM reservations WHERE id = '$reservation_id'");
if (!$query || $query->num_rows == 0) {
    die("Reservation not found");
}

$r = $query->fetch_array();

// Get room photo
$room_photo = '1.jpg';
$photo_query = $conn->query("SELECT photo FROM room WHERE room_id = '{$r['room_id']}'");
if ($photo_query && $photo_query->num_rows > 0) {
    $photo_row = $photo_query->fetch_array();
    $room_photo = $photo_row['photo'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hotel Eksa Invoice</title>
    <style>
        /* MINIMAL CSS - GUARANTEED TO WORK WITH PDF */
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #C4A484;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #0A1C2F;
            font-size: 32px;
            margin: 0;
        }
        .header h2 {
            color: #A67B5B;
            font-size: 24px;
            margin: 10px 0 0;
        }
        .success {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            display: inline-block;
            border-radius: 50px;
            font-weight: bold;
            margin: 20px 0;
        }
        .section {
            margin-bottom: 30px;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;
        }
        .section-title {
            color: #A67B5B;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            border-bottom: 1px solid #C4A484;
            padding-bottom: 10px;
        }
        .row {
            margin-bottom: 10px;
            display: flex;
        }
        .label {
            font-weight: bold;
            width: 150px;
            color: #0A1C2F;
        }
        .value {
            flex: 1;
        }
        .code-box {
            background: #f5f5f5;
            border: 2px dashed #C4A484;
            padding: 20px;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            letter-spacing: 5px;
            margin: 20px 0;
            color: #0A1C2F;
        }
        .room-box {
            display: flex;
            gap: 20px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 10px;
        }
        .room-image {
            width: 100px;
            height: 100px;
            border: 2px solid #C4A484;
            border-radius: 10px;
            overflow: hidden;
        }
        .room-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .room-details h3 {
            margin: 0 0 10px 0;
            color: #0A1C2F;
            font-size: 22px;
        }
        .room-details p {
            margin: 0;
            font-size: 18px;
            font-weight: bold;
            color: #A67B5B;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th {
            background: #f0f0f0;
            padding: 12px;
            text-align: left;
            border-bottom: 2px solid #C4A484;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        .total {
            font-size: 20px;
            font-weight: bold;
            color: #A67B5B;
            text-align: right;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #C4A484;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
        }
        .signature {
            font-size: 18px;
            color: #A67B5B;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <div class="header">
        <h1>HOTEL EKSA</h1>
        <div style="margin: 20px 0;">
            <span class="success">✓ <?php echo $r['status']; ?></span>
        </div>
        <h2>BOOKING INVOICE</h2>
    </div>

    <!-- HOTEL & INVOICE INFO -->
    <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
        <div>
            <strong style="color: #A67B5B;">HOTEL ADDRESS</strong><br>
            Khairahani-06, Parsa<br>
            Chitwan, Nepal<br>
            Tel: +977 9800000000<br>
            Email: reservations@hoteleksa.com
        </div>
        <div style="text-align: right;">
            <strong style="color: #A67B5B;">INVOICE DETAILS</strong><br>
            Invoice No: <?php echo $r['invoice_number']; ?><br>
            Date: <?php echo date('F d, Y', strtotime($r['booking_date'])); ?><br>
            Status: <span style="color: #28a745; font-weight: bold;"><?php echo $r['status']; ?></span>
        </div>
    </div>

    <!-- RESERVATION CODE -->
    <div class="code-box">
        <?php echo $r['reservation_code']; ?>
    </div>

    <!-- GUEST INFORMATION -->
    <div class="section">
        <div class="section-title">GUEST INFORMATION</div>
        <div class="row">
            <span class="label">Full Name:</span>
            <span class="value"><?php echo $r['fullname']; ?></span>
        </div>
        <div class="row">
            <span class="label">Address:</span>
            <span class="value"><?php echo $r['address']; ?></span>
        </div>
        <div class="row">
            <span class="label">Contact No:</span>
            <span class="value"><?php echo $r['contactno']; ?></span>
        </div>
        <div class="row">
            <span class="label">Check-in Date:</span>
            <span class="value"><?php echo date('F d, Y', strtotime($r['checkin_date'])); ?></span>
        </div>
    </div>

    <!-- ROOM INFORMATION -->
    <div class="section">
        <div class="section-title">ROOM DETAILS</div>
        <div class="room-box">
            <div class="room-image">
                <img src="photo/<?php echo $room_photo; ?>" alt="Room">
            </div>
            <div class="room-details">
                <h3><?php echo $r['room_type']; ?></h3>
                <p>Rs. <?php echo number_format($r['room_price'], 2); ?> / night</p>
            </div>
        </div>
    </div>

    <!-- CHARGES TABLE -->
    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Rate</th>
                <th>Nights</th>
                <th align="right">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $r['room_type']; ?> - Standard Rate</td>
                <td>Rs. <?php echo number_format($r['room_price'], 2); ?></td>
                <td><?php echo $r['nights']; ?></td>
                <td align="right">Rs. <?php echo number_format($r['subtotal'], 2); ?></td>
            </tr>
            <tr>
                <td>Service Charge (10%)</td>
                <td>-</td>
                <td>-</td>
                <td align="right">Rs. <?php echo number_format($r['service_charge'], 2); ?></td>
            </tr>
            <tr>
                <td>Tax (12%)</td>
                <td>-</td>
                <td>-</td>
                <td align="right">Rs. <?php echo number_format($r['tax'], 2); ?></td>
            </tr>
            <tr style="font-weight: bold; background: #f9f9f9;">
                <td colspan="3" align="right">TOTAL AMOUNT:</td>
                <td align="right" style="color: #A67B5B; font-size: 18px;">Rs. <?php echo number_format($r['total'], 2); ?></td>
            </tr>
        </tbody>
    </table>

    <!-- SUMMARY -->
    <div style="margin: 30px 0; padding: 20px; background: #f9f9f9; border-radius: 10px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span>Subtotal:</span>
            <span>Rs. <?php echo number_format($r['subtotal'], 2); ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span>Service Charge (10%):</span>
            <span>Rs. <?php echo number_format($r['service_charge'], 2); ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span>Tax (12%):</span>
            <span>Rs. <?php echo number_format($r['tax'], 2); ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 20px; font-weight: bold; color: #0A1C2F; margin-top: 15px; padding-top: 15px; border-top: 2px solid #C4A484;">
            <span>TOTAL AMOUNT:</span>
            <span style="color: #A67B5B;">Rs. <?php echo number_format($r['total'], 2); ?></span>
        </div>
    </div>

    <!-- FOOTER -->
    <div class="footer">
        <p style="margin: 5px 0;">✓ This is a confirmed reservation. Please present this invoice upon check-in.</p>
        <p style="margin: 5px 0;">Check-in: 3:00 PM | Check-out: 12:00 PM</p>
        <p style="margin: 5px 0;">Payment will be collected at the hotel.</p>
        <div class="signature">
            Hotel Eksa Management
        </div>
        <p style="margin-top: 30px; color: #999; font-size: 11px;">
            Invoice generated on <?php echo date('F d, Y h:i A'); ?>
        </p>
    </div>

    <script>
        // Auto-print when page loads
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>