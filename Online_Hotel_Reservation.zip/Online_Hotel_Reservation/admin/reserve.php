


<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Reservation Management</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<!-- DataTables -->
		<link rel = "stylesheet" type = "text/css" href = "../css/dataTables.bootstrap.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - RESERVATION MANAGEMENT ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
				--eksa-danger: #dc3545;
				--eksa-success: #28a745;
				--eksa-warning: #ffc107;
				--eksa-info: #17a2b8;
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 80px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 30px !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY DROPDOWN MENU ===== */
			.dropdown-menu {
				background: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				border-radius: 15px;
				box-shadow: 0 15px 40px var(--eksa-shadow-dark);
				padding: 10px;
			}
			
			.dropdown-menu li a {
				color: var(--eksa-navy);
				padding: 10px 20px;
				border-radius: 10px;
				transition: all 0.3s ease;
			}
			
			.dropdown-menu li a:hover {
				background: rgba(196, 164, 132, 0.1);
				color: var(--eksa-gold-dark);
			}
			
			.dropdown-menu li a i {
				color: var(--eksa-gold);
				margin-right: 10px;
			}
			
			/* ===== LUXURY NAV PILLS ===== */
			.nav-pills {
				margin: 20px 0;
				display: flex;
				flex-wrap: wrap;
				gap: 10px;
			}
			
			.nav-pills li {
				margin: 0;
			}
			
			.nav-pills li a {
				background: var(--eksa-white);
				color: var(--eksa-navy);
				padding: 12px 25px;
				border-radius: 50px;
				font-weight: 600;
				transition: all 0.3s ease;
				border: 2px solid rgba(196, 164, 132, 0.2);
				text-decoration: none;
				display: inline-block;
			}
			
			.nav-pills li a:hover {
				background: rgba(196, 164, 132, 0.1);
				border-color: var(--eksa-gold);
				transform: translateY(-2px);
			}
			
			.nav-pills li.active a {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border-color: var(--eksa-white);
			}
			
			/* ===== LUXURY PANEL ===== */
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white);
				border-radius: 30px;
				padding: 40px;
				box-shadow: 0 30px 60px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			/* ===== PAGE HEADER ===== */
			.page-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 30px;
				flex-wrap: wrap;
				gap: 20px;
			}
			
			.page-title {
				display: flex;
				align-items: center;
				gap: 15px;
			}
			
			.page-title i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
				background: rgba(196, 164, 132, 0.1);
				padding: 15px;
				border-radius: 20px;
			}
			
			.page-title h2 {
				color: var(--eksa-navy);
				font-size: 2.2rem;
				margin: 0;
			}
			
			.page-title p {
				color: var(--eksa-navy-light);
				margin: 5px 0 0;
				font-size: 0.95rem;
			}
			
			/* ===== STATS CARDS ===== */
			.stats-container {
				display: flex;
				gap: 20px;
				margin-bottom: 30px;
				flex-wrap: wrap;
			}
			
			.stat-card {
				display: flex;
				align-items: center;
				gap: 15px;
				padding: 20px 30px;
				border-radius: 20px;
				background: var(--eksa-white);
				box-shadow: 0 10px 30px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				transition: all 0.3s ease;
			}
			
			.stat-card:hover {
				transform: translateY(-5px);
				border-color: var(--eksa-gold);
				box-shadow: 0 15px 40px var(--eksa-gold-glow);
			}
			
			.stat-icon {
				width: 60px;
				height: 60px;
				border-radius: 15px;
				display: flex;
				align-items: center;
				justify-content: center;
				font-size: 1.8rem;
			}
			
			.stat-icon.pending {
				background: rgba(255, 193, 7, 0.1);
				color: var(--eksa-warning);
			}
			
			.stat-icon.checkin {
				background: rgba(23, 162, 184, 0.1);
				color: var(--eksa-info);
			}
			
			.stat-content h4 {
				font-size: 1.8rem;
				font-weight: 800;
				margin: 0;
				line-height: 1.2;
			}
			
			.stat-content p {
				margin: 0;
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
			}
			
			/* ===== ACTION BUTTONS ===== */
			.action-buttons {
				display: flex;
				gap: 15px;
				margin-bottom: 30px;
				flex-wrap: wrap;
			}
			
			.btn-checkout {
				background: linear-gradient(135deg, var(--eksa-warning), #e0a800);
				color: var(--eksa-navy-dark);
				border: none;
				padding: 12px 30px;
				border-radius: 50px;
				font-weight: 700;
				display: inline-flex;
				align-items: center;
				gap: 10px;
				transition: all 0.3s ease;
				text-decoration: none;
			}
			
			.btn-checkout:hover {
				transform: translateY(-3px);
				box-shadow: 0 10px 25px rgba(255, 193, 7, 0.3);
				color: var(--eksa-navy-dark);
				text-decoration: none;
			}
			
			/* ===== TABLE STYLES ===== */
			.table-container {
				margin-top: 30px;
				overflow-x: auto;
			}
			
			.table {
				width: 100%;
				border-collapse: collapse;
			}
			
			.table thead {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
			}
			
			.table thead th {
				padding: 18px 15px;
				color: var(--eksa-gold-light);
				font-weight: 600;
				text-transform: uppercase;
				letter-spacing: 1px;
				border: none;
			}
			
			.table tbody tr {
				transition: all 0.3s ease;
				border-bottom: 1px solid rgba(196, 164, 132, 0.1);
			}
			
			.table tbody tr:hover {
				background: rgba(196, 164, 132, 0.05);
			}
			
			.table tbody td {
				padding: 18px 15px;
				vertical-align: middle;
				color: var(--eksa-navy-light);
				border: none;
			}
			
			/* ===== STATUS BADGES ===== */
			.status-badge {
				display: inline-block;
				padding: 6px 18px;
				border-radius: 50px;
				font-size: 0.85rem;
				font-weight: 600;
				text-align: center;
			}
			
			.status-pending {
				background: rgba(255, 193, 7, 0.1);
				color: #856404;
				border: 1px solid #ffc107;
			}
			
			.status-checkin {
				background: rgba(23, 162, 184, 0.1);
				color: #0c5460;
				border: 1px solid #17a2b8;
			}
			
			.status-checkout {
				background: rgba(108, 117, 125, 0.1);
				color: #383d41;
				border: 1px solid #6c757d;
			}
			
			/* ===== DATE BADGES ===== */
			.date-badge {
				display: inline-block;
				padding: 8px 16px;
				border-radius: 50px;
				font-weight: 600;
			}
			
			.date-overdue {
				background: rgba(220, 53, 69, 0.1);
				color: #dc3545;
				border: 1px solid #dc3545;
			}
			
			.date-upcoming {
				background: rgba(40, 167, 69, 0.1);
				color: #28a745;
				border: 1px solid #28a745;
			}
			
			/* ===== ACTION BUTTONS ===== */
			.btn-checkin {
				background: linear-gradient(135deg, var(--eksa-success), #218838);
				color: white;
				border: none;
				padding: 8px 20px;
				border-radius: 50px;
				font-weight: 600;
				display: inline-flex;
				align-items: center;
				gap: 8px;
				transition: all 0.3s ease;
				text-decoration: none;
				margin-right: 8px;
			}
			
			.btn-checkin:hover {
				background: #218838;
				transform: translateY(-2px);
				box-shadow: 0 8px 20px rgba(40, 167, 69, 0.3);
				color: white;
				text-decoration: none;
			}
			
			.btn-discard {
				background: linear-gradient(135deg, var(--eksa-danger), #c82333);
				color: white;
				border: none;
				padding: 8px 20px;
				border-radius: 50px;
				font-weight: 600;
				display: inline-flex;
				align-items: center;
				gap: 8px;
				transition: all 0.3s ease;
				text-decoration: none;
			}
			
			.btn-discard:hover {
				background: #c82333;
				transform: translateY(-2px);
				box-shadow: 0 8px 20px rgba(220, 53, 69, 0.3);
				color: white;
				text-decoration: none;
			}
			
			/* ===== DATA TABLE CUSTOMIZATION ===== */
			.dataTables_wrapper .dataTables_length,
			.dataTables_wrapper .dataTables_filter,
			.dataTables_wrapper .dataTables_info,
			.dataTables_wrapper .dataTables_paginate {
				margin-bottom: 20px;
				color: var(--eksa-navy-light);
			}
			
			.dataTables_wrapper .dataTables_filter input {
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 50px;
				padding: 10px 20px;
				margin-left: 10px;
				background: var(--eksa-cream);
			}
			
			.dataTables_wrapper .dataTables_filter input:focus {
				outline: none;
				border-color: var(--eksa-gold);
				box-shadow: 0 0 0 5px var(--eksa-gold-glow);
			}
			
			.dataTables_wrapper .dataTables_paginate .paginate_button {
				border-radius: 50px !important;
				padding: 8px 15px !important;
				margin: 0 3px;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				background: var(--eksa-white) !important;
				color: var(--eksa-navy) !important;
			}
			
			.dataTables_wrapper .dataTables_paginate .paginate_button.current {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy-dark) !important;
				border-color: var(--eksa-gold) !important;
			}
			
			/* ===== EMPTY STATE ===== */
			.empty-state {
				text-align: center;
				padding: 60px 20px;
				background: rgba(196, 164, 132, 0.03);
				border-radius: 20px;
			}
			
			.empty-state i {
				font-size: 4rem;
				color: var(--eksa-gold);
				margin-bottom: 20px;
				opacity: 0.5;
			}
			
			.empty-state h4 {
				color: var(--eksa-navy);
				margin-bottom: 10px;
			}
			
			.empty-state p {
				color: var(--eksa-navy-light);
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 768px) {
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.nav-pills {
					flex-direction: column;
				}
				
				.nav-pills li a {
					display: block;
					text-align: center;
				}
				
				.panel-body {
					padding: 25px;
				}
				
				.page-header {
					flex-direction: column;
					align-items: flex-start;
				}
				
				.page-title h2 {
					font-size: 1.8rem;
				}
				
				.stats-container {
					flex-direction: column;
				}
				
				.stat-card {
					width: 100%;
				}
				
				.action-buttons {
					flex-direction: column;
				}
				
				.btn-checkout {
					width: 100%;
					justify-content: center;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 30px !important;
				padding-right: 30px !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
			
			.btn.disabled {
				opacity: 0.7;
				pointer-events: none;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
			<ul class = "nav navbar-nav pull-right">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						<i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
						<span style="color: var(--eksa-white); font-weight: 600;"><?php echo $name; ?></span>
						<span class="caret" style="color: var(--eksa-gold);"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
						<li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
						<li class="divider"></li>
						<li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	
	<!-- LUXURY NAVIGATION PILLS - FIXED: Added Check In and Check Out tabs -->
	<div class = "container-fluid">
		<ul class = "nav nav-pills">
			<li><a href = "home.php"><i class="fas fa-home me-2"></i> Dashboard</a></li>
			<li><a href = "account.php"><i class="fas fa-users-cog me-2"></i> Accounts</a></li>
			<li class = "active"><a href = "reserve.php"><i class="fas fa-calendar-check me-2"></i> Pending</a></li>
			<li><a href = "checkin.php"><i class="fas fa-sign-in-alt me-2"></i> Check In</a></li>
			<li><a href = "checkout.php"><i class="fas fa-sign-out-alt me-2"></i> Check Out</a></li>
			<li><a href = "room.php"><i class="fas fa-bed me-2"></i> Rooms</a></li>
			<li><a href = "reports.php"><i class="fas fa-chart-line me-2"></i> Reports</a></li>
		</ul>
	</div>
	
	<br />
	
	<!-- LUXURY RESERVATION MANAGEMENT CONTENT -->
	<div class = "container-fluid">	
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- PAGE HEADER -->
				<div class="page-header">
					<div class="page-title">
						<i class="fas fa-calendar-check"></i>
						<div>
							<h2>Pending Reservations</h2>
							<p>Manage pending reservations and check-ins</p>
						</div>
					</div>
				</div>
				
				<?php
					// Get statistics
					$q_p = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Pending'") or die(mysqli_error($conn));
					$f_p = $q_p->fetch_array();
					$q_ci = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Check In'") or die(mysqli_error($conn));
					$f_ci = $q_ci->fetch_array();
					$q_co = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Check Out'") or die(mysqli_error($conn));
					$f_co = $q_co->fetch_array();
					
					// Get overdue reservations (check-in date is past)
					$current_date = date("Y-m-d");
					$q_overdue = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Pending' AND `checkin` < '$current_date'") or die(mysqli_error($conn));
					$f_overdue = $q_overdue->fetch_array();
				?>
				
				<!-- STATISTICS CARDS -->
				<div class="stats-container">
					<div class="stat-card">
						<div class="stat-icon pending">
							<i class="fas fa-clock"></i>
						</div>
						<div class="stat-content">
							<h4><?php echo $f_p['total']; ?></h4>
							<p>Pending Reservations</p>
							<?php if($f_overdue['total'] > 0): ?>
								<small style="color: #dc3545;"><i class="fas fa-exclamation-circle"></i> <?php echo $f_overdue['total']; ?> overdue</small>
							<?php endif; ?>
						</div>
					</div>
					
					<div class="stat-card">
						<div class="stat-icon checkin">
							<i class="fas fa-sign-in-alt"></i>
						</div>
						<div class="stat-content">
							<h4><?php echo $f_ci['total']; ?></h4>
							<p>Checked In</p>
							<small style="color: var(--eksa-navy-light);">Currently staying</small>
						</div>
					</div>
					
					<div class="stat-card">
						<div class="stat-icon" style="background: rgba(108,117,125,0.1); color: #6c757d;">
							<i class="fas fa-sign-out-alt"></i>
						</div>
						<div class="stat-content">
							<h4><?php echo $f_co['total']; ?></h4>
							<p>Checked Out</p>
							<small style="color: var(--eksa-navy-light);">Completed stays</small>
						</div>
					</div>
				</div>
				
				<!-- ACTION BUTTONS -->
				<div class="action-buttons">
					<a class="btn-checkout" href="checkout.php">
						<i class="fas fa-eye"></i> View Check Outs
					</a>
				</div>
				
				<!-- PENDING RESERVATIONS TABLE -->
				<div class="table-container">
					<table id = "table" class = "table table-bordered">
						<thead>
							<tr>
								<th><i class="fas fa-user"></i> Guest Name</th>
								<th><i class="fas fa-phone"></i> Contact</th>
								<th><i class="fas fa-bed"></i> Room Type</th>
								<th><i class="fas fa-calendar-alt"></i> Reserved Date</th>
								<th><i class="fas fa-tag"></i> Status</th>
								<th><i class="fas fa-cog"></i> Actions</th>
							</tr>
						</thead>
						<tbody>
							<?php
$query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` NATURAL JOIN `room` WHERE `status` = 'Pending' ORDER BY `checkin` ASC") or die(mysqli_error($conn));
								if($query->num_rows > 0) {
									while($fetch = $query->fetch_array()){
										$checkin_date = date("Y-m-d", strtotime($fetch['checkin']));
										$current_date = date("Y-m-d");
										$is_overdue = ($checkin_date < $current_date);
							?>
							<tr>
								<td>
									<i class="fas fa-user-circle" style="color: var(--eksa-gold); margin-right: 8px;"></i>
									<?php echo $fetch['firstname'] . " " . $fetch['lastname']; ?>
								</td>
								<td>
									<span style="background: rgba(196,164,132,0.1); padding: 5px 12px; border-radius: 50px;">
										<i class="fas fa-phone-alt" style="color: var(--eksa-gold);"></i> 
										<?php echo $fetch['contactno']; ?>
									</span>
								</td>
								<td>
									<span style="font-weight: 600; color: var(--eksa-navy);">
										<?php echo $fetch['room_type']; ?>
									</span>
								</td>
								<td>
									<span class="date-badge <?php echo $is_overdue ? 'date-overdue' : 'date-upcoming'; ?>">
										<i class="fas <?php echo $is_overdue ? 'fa-exclamation-circle' : 'fa-calendar-check'; ?>"></i>
										<?php echo date("M d, Y", strtotime($fetch['checkin'])); ?>
									</span>
								</td>
								<td>
									<span class="status-badge status-pending">
										<i class="fas fa-clock"></i> <?php echo $fetch['status']; ?>
									</span>
								</td>
								<td>
									<center>
										<!-- FIXED: Changed button to proper link -->
										<a href="confirm_reserve.php?transaction_id=<?php echo $fetch['transaction_id']; ?>" class="btn-checkin">
    <i class="fas fa-check-circle"></i> Check In
</a>
										<a class = "btn-discard" onclick = "confirmationDelete(this); return false;" href = "delete_pending.php?transaction_id=<?php echo $fetch['transaction_id']?>">
											<i class = "fas fa-trash-alt"></i> Discard
										</a>
									</center>
								</td>
							</tr>
							<?php
									}
								}
							?>
						</tbody>
					</table>
					
					<?php if($query->num_rows == 0): ?>
					<div class="empty-state">
						<i class="fas fa-calendar-check"></i>
						<h4>No Pending Reservations</h4>
						<p>All reservations have been processed or there are no pending bookings.</p>
					</div>
					<?php endif; ?>
				</div>
				
				<!-- QUICK TIPS -->
				<div style="margin-top: 30px; padding: 20px; background: rgba(196,164,132,0.03); border-radius: 15px; border: 1px dashed var(--eksa-gold);">
					<div style="display: flex; align-items: center; gap: 15px;">
						<i class="fas fa-info-circle" style="font-size: 2rem; color: var(--eksa-gold);"></i>
						<div>
							<h5 style="color: var(--eksa-navy); margin-bottom: 5px;">Reservation Guidelines</h5>
							<p style="color: var(--eksa-navy-light); margin: 0; font-size: 0.9rem;">
								<strong>Check In:</strong> Confirm guest arrival and assign room. | 
								<strong>Discard:</strong> Cancel reservation (non-refundable). | 
								<strong>Overdue:</strong> Red dates indicate check-in date has passed.
							</p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • RESERVATION MANAGEMENT • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-calendar-check"></i> Pending: <?php echo $f_p['total']; ?> | Checked In: <?php echo $f_ci['total']; ?> <i class="fas fa-calendar-check"></i>
		</div>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script src = "../js/jquery.dataTables.js"></script>
<script src = "../js/dataTables.bootstrap.js"></script>	
<script type = "text/javascript">
	$(document).ready(function(){
		$("#table").DataTable({
			language: {
				search: "Filter reservations:",
				lengthMenu: "Show _MENU_ reservations",
				info: "Showing _START_ to _END_ of _TOTAL_ pending reservations",
				paginate: {
					first: "First",
					last: "Last",
					next: '<i class="fas fa-chevron-right"></i>',
					previous: '<i class="fas fa-chevron-left"></i>'
				}
			},
			order: [[3, 'asc']] // Sort by check-in date
		});
		
		// Add animation to table rows
		$('#table tbody tr').each(function(index) {
			$(this).css({
				'opacity': '0',
				'transform': 'translateY(20px)'
			});
			
			setTimeout(() => {
				$(this).css({
					'transition': 'all 0.4s ease',
					'opacity': '1',
					'transform': 'translateY(0)'
				});
			}, 50 * index);
		});
	});
	
	function confirmationDelete(anchor) {
		var transaction_id = anchor.getAttribute('href').match(/transaction_id=(\d+)/)[1];
		
		swal({
			title: 'Discard Reservation?',
			text: 'Are you sure you want to discard this pending reservation? This action cannot be undone.',
			icon: 'warning',
			buttons: ['Cancel', 'Discard'],
			dangerMode: true,
		}).then((willDelete) => {
			if (willDelete) {
				window.location = anchor.getAttribute('href');
			}
			return false;
		});
		return false;
	}
</script>
</html>