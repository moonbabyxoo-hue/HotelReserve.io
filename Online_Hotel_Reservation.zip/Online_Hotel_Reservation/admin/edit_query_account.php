<?php
// ==================== START SESSION AT THE VERY TOP ====================
session_start();
require_once 'connect.php';
require_once 'validate.php';

// Check if form was submitted
if (!isset($_POST['edit_account'])) {
    header("location: account.php");
    exit();
}

// Get and sanitize form data
$admin_id = isset($_REQUEST['admin_id']) ? (int)$_REQUEST['admin_id'] : 0;
$name = trim($_POST['name']);
$username = trim($_POST['username']);
$password = trim($_POST['password']);

// Validate required fields
if (empty($name) || empty($username)) {
    $_SESSION['error_message'] = "Name and username cannot be empty!";
    header("location: edit_account.php?admin_id=" . $admin_id);
    exit();
}

// Check if trying to edit Super Admin
$check_query = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$admin_id'");
if ($check_query->num_rows == 0) {
    $_SESSION['error_message'] = "Account not found!";
    header("location: account.php");
    exit();
}

$admin_data = $check_query->fetch_array();
$is_super_admin = ($admin_data['admin_id'] == 1);

// Prepare update query based on whether password is changed
if (!empty($password)) {
    // Password is being changed - validate length
    if (strlen($password) < 8) {
        $_SESSION['error_message'] = "Password must be at least 8 characters long!";
        header("location: edit_account.php?admin_id=" . $admin_id);
        exit();
    }
    
    // Update with new password
    $update_sql = "UPDATE `admin` SET 
                    `name` = ?, 
                    `username` = ?, 
                    `password` = ? 
                    WHERE `admin_id` = ?";
    
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("sssi", $name, $username, $password, $admin_id);
    
} else {
    // Password not changed - keep existing password
    $update_sql = "UPDATE `admin` SET 
                    `name` = ?, 
                    `username` = ? 
                    WHERE `admin_id` = ?";
    
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssi", $name, $username, $admin_id);
}

// Execute the query
if ($stmt->execute()) {
    // Success - set success message
    $_SESSION['success_message'] = "Account updated successfully!";
} else {
    // Error - set error message
    $_SESSION['error_message'] = "Failed to update account: " . $conn->error;
}

// Close statement
$stmt->close();

// Redirect back to account page
header("location: account.php");
exit();
?>