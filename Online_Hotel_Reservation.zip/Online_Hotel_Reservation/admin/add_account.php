<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Create Account</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - CREATE ACCOUNT ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
				--eksa-success: #28a745;
				--eksa-info: #17a2b8;
				--eksa-warning: #ffc107;
				--eksa-danger: #dc3545;
				--eksa-purple: #6f42c1;
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 80px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 30px !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY DROPDOWN MENU ===== */
			.dropdown-menu {
				background: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				border-radius: 15px;
				box-shadow: 0 15px 40px var(--eksa-shadow-dark);
				padding: 10px;
			}
			
			.dropdown-menu li a {
				color: var(--eksa-navy);
				padding: 10px 20px;
				border-radius: 10px;
				transition: all 0.3s ease;
			}
			
			.dropdown-menu li a:hover {
				background: rgba(196, 164, 132, 0.1);
				color: var(--eksa-gold-dark);
			}
			
			.dropdown-menu li a i {
				color: var(--eksa-gold);
				margin-right: 10px;
			}
			
			/* ===== LUXURY NAV PILLS ===== */
			.nav-pills {
				margin: 20px 0;
				display: flex;
				flex-wrap: wrap;
				gap: 10px;
			}
			
			.nav-pills li {
				margin: 0;
			}
			
			.nav-pills li a {
				background: var(--eksa-white);
				color: var(--eksa-navy);
				padding: 12px 25px;
				border-radius: 50px;
				font-weight: 600;
				transition: all 0.3s ease;
				border: 2px solid rgba(196, 164, 132, 0.2);
				text-decoration: none;
				display: inline-block;
			}
			
			.nav-pills li a:hover {
				background: rgba(196, 164, 132, 0.1);
				border-color: var(--eksa-gold);
				transform: translateY(-2px);
			}
			
			.nav-pills li.active a {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border-color: var(--eksa-white);
			}
			
			/* ===== LUXURY PANEL ===== */
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white);
				border-radius: 30px;
				padding: 40px;
				box-shadow: 0 30px 60px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			/* ===== PAGE HEADER ===== */
			.page-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 30px;
				flex-wrap: wrap;
				gap: 20px;
			}
			
			.page-title {
				display: flex;
				align-items: center;
				gap: 15px;
			}
			
			.page-title i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
				background: rgba(196, 164, 132, 0.1);
				padding: 15px;
				border-radius: 20px;
			}
			
			.page-title h2 {
				color: var(--eksa-navy);
				font-size: 2.2rem;
				margin: 0;
			}
			
			.page-title p {
				color: var(--eksa-navy-light);
				margin: 5px 0 0;
				font-size: 0.95rem;
			}
			
			/* ===== LUXURY ALERT ===== */
			.alert-info {
				background: linear-gradient(135deg, var(--eksa-info), #138496);
				color: white;
				border: none;
				border-radius: 15px;
				padding: 20px 25px;
				font-size: 1.1rem;
				font-weight: 600;
				margin-bottom: 30px;
				border-left: 5px solid var(--eksa-gold);
				display: flex;
				align-items: center;
				gap: 15px;
			}
			
			.alert-info i {
				color: var(--eksa-gold);
				font-size: 1.5rem;
			}
			
			/* ===== ROLE BADGE ===== */
			.role-badge {
				display: inline-block;
				padding: 8px 20px;
				border-radius: 50px;
				font-weight: 600;
				font-size: 0.85rem;
			}
			
			.role-superadmin {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
			}
			
			.role-manager {
				background: linear-gradient(135deg, var(--eksa-purple), #5a32a3);
				color: white;
			}
			
			.role-staff {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				color: var(--eksa-gold-light);
			}
			
			/* ===== FORM STYLES ===== */
			.form-container {
				max-width: 600px;
				margin: 0 auto;
			}
			
			.form-group {
				margin-bottom: 25px;
			}
			
			.form-group label {
				display: block;
				margin-bottom: 10px;
				font-weight: 600;
				color: var(--eksa-navy);
				font-size: 0.95rem;
				letter-spacing: 1px;
			}
			
			.form-group label i {
				color: var(--eksa-gold);
				margin-right: 8px;
			}
			
			.input-wrapper {
				position: relative;
				display: flex;
				align-items: center;
			}
			
			.input-icon {
				position: absolute;
				left: 15px;
				color: var(--eksa-gold);
				font-size: 1.1rem;
				z-index: 10;
			}
			
			.form-control {
				width: 100%;
				padding: 14px 20px 14px 45px;
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 15px;
				font-size: 1rem;
				transition: all 0.3s ease;
				background: var(--eksa-cream);
				font-family: 'Poppins', sans-serif;
			}
			
			.form-control:focus {
				outline: none;
				border-color: var(--eksa-gold);
				box-shadow: 0 0 0 5px var(--eksa-gold-glow);
				background: var(--eksa-white);
				transform: translateY(-2px);
			}
			
			/* ===== ROLE SELECTOR ===== */
			.role-selector {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
				gap: 15px;
				margin-top: 10px;
			}
			
			.role-option {
				position: relative;
			}
			
			.role-option input[type="radio"] {
				position: absolute;
				opacity: 0;
				width: 0;
				height: 0;
			}
			
			.role-option label {
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				padding: 20px 15px;
				background: var(--eksa-white);
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 15px;
				cursor: pointer;
				transition: all 0.3s ease;
				margin-bottom: 0;
			}
			
			.role-option label i {
				font-size: 1.8rem;
				color: var(--eksa-gold);
				margin-bottom: 10px;
			}
			
			.role-option label span {
				font-weight: 600;
				color: var(--eksa-navy);
			}
			
			.role-option label small {
				color: var(--eksa-navy-light);
				font-size: 0.8rem;
				margin-top: 5px;
			}
			
			.role-option input[type="radio"]:checked + label {
				border-color: var(--eksa-gold);
				background: rgba(196, 164, 132, 0.05);
				box-shadow: 0 0 0 3px var(--eksa-gold-glow);
			}
			
			.role-option input[type="radio"]:checked + label i {
				color: var(--eksa-gold-dark);
			}
			
			/* ===== PASSWORD REQUIREMENTS ===== */
			.password-requirements {
				margin-top: 15px;
				padding: 15px;
				background: rgba(196, 164, 132, 0.05);
				border-radius: 12px;
				font-size: 0.85rem;
			}
			
			.password-requirements p {
				color: var(--eksa-navy);
				font-weight: 600;
				margin-bottom: 10px;
			}
			
			.requirement-item {
				display: flex;
				align-items: center;
				gap: 8px;
				margin-bottom: 5px;
				color: var(--eksa-navy-light);
			}
			
			.requirement-item i {
				color: var(--eksa-gold);
				font-size: 0.8rem;
			}
			
			.requirement-item.valid i {
				color: #28a745;
			}
			
			/* ===== BUTTON STYLES ===== */
			.btn-save {
				background: linear-gradient(135deg, var(--eksa-success), #218838);
				color: white;
				border: none;
				padding: 16px 30px;
				border-radius: 50px;
				font-size: 1.1rem;
				font-weight: 700;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				gap: 12px;
				border: 2px solid transparent;
				margin-top: 20px;
				width: 100%;
			}
			
			.btn-save:hover {
				background: #218838;
				transform: translateY(-3px);
				box-shadow: 0 15px 30px rgba(40, 167, 69, 0.3);
				border-color: var(--eksa-white);
			}
			
			.btn-cancel {
				background: transparent;
				color: var(--eksa-navy);
				border: 2px solid var(--eksa-gold);
				padding: 14px 30px;
				border-radius: 50px;
				font-size: 1rem;
				font-weight: 600;
				transition: all 0.3s ease;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				gap: 10px;
				text-decoration: none;
				width: 100%;
				margin-top: 15px;
			}
			
			.btn-cancel:hover {
				background: var(--eksa-gold);
				color: var(--eksa-navy-dark);
				transform: translateY(-2px);
				text-decoration: none;
			}
			
			/* ===== PERMISSION CARD ===== */
			.permission-card {
				background: rgba(196, 164, 132, 0.03);
				border-radius: 15px;
				padding: 20px;
				margin-top: 30px;
				border: 1px dashed var(--eksa-gold);
			}
			
			.permission-title {
				display: flex;
				align-items: center;
				gap: 10px;
				color: var(--eksa-navy);
				font-weight: 600;
				margin-bottom: 15px;
			}
			
			.permission-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
				gap: 15px;
			}
			
			.permission-item {
				display: flex;
				align-items: center;
				gap: 10px;
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
			}
			
			.permission-item i {
				color: var(--eksa-gold);
				width: 20px;
			}
			
			/* ===== ACCESS DENIED ===== */
			.access-denied {
				text-align: center;
				padding: 60px 20px;
				background: rgba(220, 53, 69, 0.05);
				border-radius: 20px;
				border: 2px solid #dc3545;
			}
			
			.access-denied i {
				font-size: 4rem;
				color: #dc3545;
				margin-bottom: 20px;
			}
			
			.access-denied h3 {
				color: #dc3545;
				margin-bottom: 15px;
			}
			
			.access-denied p {
				color: var(--eksa-navy-light);
				margin-bottom: 25px;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 768px) {
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.nav-pills {
					flex-direction: column;
				}
				
				.nav-pills li a {
					display: block;
					text-align: center;
				}
				
				.panel-body {
					padding: 30px;
				}
				
				.page-header {
					flex-direction: column;
					align-items: flex-start;
				}
				
				.page-title h2 {
					font-size: 1.8rem;
				}
				
				.role-selector {
					grid-template-columns: 1fr;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 30px !important;
				padding-right: 30px !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
			
			.col-md-4 {
				width: 100% !important;
				max-width: 600px;
				margin: 0 auto;
				float: none;
			}
		</style>
	</head>
<body>
	<?php
		// Check current user's role from session
		$current_user_role = isset($_SESSION['admin_role']) ? $_SESSION['admin_role'] : 'Staff';
		$current_user_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
		
		// Get current user details
		require_once 'connect.php';
		$user_query = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$current_user_id'") or die(mysqli_error($conn));
		$user_data = $user_query->fetch_array();
		$current_user_role = $user_data['role'] ?? 'Staff';
		
		// Check if user has permission to create accounts (Only Super Admin and Manager)
		$can_create_accounts = ($current_user_role == 'Super Admin' || $current_user_role == 'Manager');
	?>
	
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
			<ul class = "nav navbar-nav pull-right">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						<i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
						<span style="color: var(--eksa-white); font-weight: 600;"><?php echo $name; ?></span>
						<span class="caret" style="color: var(--eksa-gold);"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
						<li>
							<span style="display: block; padding: 10px 20px; color: var(--eksa-gold);">
								<i class="fas fa-tag"></i> Role: 
								<?php if($current_user_role == 'Super Admin'): ?>
									<span class="role-badge role-superadmin" style="margin-left: 5px;">Super Admin</span>
								<?php elseif($current_user_role == 'Manager'): ?>
									<span class="role-badge role-manager" style="margin-left: 5px;">Manager</span>
								<?php else: ?>
									<span class="role-badge role-staff" style="margin-left: 5px;">Staff</span>
								<?php endif; ?>
							</span>
						</li>
						<li class="divider"></li>
						<li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	
	<!-- LUXURY NAVIGATION PILLS -->
	<div class = "container-fluid">
		<ul class = "nav nav-pills">
			<li><a href = "home.php"><i class="fas fa-home me-2"></i> Dashboard</a></li>
			<li class = "active"><a href = "account.php"><i class="fas fa-users-cog me-2"></i> Accounts</a></li>
			<li><a href = "reserve.php"><i class="fas fa-calendar-check me-2"></i> Pending</a></li>
			<li><a href = "checkin.php"><i class="fas fa-sign-in-alt me-2"></i> Check In</a></li>
			<li><a href = "checkout.php"><i class="fas fa-sign-out-alt me-2"></i> Check Out</a></li>
			<li><a href = "room.php"><i class="fas fa-bed me-2"></i> Rooms</a></li>
			<li><a href = "reports.php"><i class="fas fa-chart-line me-2"></i> Reports</a></li>
		</ul>
	</div>
	
	<br />
	
	<!-- LUXURY CREATE ACCOUNT CONTENT -->
	<div class = "container-fluid">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<?php if($can_create_accounts): ?>
				
				<!-- PAGE HEADER -->
				<div class="page-header">
					<div class="page-title">
						<i class="fas fa-user-plus"></i>
						<div>
							<h2>Create New Account</h2>
							<p>Add a new administrator, manager, or staff member</p>
						</div>
					</div>
					<a href="account.php" style="color: var(--eksa-gold-dark); font-size: 1rem; text-decoration: none;">
						<i class="fas fa-arrow-left"></i> Back to Accounts
					</a>
				</div>
				
				<!-- CURRENT USER ROLE DISPLAY -->
				<div style="display: flex; align-items: center; gap: 15px; background: rgba(196,164,132,0.05); padding: 15px 20px; border-radius: 15px; margin-bottom: 30px;">
					<i class="fas fa-shield-alt" style="color: var(--eksa-gold); font-size: 1.5rem;"></i>
					<div>
						<span style="color: var(--eksa-navy-light);">You are creating accounts as:</span>
						<?php if($current_user_role == 'Super Admin'): ?>
							<span class="role-badge role-superadmin" style="margin-left: 10px;">Super Administrator</span>
							<small style="display: block; color: var(--eksa-navy-light); margin-top: 5px;">You have full access to create all account types</small>
						<?php elseif($current_user_role == 'Manager'): ?>
							<span class="role-badge role-manager" style="margin-left: 10px;">Manager</span>
							<small style="display: block; color: var(--eksa-navy-light); margin-top: 5px;">You can create Staff accounts only</small>
						<?php endif; ?>
					</div>
				</div>
				
				<div class="form-container">
					<form method = "POST" id="createAccountForm">
						<!-- Name Field -->
						<div class = "form-group">
							<label><i class="fas fa-user"></i> Full Name</label>
							<div class="input-wrapper">
								<i class="fas fa-user input-icon"></i>
								<input type = "text" class = "form-control" name = "name" placeholder = "Enter full name" required />
							</div>
						</div>
						
						<!-- Username Field -->
						<div class = "form-group">
							<label><i class="fas fa-at"></i> Username</label>
							<div class="input-wrapper">
								<i class="fas fa-at input-icon"></i>
								<input type = "text" class = "form-control" name = "username" placeholder = "Enter username" required />
							</div>
						</div>
						
						<!-- Password Field -->
						<div class = "form-group">
							<label><i class="fas fa-lock"></i> Password</label>
							<div class="input-wrapper">
								<i class="fas fa-lock input-icon"></i>
								<input type = "password" class = "form-control" name = "password" id="password" placeholder = "Enter password" required />
								<i class="fas fa-eye password-toggle" style="position: absolute; right: 15px; color: var(--eksa-gold); cursor: pointer;" onclick="togglePassword()"></i>
							</div>
							
							<!-- Password Requirements -->
							<div class="password-requirements">
								<p><i class="fas fa-info-circle" style="color: var(--eksa-gold);"></i> Password Requirements:</p>
								<div class="requirement-item" id="req-length">
									<i class="fas fa-circle"></i> At least 8 characters
								</div>
								<div class="requirement-item" id="req-uppercase">
									<i class="fas fa-circle"></i> At least one uppercase letter
								</div>
								<div class="requirement-item" id="req-lowercase">
									<i class="fas fa-circle"></i> At least one lowercase letter
								</div>
								<div class="requirement-item" id="req-number">
									<i class="fas fa-circle"></i> At least one number
								</div>
								<div class="requirement-item" id="req-special">
									<i class="fas fa-circle"></i> At least one special character (@$!%*?&)
								</div>
							</div>
						</div>
						
						<!-- Role Selection - Dynamic based on current user -->
						<div class = "form-group">
							<label><i class="fas fa-tag"></i> Account Role</label>
							<div class="role-selector">
								<?php if($current_user_role == 'Super Admin'): ?>
									<!-- Super Admin can create all roles -->
									<div class="role-option">
										<input type="radio" name="role" id="role_superadmin" value="Super Admin">
										<label for="role_superadmin">
											<i class="fas fa-crown"></i>
											<span>Super Admin</span>
											<small>Full system access</small>
										</label>
									</div>
								<?php endif; ?>
								
								<?php if($current_user_role == 'Super Admin' || $current_user_role == 'Manager'): ?>
									<!-- Manager and Super Admin can create Managers -->
									<div class="role-option">
										<input type="radio" name="role" id="role_manager" value="Manager" <?php echo ($current_user_role == 'Manager') ? 'checked' : ''; ?>>
										<label for="role_manager">
											<i class="fas fa-user-tie"></i>
											<span>Manager</span>
											<small>Manage operations</small>
										</label>
									</div>
								<?php endif; ?>
								
								<!-- Everyone can create Staff -->
								<div class="role-option">
									<input type="radio" name="role" id="role_staff" value="Staff" checked>
									<label for="role_staff">
										<i class="fas fa-user"></i>
										<span>Staff</span>
										<small>Basic access</small>
									</label>
								</div>
							</div>
						</div>
						
						<!-- Permission Preview - Dynamic based on selected role -->
						<div class="permission-card" id="permissionCard">
							<div class="permission-title">
								<i class="fas fa-shield-alt"></i>
								<span id="permissionTitle">Staff Permissions</span>
							</div>
							<div class="permission-grid" id="permissionGrid">
								<!-- Permissions will be updated via JavaScript -->
							</div>
						</div>
						
						<!-- Action Buttons -->
						<div style="margin-top: 30px;">
							<button type="submit" name = "add_account" class = "btn-save">
								<i class = "fas fa-save"></i> CREATE ACCOUNT
							</button>
							<a href="account.php" class = "btn-cancel">
								<i class = "fas fa-times-circle"></i> CANCEL
							</a>
						</div>
					</form>
					
					<?php require_once 'add_query_account.php'?>
				</div>
				
				<?php else: ?>
				
				<!-- ACCESS DENIED - Staff cannot create accounts -->
				<div class="access-denied">
					<i class="fas fa-shield-alt"></i>
					<h3>Access Denied</h3>
					<p>You don't have permission to create new accounts. Only Super Administrators and Managers can perform this action.</p>
					<a href="account.php" class="btn-cancel" style="display: inline-block; width: auto; padding: 12px 30px;">
						<i class="fas fa-arrow-left"></i> Back to Accounts
					</a>
				</div>
				
				<?php endif; ?>
				
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • ACCOUNT MANAGEMENT • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-user-plus"></i> 
			<?php if($can_create_accounts): ?>
				Creating new account
			<?php else: ?>
				Access restricted
			<?php endif; ?>
			<i class="fas fa-user-plus"></i>
		</div>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script>
	// Toggle password visibility
	function togglePassword() {
		var passwordField = document.getElementById("password");
		var icon = event.currentTarget;
		
		if (passwordField.type === "password") {
			passwordField.type = "text";
			icon.classList.remove("fa-eye");
			icon.classList.add("fa-eye-slash");
		} else {
			passwordField.type = "password";
			icon.classList.remove("fa-eye-slash");
			icon.classList.add("fa-eye");
		}
	}
	
	// Password strength validation
	document.getElementById('password').addEventListener('input', function() {
		var password = this.value;
		
		// Check length
		var lengthReq = document.getElementById('req-length');
		if (password.length >= 8) {
			lengthReq.innerHTML = '<i class="fas fa-check-circle" style="color: #28a745;"></i> At least 8 characters';
			lengthReq.classList.add('valid');
		} else {
			lengthReq.innerHTML = '<i class="fas fa-circle"></i> At least 8 characters';
			lengthReq.classList.remove('valid');
		}
		
		// Check uppercase
		var upperReq = document.getElementById('req-uppercase');
		if (/[A-Z]/.test(password)) {
			upperReq.innerHTML = '<i class="fas fa-check-circle" style="color: #28a745;"></i> At least one uppercase letter';
			upperReq.classList.add('valid');
		} else {
			upperReq.innerHTML = '<i class="fas fa-circle"></i> At least one uppercase letter';
			upperReq.classList.remove('valid');
		}
		
		// Check lowercase
		var lowerReq = document.getElementById('req-lowercase');
		if (/[a-z]/.test(password)) {
			lowerReq.innerHTML = '<i class="fas fa-check-circle" style="color: #28a745;"></i> At least one lowercase letter';
			lowerReq.classList.add('valid');
		} else {
			lowerReq.innerHTML = '<i class="fas fa-circle"></i> At least one lowercase letter';
			lowerReq.classList.remove('valid');
		}
		
		// Check number
		var numReq = document.getElementById('req-number');
		if (/[0-9]/.test(password)) {
			numReq.innerHTML = '<i class="fas fa-check-circle" style="color: #28a745;"></i> At least one number';
			numReq.classList.add('valid');
		} else {
			numReq.innerHTML = '<i class="fas fa-circle"></i> At least one number';
			numReq.classList.remove('valid');
		}
		
		// Check special character
		var specialReq = document.getElementById('req-special');
		if (/[@$!%*?&]/.test(password)) {
			specialReq.innerHTML = '<i class="fas fa-check-circle" style="color: #28a745;"></i> At least one special character (@$!%*?&)';
			specialReq.classList.add('valid');
		} else {
			specialReq.innerHTML = '<i class="fas fa-circle"></i> At least one special character (@$!%*?&)';
			specialReq.classList.remove('valid');
		}
	});
	
	// Update permissions based on selected role
	document.addEventListener('DOMContentLoaded', function() {
		updatePermissions();
		
		var roleRadios = document.querySelectorAll('input[name="role"]');
		roleRadios.forEach(function(radio) {
			radio.addEventListener('change', updatePermissions);
		});
	});
	
	function updatePermissions() {
		var selectedRole = document.querySelector('input[name="role"]:checked');
		if (!selectedRole) return;
		
		var role = selectedRole.value;
		var permissionTitle = document.getElementById('permissionTitle');
		var permissionGrid = document.getElementById('permissionGrid');
		
		if (role === 'Super Admin') {
			permissionTitle.innerHTML = 'Super Administrator Permissions';
			permissionGrid.innerHTML = `
				<div class="permission-item"><i class="fas fa-check-circle"></i> Full system access</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Create/Edit/Delete all accounts</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Manage all reservations</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> View all reports</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> System configuration</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Audit logs access</div>
			`;
		} else if (role === 'Manager') {
			permissionTitle.innerHTML = 'Manager Permissions';
			permissionGrid.innerHTML = `
				<div class="permission-item"><i class="fas fa-check-circle"></i> Create/Edit Staff accounts</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Manage all reservations</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Check-in/Check-out guests</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Manage room inventory</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> View reports</div>
				<div class="permission-item"><i class="fas fa-times-circle" style="color: #dc3545;"></i> Cannot delete Super Admin</div>
			`;
		} else {
			permissionTitle.innerHTML = 'Staff Permissions';
			permissionGrid.innerHTML = `
				<div class="permission-item"><i class="fas fa-check-circle"></i> View reservations</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> Check-in/Check-out guests</div>
				<div class="permission-item"><i class="fas fa-check-circle"></i> View room availability</div>
				<div class="permission-item"><i class="fas fa-times-circle" style="color: #dc3545;"></i> Cannot create accounts</div>
				<div class="permission-item"><i class="fas fa-times-circle" style="color: #dc3545;"></i> Cannot edit/delete accounts</div>
				<div class="permission-item"><i class="fas fa-times-circle" style="color: #dc3545;"></i> Cannot modify room prices</div>
			`;
		}
	}
	
	// Form validation
	document.getElementById('createAccountForm').addEventListener('submit', function(e) {
		var name = document.querySelector('input[name="name"]').value.trim();
		var username = document.querySelector('input[name="username"]').value.trim();
		var password = document.getElementById('password').value;
		var role = document.querySelector('input[name="role"]:checked');
		
		if (!name || !username || !password) {
			e.preventDefault();
			swal({
				title: 'Validation Error',
				text: 'Please fill in all required fields',
				icon: 'error',
				button: 'OK'
			});
			return false;
		}
		
		if (password.length < 8) {
			e.preventDefault();
			swal({
				title: 'Password Too Short',
				text: 'Password must be at least 8 characters long',
				icon: 'error',
				button: 'OK'
			});
			return false;
		}
		
		if (!role) {
			e.preventDefault();
			swal({
				title: 'Role Required',
				text: 'Please select a role for the new account',
				icon: 'error',
				button: 'OK'
			});
			return false;
		}
		
		// Confirm account creation
		e.preventDefault();
		swal({
			title: 'Create Account?',
			text: 'Are you sure you want to create this ' + role.value + ' account?',
			icon: 'info',
			buttons: ['Cancel', 'Create'],
			dangerMode: false,
		}).then((willCreate) => {
			if (willCreate) {
				// Add hidden role field and submit
				var form = this;
				
				// Create a hidden input for role
				var roleInput = document.createElement('input');
				roleInput.type = 'hidden';
				roleInput.name = 'user_role';
				roleInput.value = role.value;
				form.appendChild(roleInput);
				
				form.submit();
			}
		});
	});
</script>
</html>