<!DOCTYPE html>
<?php
    require_once 'validate.php';
    require 'name.php';
?>
<html lang = "en">
    <head>
        <title>Hotel Eksa - Confirm Check-Out & Payment</title>
        <meta charset = "utf-8" />
        <meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
        <!-- Font Awesome 6 -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <!-- Sweet Alert -->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!-- Khalti SDK -->
        <script src="https://khalti.s3.ap-south-1.amazonaws.com/KPG/dist/2020.12.17.0.0.0/khalti-checkout.iffe.js"></script>
        <link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
        
        <style>
            :root {
                --eksa-gold: #C4A484;
                --eksa-gold-dark: #A67B5B;
                --eksa-navy: #0A1C2F;
                --eksa-navy-dark: #051220;
                --eksa-cream: #FAF7F2;
                --eksa-white: #FFFFFF;
                --eksa-success: #28a745;
                --eksa-danger: #dc3545;
                --eksa-warning: #ffc107;
                --esewa-green: #00B388;
                --khalti-purple: #5D2E8E;
            }
            
            body {
                font-family: 'Poppins', sans-serif;
                background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
                color: var(--eksa-navy);
                padding-bottom: 80px;
            }
            
            .navbar {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
                border-bottom: 3px solid var(--eksa-gold) !important;
            }
            
            .navbar-brand {
                color: var(--eksa-gold) !important;
                font-size: 1.8rem;
                font-family: 'Playfair Display', serif;
            }
            
            .nav-pills {
                margin: 20px 0;
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            
            .nav-pills li a {
                background: var(--eksa-white);
                color: var(--eksa-navy);
                padding: 12px 25px;
                border-radius: 50px;
                font-weight: 600;
                border: 2px solid rgba(196,164,132,0.2);
                text-decoration: none;
            }
            
            .nav-pills li.active a {
                background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
                color: var(--eksa-navy-dark);
            }
            
            .panel-body {
                background: var(--eksa-white);
                border-radius: 30px;
                padding: 40px;
                box-shadow: 0 30px 60px rgba(0,0,0,0.1);
                max-width: 1000px;
                margin: 0 auto;
            }
            
            .guest-info-card {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
                border-radius: 20px;
                padding: 30px;
                color: white;
                display: flex;
                gap: 30px;
                align-items: center;
                margin-bottom: 30px;
            }
            
            .guest-avatar {
                width: 100px;
                height: 100px;
                background: rgba(196,164,132,0.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                border: 3px solid var(--eksa-gold);
            }
            
            .guest-avatar i {
                font-size: 3rem;
                color: var(--eksa-gold);
            }
            
            .guest-name {
                font-size: 2rem;
                font-weight: 700;
                color: var(--eksa-gold);
            }
            
            .room-info-card {
                background: rgba(196,164,132,0.05);
                border-radius: 20px;
                padding: 30px;
                margin-bottom: 30px;
                border: 1px solid rgba(196,164,132,0.3);
            }
            
            .bill-summary {
                background: linear-gradient(135deg, #fff3cd, #ffe69c);
                border-radius: 20px;
                padding: 30px;
                margin-bottom: 30px;
                border-left: 5px solid var(--eksa-warning);
            }
            
            .total-amount {
                font-size: 2.5rem;
                font-weight: 800;
                color: var(--eksa-navy-dark);
            }
            
            /* ===== PAYMENT METHODS ===== */
            .payment-section {
                margin-top: 30px;
                padding: 30px;
                background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                border-radius: 20px;
                border: 1px solid rgba(196,164,132,0.2);
            }
            
            .payment-title {
                display: flex;
                align-items: center;
                gap: 15px;
                margin-bottom: 25px;
            }
            
            .payment-title i {
                font-size: 2rem;
                color: var(--eksa-gold);
                background: rgba(196,164,132,0.1);
                padding: 12px;
                border-radius: 15px;
            }
            
            .payment-title h3 {
                color: var(--eksa-navy);
                font-size: 1.8rem;
                margin: 0;
            }
            
            .payment-options {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 25px;
                margin-bottom: 25px;
            }
            
            .payment-card {
                background: white;
                border-radius: 20px;
                padding: 25px;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s ease;
                border: 2px solid rgba(196,164,132,0.2);
                position: relative;
            }
            
            .payment-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            }
            
            .payment-card.selected {
                border: 2px solid var(--eksa-gold);
                background: rgba(196,164,132,0.05);
                box-shadow: 0 0 0 3px var(--eksa-gold-glow);
            }
            
            .payment-card img {
                width: 80px;
                height: 80px;
                object-fit: contain;
                margin-bottom: 15px;
            }
            
            .payment-card i {
                font-size: 3rem;
                margin-bottom: 15px;
            }
            
            .payment-card h4 {
                color: var(--eksa-navy);
                font-size: 1.2rem;
                margin-bottom: 5px;
            }
            
            .payment-card p {
                color: var(--eksa-navy-light);
                font-size: 0.85rem;
                margin: 0;
            }
            
            .payment-card .check-icon {
                position: absolute;
                top: 15px;
                right: 15px;
                color: var(--eksa-success);
                font-size: 1.2rem;
                display: none;
            }
            
            .payment-card.selected .check-icon {
                display: block;
            }
            
            .payment-esewa {
                border-top: 5px solid #00B388;
            }
            
            .payment-khalti {
                border-top: 5px solid #5D2E8E;
            }
            
            .payment-cash {
                border-top: 5px solid var(--eksa-gold);
            }
            
            .payment-details {
                background: white;
                border-radius: 15px;
                padding: 25px;
                margin-top: 20px;
                display: none;
            }
            
            .payment-details.active {
                display: block;
            }
            
            .esewa-details, .khalti-details, .cash-details {
                text-align: center;
            }
            
            .btn-process-payment {
                background: linear-gradient(135deg, var(--eksa-success), #218838);
                color: white;
                border: none;
                padding: 16px 40px;
                border-radius: 50px;
                font-weight: 700;
                font-size: 1.1rem;
                cursor: pointer;
                transition: all 0.3s ease;
                display: inline-flex;
                align-items: center;
                gap: 10px;
                margin-top: 20px;
            }
            
            .btn-process-payment:hover {
                transform: translateY(-3px);
                box-shadow: 0 15px 30px rgba(40,167,69,0.3);
            }
            
            .btn-esewa {
                background: #00B388;
            }
            
            .btn-esewa:hover {
                background: #008F6B;
                box-shadow: 0 15px 30px rgba(0,179,136,0.3);
            }
            
            .btn-khalti {
                background: #5D2E8E;
            }
            
            .btn-khalti:hover {
                background: #4A2370;
                box-shadow: 0 15px 30px rgba(93,46,142,0.3);
            }
            
            .btn-cancel {
                background: transparent;
                color: var(--eksa-navy);
                border: 2px solid var(--eksa-gold);
                padding: 16px 40px;
                border-radius: 50px;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 10px;
            }
            
            .btn-cancel:hover {
                background: var(--eksa-gold);
                color: var(--eksa-navy-dark);
                text-decoration: none;
            }
            
            .payment-warning {
                background: rgba(220,53,69,0.1);
                border-left: 5px solid #dc3545;
                padding: 15px 20px;
                border-radius: 10px;
                margin-bottom: 20px;
                text-align: left;
            }
            
            .payment-warning i {
                color: #dc3545;
                margin-right: 10px;
            }
            
            @media (max-width: 768px) {
                .guest-info-card { flex-direction: column; text-align: center; }
                .guest-avatar { width: 80px; height: 80px; }
                .guest-name { font-size: 1.5rem; }
                .payment-options { grid-template-columns: 1fr; }
            }
        </style>
    </head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand">
                    <i class="fas fa-h-square" style="color: var(--eksa-gold);"></i>
                    Hotel Eksa
                </a>
            </div>
            <ul class="nav navbar-nav pull-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fas fa-user-circle" style="color: var(--eksa-gold);"></i> 
                        <span style="color: white;"><?php echo $name; ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    
    <div class="container-fluid">
        <ul class="nav nav-pills">
            <li><a href="home.php">Dashboard</a></li>
            <li><a href="account.php">Accounts</a></li>
            <li><a href="reserve.php">Pending</a></li>
            <li><a href="checkin.php">Check In</a></li>
            <li class="active"><a href="checkout.php">Check Out</a></li>
            <li><a href="room.php">Rooms</a></li>
            <li><a href="reports.php">Reports</a></li>
        </ul>
    </div>
    
    <br />
    
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-body">
                
                <h2 style="text-align: center; font-family: 'Playfair Display'; margin-bottom: 30px;">
                    ≼ Confirm Check-Out & Payment ≽
                </h2>
                
                <?php
                    if(!isset($_REQUEST['transaction_id'])) {
                        $_SESSION['error_message'] = "No transaction ID provided.";
                        header("location: checkout.php");
                        exit();
                    }
                    
                    $transaction_id = (int)$_REQUEST['transaction_id'];
                    
                    $query = $conn->query("SELECT * FROM `transaction` 
                                          NATURAL JOIN `guest` 
                                          NATURAL JOIN `room` 
                                          WHERE `transaction_id` = '$transaction_id' 
                                          AND `status` = 'Check In'") or die(mysqli_error($conn));
                    
                    if($query->num_rows == 0) {
                        $_SESSION['error_message'] = "Transaction not found or guest already checked out.";
                        header("location: checkout.php");
                        exit();
                    }
                    
                    $fetch = $query->fetch_array();
                    
                    // Calculate bill
                    $room_price = floatval($fetch['price']);
                    $days = intval($fetch['days']) ?: 1;
                    $extra_bed = intval($fetch['extra_bed']) ?: 0;
                    
                    $room_total = $room_price * $days;
                    $extra_bed_total = 800 * $extra_bed;
                    $total_bill = $room_total + $extra_bed_total;
                    
                    $checkin_date = date('M d, Y', strtotime($fetch['checkin']));
                    $checkout_date = date('M d, Y', strtotime($fetch['checkout']));
                    $checkin_time = isset($fetch['checkin_time']) && $fetch['checkin_time'] != '' ? date('h:i A', strtotime($fetch['checkin_time'])) : '2:00 PM';
                    
                    // Generate unique transaction ID for payment
                    $payment_txn_id = 'HOTEL' . date('Ymd') . $transaction_id . rand(100, 999);
                ?>
                
                <!-- GUEST INFORMATION -->
                <div class="guest-info-card">
                    <div class="guest-avatar">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <div>
                        <div class="guest-name">
                            <?php echo $fetch['firstname'] . ' ' . $fetch['lastname']; ?>
                        </div>
                        <div style="display: flex; gap: 20px; margin-top: 10px; flex-wrap: wrap;">
                            <span><i class="fas fa-phone-alt" style="color: var(--eksa-gold);"></i> <?php echo $fetch['contactno']; ?></span>
                            <span><i class="fas fa-map-marker-alt" style="color: var(--eksa-gold);"></i> <?php echo $fetch['address']; ?></span>
                            <span><i class="fas fa-door-open" style="color: var(--eksa-gold);"></i> Room #<?php echo $fetch['room_no']; ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- ROOM INFORMATION -->
                <div class="room-info-card">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h4 style="margin: 0; color: var(--eksa-navy);">
                            <i class="fas fa-bed" style="color: var(--eksa-gold);"></i> 
                            <?php echo $fetch['room_type']; ?>
                        </h4>
                        <span style="background: rgba(40,167,69,0.1); padding: 8px 20px; border-radius: 50px; color: #28a745; border: 1px solid #28a745;">
                            <i class="fas fa-check-circle"></i> Checked In
                        </span>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;">
                        <div>
                            <small style="color: #666;">Check-In Date</small>
                            <h4 style="margin: 5px 0;"><?php echo $checkin_date; ?></h4>
                            <small><?php echo $checkin_time; ?></small>
                        </div>
                        <div>
                            <small style="color: #666;">Check-Out Date</small>
                            <h4 style="margin: 5px 0; color: #dc3545;"><?php echo $checkout_date; ?></h4>
                        </div>
                        <div>
                            <small style="color: #666;">Nights</small>
                            <h4 style="margin: 5px 0;"><?php echo $days; ?> nights</h4>
                        </div>
                        <div>
                            <small style="color: #666;">Extra Bed</small>
                            <h4 style="margin: 5px 0;"><?php echo $extra_bed > 0 ? $extra_bed . ' bed(s)' : 'None'; ?></h4>
                        </div>
                    </div>
                </div>
                
                <!-- BILL SUMMARY -->
                <div class="bill-summary">
                    <h4 style="color: var(--eksa-navy-dark); margin-bottom: 20px;">
                        <i class="fas fa-file-invoice-dollar"></i> Bill Summary
                    </h4>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                        <div>
                            <table style="width: 100%;">
                                <tr>
                                    <td style="padding: 10px 0;">Room Rate (<?php echo $days; ?> nights)</td>
                                    <td style="text-align: right; font-weight: 600;">Rs. <?php echo number_format($room_price, 2); ?> x <?php echo $days; ?></td>
                                    <td style="text-align: right; font-weight: 600;">Rs. <?php echo number_format($room_total, 2); ?></td>
                                </tr>
                                <?php if($extra_bed > 0): ?>
                                <tr>
                                    <td style="padding: 10px 0;">Extra Bed (Rs. 800 x <?php echo $extra_bed; ?>)</td>
                                    <td style="text-align: right; font-weight: 600;">Rs. 800 x <?php echo $extra_bed; ?></td>
                                    <td style="text-align: right; font-weight: 600;">Rs. <?php echo number_format($extra_bed_total, 2); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr style="border-top: 2px solid var(--eksa-gold);">
                                    <td style="padding: 15px 0; font-size: 1.2rem; font-weight: 700;">TOTAL</td>
                                    <td></td>
                                    <td style="text-align: right; font-size: 1.8rem; font-weight: 800; color: var(--eksa-navy-dark);">
                                        Rs. <?php echo number_format($total_bill, 2); ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div style="background: white; padding: 20px; border-radius: 15px;">
                            <h5 style="margin-top: 0; color: var(--eksa-navy);">Payment Summary</h5>
                            <p style="margin: 5px 0;"><strong>Room Charges:</strong> Rs. <?php echo number_format($room_total, 2); ?></p>
                            <?php if($extra_bed > 0): ?>
                            <p style="margin: 5px 0;"><strong>Extra Bed Charges:</strong> Rs. <?php echo number_format($extra_bed_total, 2); ?></p>
                            <?php endif; ?>
                            <hr>
                            <p style="margin: 10px 0; font-size: 1.2rem;"><strong>Amount Due:</strong> Rs. <?php echo number_format($total_bill, 2); ?></p>
                            <span style="background: #ffc107; color: #856404; padding: 5px 15px; border-radius: 50px; display: inline-block;">
                                <i class="fas fa-clock"></i> Awaiting Payment
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- PAYMENT METHODS SECTION -->
                <div class="payment-section">
                    <div class="payment-title">
                        <i class="fas fa-credit-card"></i>
                        <h3>Select Payment Method</h3>
                    </div>
                    
                    <div class="payment-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Important:</strong> Please select a payment method and complete the payment before check-out.
                    </div>
                    
                    <div class="payment-options">
                        <!-- eSewa Payment -->
                        <div class="payment-card payment-esewa" onclick="selectPayment('esewa')" id="esewa-card">
                            <div class="check-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <img src="https://esewa.com.np/common/images/esewa_logo.png" alt="eSewa" style="width: 80px; height: 80px;">
                            <h4>eSewa</h4>
                            <p>Pay via eSewa wallet</p>
                        </div>
                        
                        <!-- Khalti Payment -->
                        <div class="payment-card payment-khalti" onclick="selectPayment('khalti')" id="khalti-card">
                            <div class="check-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <img src="https://dao578ztqooau.cloudfront.net/static/img/logo1.png" alt="Khalti" style="width: 80px; height: 80px;">
                            <h4>Khalti</h4>
                            <p>Pay via Khalti wallet</p>
                        </div>
                        
                        <!-- Cash Payment -->
                        <div class="payment-card payment-cash" onclick="selectPayment('cash')" id="cash-card">
                            <div class="check-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <i class="fas fa-money-bill-wave" style="font-size: 3rem; color: var(--eksa-gold);"></i>
                            <h4>Cash</h4>
                            <p>Pay at front desk</p>
                        </div>
                    </div>
                    
                    <!-- eSewa Payment Details -->
                    <div class="payment-details" id="esewa-details">
                        <div class="esewa-details">
                            <h4 style="color: #00B388; margin-bottom: 20px;">Pay with eSewa</h4>
                            
                            <div style="background: #f8f9fa; padding: 20px; border-radius: 15px; margin-bottom: 20px;">
                                <p style="font-size: 1.2rem; margin-bottom: 10px;"><strong>Amount to Pay:</strong> Rs. <?php echo number_format($total_bill, 2); ?></p>
                                <p style="color: #666;"><i class="fas fa-mobile-alt"></i> eSewa Merchant ID: <strong>HOTEL2024</strong></p>
                            </div>
                            
                            <div style="display: flex; flex-direction: column; align-items: center; gap: 15px;">
                                <p style="color: #666;">1. Open eSewa app on your mobile</p>
                                <p style="color: #666;">2. Go to "Pay" section</p>
                                <p style="color: #666;">3. Enter Merchant ID: <strong>HOTEL2024</strong></p>
                                <p style="color: #666;">4. Enter amount: <strong>Rs. <?php echo number_format($total_bill, 2); ?></strong></p>
                                <p style="color: #666;">5. Complete payment and get transaction ID</p>
                                <p style="color: #666;">6. Enter transaction ID below</p>
                            </div>
                            
                            <form method="POST" action="process_esewa_payment.php" style="margin-top: 25px;">
                                <input type="hidden" name="transaction_id" value="<?php echo $transaction_id; ?>">
                                <input type="hidden" name="bill_amount" value="<?php echo $total_bill; ?>">
                                
                                <div style="margin-bottom: 20px;">
                                    <label style="display: block; text-align: left; margin-bottom: 8px; font-weight: 600;">eSewa Transaction ID:</label>
                                    <input type="text" name="esewa_txn_id" class="form-control" placeholder="Enter eSewa transaction ID" required style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 10px;">
                                </div>
                                
                                <button type="submit" name="process_esewa" class="btn-process-payment btn-esewa">
                                    <i class="fas fa-check-circle"></i> VERIFY & COMPLETE PAYMENT
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Khalti Payment Details -->
                    <div class="payment-details" id="khalti-details">
                        <div class="khalti-details">
                            <h4 style="color: #5D2E8E; margin-bottom: 20px;">Pay with Khalti</h4>
                            
                            <div style="background: #f8f9fa; padding: 20px; border-radius: 15px; margin-bottom: 20px;">
                                <p style="font-size: 1.2rem; margin-bottom: 10px;"><strong>Amount to Pay:</strong> Rs. <?php echo number_format($total_bill, 2); ?></p>
                                <p style="color: #666;"><i class="fas fa-wallet"></i> Khalti Integration</p>
                            </div>
                            
                            <p style="color: #666; margin-bottom: 20px;">Click the button below to pay with Khalti wallet</p>
                            
                            <button class="btn-process-payment btn-khalti" onclick="initiateKhaltiPayment(<?php echo $total_bill; ?>, '<?php echo $payment_txn_id; ?>', <?php echo $transaction_id; ?>)">
                                <i class="fas fa-wallet"></i> PAY WITH KHALTI
                            </button>
                        </div>
                    </div>
                    
                    <!-- Cash Payment Details -->
                    <div class="payment-details" id="cash-details">
                        <div class="cash-details">
                            <i class="fas fa-money-bill-wave" style="font-size: 4rem; color: var(--eksa-gold); margin-bottom: 20px;"></i>
                            <h4 style="color: var(--eksa-navy); margin-bottom: 20px;">Cash Payment</h4>
                            
                            <div style="background: #f8f9fa; padding: 20px; border-radius: 15px; margin-bottom: 20px;">
                                <p style="font-size: 1.2rem; margin-bottom: 10px;"><strong>Amount to Collect:</strong> Rs. <?php echo number_format($total_bill, 2); ?></p>
                            </div>
                            
                            <p style="color: #666; margin-bottom: 10px;">✓ Collect cash payment from guest at front desk</p>
                            <p style="color: #666; margin-bottom: 20px;">✓ Confirm receipt of payment before check-out</p>
                            
                            <form method="POST" action="process_cash_payment.php" style="display: inline-block;">
                                <input type="hidden" name="transaction_id" value="<?php echo $transaction_id; ?>">
                                <input type="hidden" name="bill_amount" value="<?php echo $total_bill; ?>">
                                <input type="hidden" name="payment_method" value="Cash">
                                <input type="hidden" name="cash_received" value="1">
                                
                                <button type="submit" name="confirm_cash_payment" class="btn-process-payment">
                                    <i class="fas fa-check-circle"></i> CONFIRM CASH RECEIVED & CHECK-OUT
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div style="display: flex; gap: 20px; justify-content: center; margin-top: 20px;">
                    <a href="checkin.php" class="btn-cancel">
                        <i class="fas fa-times-circle"></i> CANCEL
                    </a>
                </div>
                
            </div>
        </div>
    </div>
    
    <div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
        <label>HOTEL EKSA • CHECK-OUT & PAYMENT • EST. 2024 </label>
        <div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
            <i class="fas fa-credit-card"></i> Processing payment for: <?php echo $fetch['firstname'] . ' ' . $fetch['lastname']; ?> <i class="fas fa-credit-card"></i>
        </div>
    </div>
    
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script>
        // Select payment method
        function selectPayment(method) {
            // Remove selected class from all cards
            document.getElementById('esewa-card').classList.remove('selected');
            document.getElementById('khalti-card').classList.remove('selected');
            document.getElementById('cash-card').classList.remove('selected');
            
            // Hide all payment details
            document.getElementById('esewa-details').classList.remove('active');
            document.getElementById('khalti-details').classList.remove('active');
            document.getElementById('cash-details').classList.remove('active');
            
            // Add selected class to chosen card and show details
            if (method === 'esewa') {
                document.getElementById('esewa-card').classList.add('selected');
                document.getElementById('esewa-details').classList.add('active');
            } else if (method === 'khalti') {
                document.getElementById('khalti-card').classList.add('selected');
                document.getElementById('khalti-details').classList.add('active');
            } else if (method === 'cash') {
                document.getElementById('cash-card').classList.add('selected');
                document.getElementById('cash-details').classList.add('active');
            }
        }
        
        // Khalti Payment Integration
        function initiateKhaltiPayment(amount, txnId, transactionId) {
            var config = {
                // Replace with your Khalti public key
                "publicKey": "test_public_key_dc74e0fd57cb46cd93832aee0a390234",
                "productIdentity": txnId,
                "productName": "Hotel Eksa - Room Payment",
                "productUrl": "http://localhost/Online_Hotel_Reservation/",
                "paymentPreference": [
                    "KHALTI",
                    "EBANKING",
                    "MOBILE_BANKING",
                    "CONNECT_IPS",
                    "SCT",
                ],
                "eventHandler": {
                    onSuccess: function(payload) {
                        // Payment successful
                        console.log(payload);
                        
                        // Send payment data to server
                        $.ajax({
                            url: "process_khalti_payment.php",
                            type: "POST",
                            data: {
                                transaction_id: transactionId,
                                bill_amount: amount,
                                khalti_token: payload.token,
                                khalti_amount: payload.amount,
                                khalti_txn_id: payload.transaction_id,
                                khalti_mobile: payload.mobile
                            },
                            success: function(response) {
                                var data = JSON.parse(response);
                                if (data.status === 'success') {
                                    swal({
                                        title: 'Payment Successful!',
                                        text: 'Guest has been checked out successfully.',
                                        icon: 'success',
                                        button: 'OK'
                                    }).then(() => {
                                        window.location.href = 'checkout.php';
                                    });
                                } else {
                                    swal({
                                        title: 'Payment Failed',
                                        text: data.message,
                                        icon: 'error',
                                        button: 'OK'
                                    });
                                }
                            },
                            error: function(error) {
                                swal({
                                    title: 'Payment Failed',
                                    text: 'There was an error processing your payment.',
                                    icon: 'error',
                                    button: 'OK'
                                });
                            }
                        });
                    },
                    onError: function(error) {
                        console.log(error);
                        swal({
                            title: 'Payment Failed',
                            text: 'You cancelled the payment or it failed.',
                            icon: 'error',
                            button: 'OK'
                        });
                    },
                    onClose: function() {
                        console.log('Payment widget closed');
                    }
                }
            };
            
            var checkout = new KhaltiCheckout(config);
            checkout.show({amount: amount * 100}); // Amount in paisa (multiply by 100)
        }
    </script>
</body>
</html>