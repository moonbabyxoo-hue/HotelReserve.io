<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Edit Account</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - EDIT ACCOUNT ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
				--eksa-warning: #ffc107;
				--eksa-warning-dark: #e0a800;
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 80px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 30px !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY DROPDOWN MENU ===== */
			.dropdown-menu {
				background: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				border-radius: 15px;
				box-shadow: 0 15px 40px var(--eksa-shadow-dark);
				padding: 10px;
			}
			
			.dropdown-menu li a {
				color: var(--eksa-navy);
				padding: 10px 20px;
				border-radius: 10px;
				transition: all 0.3s ease;
			}
			
			.dropdown-menu li a:hover {
				background: rgba(196, 164, 132, 0.1);
				color: var(--eksa-gold-dark);
			}
			
			.dropdown-menu li a i {
				color: var(--eksa-gold);
				margin-right: 10px;
			}
			
			/* ===== LUXURY NAV PILLS ===== */
			.nav-pills {
				margin: 20px 0;
				display: flex;
				flex-wrap: wrap;
				gap: 10px;
			}
			
			.nav-pills li {
				margin: 0;
			}
			
			.nav-pills li a {
				background: var(--eksa-white);
				color: var(--eksa-navy);
				padding: 12px 25px;
				border-radius: 50px;
				font-weight: 600;
				transition: all 0.3s ease;
				border: 2px solid rgba(196, 164, 132, 0.2);
				text-decoration: none;
				display: inline-block;
			}
			
			.nav-pills li a:hover {
				background: rgba(196, 164, 132, 0.1);
				border-color: var(--eksa-gold);
				transform: translateY(-2px);
			}
			
			.nav-pills li.active a {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border-color: var(--eksa-white);
			}
			
			/* ===== LUXURY PANEL ===== */
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white);
				border-radius: 30px;
				padding: 40px;
				box-shadow: 0 30px 60px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			/* ===== PAGE HEADER ===== */
			.page-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 30px;
				flex-wrap: wrap;
				gap: 20px;
			}
			
			.page-title {
				display: flex;
				align-items: center;
				gap: 15px;
			}
			
			.page-title i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
				background: rgba(196, 164, 132, 0.1);
				padding: 15px;
				border-radius: 20px;
			}
			
			.page-title h2 {
				color: var(--eksa-navy);
				font-size: 2rem;
				margin: 0;
			}
			
			.page-title p {
				color: var(--eksa-navy-light);
				margin: 5px 0 0;
				font-size: 0.95rem;
			}
			
			/* ===== LUXURY ALERT ===== */
			.alert-info {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border: none;
				border-radius: 15px;
				padding: 20px 25px;
				font-size: 1.1rem;
				font-weight: 600;
				margin-bottom: 30px;
				border-left: 5px solid var(--eksa-white);
				display: flex;
				align-items: center;
				gap: 15px;
			}
			
			.alert-info i {
				color: var(--eksa-navy-dark);
				font-size: 1.5rem;
			}
			
			/* ===== FORM STYLES ===== */
			.form-container {
				max-width: 600px;
				margin: 0 auto;
			}
			
			.form-group {
				margin-bottom: 25px;
			}
			
			.form-group label {
				display: block;
				margin-bottom: 12px;
				font-weight: 600;
				color: var(--eksa-navy);
				font-size: 0.95rem;
				letter-spacing: 1px;
			}
			
			.form-group label i {
				color: var(--eksa-gold);
				margin-right: 10px;
			}
			
			.input-wrapper {
				position: relative;
				display: flex;
				align-items: center;
			}
			
			.input-icon {
				position: absolute;
				left: 15px;
				color: var(--eksa-gold);
				font-size: 1.1rem;
				z-index: 10;
			}
			
			.form-control {
				width: 100%;
				padding: 15px 20px 15px 45px;
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 15px;
				font-size: 1rem;
				transition: all 0.3s ease;
				background: var(--eksa-cream);
				font-family: 'Poppins', sans-serif;
				color: var(--eksa-navy);
			}
			
			.form-control:focus {
				outline: none;
				border-color: var(--eksa-gold);
				box-shadow: 0 0 0 5px var(--eksa-gold-glow);
				background: var(--eksa-white);
				transform: translateY(-2px);
			}
			
			.form-control[readonly] {
				background: rgba(196, 164, 132, 0.05);
				cursor: not-allowed;
			}
			
			.password-toggle {
				position: absolute;
				right: 15px;
				color: var(--eksa-gold);
				cursor: pointer;
				z-index: 20;
				font-size: 1.1rem;
				transition: color 0.3s ease;
			}
			
			.password-toggle:hover {
				color: var(--eksa-gold-dark);
			}
			
			/* ===== ACCOUNT INFO CARD ===== */
			.account-info-card {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				border-radius: 20px;
				padding: 25px;
				color: white;
				margin-bottom: 30px;
				border-left: 5px solid var(--eksa-gold);
			}
			
			.account-info-card h5 {
				color: var(--eksa-gold);
				font-size: 1.2rem;
				margin-bottom: 15px;
				display: flex;
				align-items: center;
				gap: 10px;
			}
			
			.info-row {
				display: flex;
				margin-bottom: 10px;
				padding: 8px 0;
				border-bottom: 1px solid rgba(255,255,255,0.1);
			}
			
			.info-label {
				width: 100px;
				color: var(--eksa-gold-light);
				font-weight: 500;
			}
			
			.info-value {
				flex: 1;
				color: white;
				font-weight: 600;
			}
			
			/* ===== BUTTON STYLES ===== */
			.btn-save {
				background: linear-gradient(135deg, var(--eksa-warning), var(--eksa-warning-dark));
				color: var(--eksa-navy-dark);
				border: none;
				padding: 16px 30px;
				border-radius: 50px;
				font-size: 1.1rem;
				font-weight: 700;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				width: 100%;
				position: relative;
				overflow: hidden;
				z-index: 1;
				border: 2px solid transparent;
				display: flex;
				align-items: center;
				justify-content: center;
				gap: 12px;
			}
			
			.btn-save::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				transition: left 0.4s ease;
				z-index: -1;
			}
			
			.btn-save:hover::before {
				left: 0;
			}
			
			.btn-save:hover {
				color: var(--eksa-navy-dark);
				border-color: var(--eksa-white);
				transform: translateY(-3px);
				box-shadow: 0 15px 30px rgba(255, 193, 7, 0.3);
			}
			
			.btn-cancel {
				background: transparent;
				color: var(--eksa-navy);
				border: 2px solid var(--eksa-gold);
				padding: 16px 30px;
				border-radius: 50px;
				font-size: 1rem;
				font-weight: 600;
				transition: all 0.3s ease;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				gap: 10px;
				text-decoration: none;
				width: 100%;
				margin-top: 15px;
			}
			
			.btn-cancel:hover {
				background: var(--eksa-gold);
				color: var(--eksa-navy-dark);
				transform: translateY(-2px);
				text-decoration: none;
			}
			
			/* ===== PASSWORD REQUIREMENTS ===== */
			.password-requirements {
				margin-top: 15px;
				padding: 15px;
				background: rgba(196, 164, 132, 0.05);
				border-radius: 12px;
				font-size: 0.85rem;
			}
			
			.password-requirements p {
				color: var(--eksa-navy-light);
				margin-bottom: 8px;
			}
			
			.requirement-item {
				display: flex;
				align-items: center;
				gap: 8px;
				margin-bottom: 5px;
				color: var(--eksa-navy-light);
			}
			
			.requirement-item i {
				color: var(--eksa-gold);
				font-size: 0.8rem;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 768px) {
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.nav-pills {
					flex-direction: column;
				}
				
				.nav-pills li a {
					display: block;
					text-align: center;
				}
				
				.panel-body {
					padding: 30px;
				}
				
				.page-header {
					flex-direction: column;
					align-items: flex-start;
				}
				
				.page-title h2 {
					font-size: 1.6rem;
				}
				
				.col-md-4 {
					width: 100% !important;
					padding: 0 !important;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 30px !important;
				padding-right: 30px !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
			
			.col-md-4 {
				width: 100%;
				max-width: 600px;
				margin: 0 auto;
				float: none;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
			<ul class = "nav navbar-nav pull-right">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						<i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
						<span style="color: var(--eksa-white); font-weight: 600;"><?php echo $name; ?></span>
						<span class="caret" style="color: var(--eksa-gold);"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
						<li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
						<li class="divider"></li>
						<li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	
	<!-- LUXURY NAVIGATION PILLS -->
	<div class = "container-fluid">
		<ul class = "nav nav-pills">
			<li><a href = "home.php"><i class="fas fa-home me-2"></i> Dashboard</a></li>
			<li class = "active"><a href = "account.php"><i class="fas fa-users-cog me-2"></i> Accounts</a></li>
			<li><a href = "reserve.php"><i class="fas fa-calendar-check me-2"></i> Reservations</a></li>
			<li><a href = "room.php"><i class="fas fa-bed me-2"></i> Rooms</a></li>
			<li><a href = "reports.php"><i class="fas fa-chart-line me-2"></i> Reports</a></li>
		</ul>
	</div>
	
	<br />
	
	<!-- LUXURY EDIT ACCOUNT CONTENT -->
	<div class = "container-fluid">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- PAGE HEADER -->
				<div class="page-header">
					<div class="page-title">
						<i class="fas fa-user-edit"></i>
						<div>
							<h2>Edit Account</h2>
							<p>Update administrator account information</p>
						</div>
					</div>
					<a href="account.php" style="color: var(--eksa-gold-dark); font-size: 1rem; text-decoration: none;">
						<i class="fas fa-arrow-left"></i> Back to Accounts
					</a>
				</div>
				
				<?php
					// Check if admin_id is set
					if(!isset($_REQUEST['admin_id'])) {
						echo '<script>window.location.href="account.php";</script>';
						exit();
					}
					
					$query = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_REQUEST[admin_id]'") or die(mysqli_error($conn));
					
					if($query->num_rows == 0) {
						echo '<script>window.location.href="account.php";</script>';
						exit();
					}
					
					$fetch = $query->fetch_array();
					
					// Determine role
					$role = ($fetch['admin_id'] == 1) ? 'Super Admin' : (($fetch['admin_id'] <= 3) ? 'Manager' : 'Staff');
					$is_protected = ($fetch['admin_id'] == 1);
				?>
				
				<!-- ACCOUNT INFO CARD -->
				<div class="account-info-card">
					<h5><i class="fas fa-id-card"></i> Account Information</h5>
					<div class="info-row">
						<span class="info-label">Account ID:</span>
						<span class="info-value"><?php echo $fetch['admin_id']; ?></span>
					</div>
					<div class="info-row">
						<span class="info-label">Role:</span>
						<span class="info-value">
							<?php if($role == 'Super Admin'): ?>
								<i class="fas fa-crown" style="color: var(--eksa-gold);"></i> Super Administrator
							<?php elseif($role == 'Manager'): ?>
								<i class="fas fa-user-tie" style="color: var(--eksa-gold);"></i> Manager
							<?php else: ?>
								<i class="fas fa-user" style="color: var(--eksa-gold);"></i> Staff
							<?php endif; ?>
						</span>
					</div>
					<?php if($is_protected): ?>
					<div class="info-row">
						<span class="info-label">Status:</span>
						<span class="info-value"><span style="color: var(--eksa-gold);">🔒 Protected Account</span> - Cannot be deleted</span>
					</div>
					<?php endif; ?>
				</div>

				<!-- Add this after the page header and before the form -->
<?php
if (isset($_SESSION['error_message'])) {
    echo '<div style="background: rgba(220,53,69,0.1); border-left: 5px solid #dc3545; border-radius: 10px; padding: 15px 20px; margin-bottom: 30px; display: flex; align-items: center; gap: 15px;">';
    echo '<i class="fas fa-exclamation-circle" style="color: #dc3545; font-size: 1.5rem;"></i>';
    echo '<div><h5 style="color: #dc3545; margin: 0 0 5px;">Error</h5>';
    echo '<p style="color: var(--eksa-navy); margin: 0;">' . $_SESSION['error_message'] . '</p></div>';
    echo '</div>';
    unset($_SESSION['error_message']);
}

if (isset($_SESSION['success_message'])) {
    echo '<div style="background: rgba(40,167,69,0.1); border-left: 5px solid #28a745; border-radius: 10px; padding: 15px 20px; margin-bottom: 30px; display: flex; align-items: center; gap: 15px;">';
    echo '<i class="fas fa-check-circle" style="color: #28a745; font-size: 1.5rem;"></i>';
    echo '<div><h5 style="color: #28a745; margin: 0 0 5px;">Success</h5>';
    echo '<p style="color: var(--eksa-navy); margin: 0;">' . $_SESSION['success_message'] . '</p></div>';
    echo '</div>';
    unset($_SESSION['success_message']);
}
?>
				
				<div class="alert-info">
					<i class="fas fa-exclamation-triangle"></i> 
					<?php echo $is_protected ? 'Editing Super Admin Account - Proceed with caution' : 'Editing Administrator Account'; ?>
				</div>
				
				<div class="form-container">
					<form method = "POST" action = "edit_query_account.php?admin_id=<?php echo $fetch['admin_id']?>" id="editAccountForm">
						<div class = "form-group">
							<label><i class="fas fa-user"></i> Full Name</label>
							<div class="input-wrapper">
								<i class="fas fa-user input-icon"></i>
								<input type = "text" class = "form-control" value = "<?php echo htmlspecialchars($fetch['name']); ?>" name = "name" required placeholder="Enter full name" />
							</div>
						</div>
						
						<div class = "form-group">
							<label><i class="fas fa-at"></i> Username</label>
							<div class="input-wrapper">
								<i class="fas fa-at input-icon"></i>
								<input type = "text" class = "form-control" value = "<?php echo htmlspecialchars($fetch['username']); ?>" name = "username" required placeholder="Enter username" />
							</div>
						</div>
						
						<div class = "form-group">
							<label><i class="fas fa-lock"></i> Password</label>
							<div class="input-wrapper">
								<i class="fas fa-lock input-icon"></i>
								<input type = "password" class = "form-control" value = "<?php echo htmlspecialchars($fetch['password']); ?>" name = "password" id="password" placeholder="Leave blank to keep current password" />
								<i class="fas fa-eye password-toggle" onclick="togglePassword()" id="toggleIcon"></i>
							</div>
							<div class="password-requirements">
								<p><i class="fas fa-info-circle" style="color: var(--eksa-gold);"></i> Password Requirements:</p>
								<div class="requirement-item">
									<i class="fas fa-check-circle"></i> Leave blank to keep current password
								</div>
								<div class="requirement-item">
									<i class="fas fa-check-circle"></i> Minimum 8 characters
								</div>
								<div class="requirement-item">
									<i class="fas fa-check-circle"></i> At least one uppercase letter
								</div>
								<div class="requirement-item">
									<i class="fas fa-check-circle"></i> At least one number
								</div>
							</div>
						</div>
						
						<hr style="border: 1px solid rgba(196,164,132,0.2); margin: 30px 0;" />
						
						<div class = "form-group">
							<button type="submit" name = "edit_account" class = "btn-save">
								<i class = "fas fa-save"></i> SAVE CHANGES
							</button>
							<a href="account.php" class = "btn-cancel">
								<i class = "fas fa-times-circle"></i> CANCEL
							</a>
						</div>
					</form>
				</div>
				
				<!-- AUDIT LOG NOTE -->
				<div style="margin-top: 30px; padding: 15px; background: rgba(196,164,132,0.03); border-radius: 10px; text-align: center;">
					<p style="color: var(--eksa-navy-light); margin: 0; font-size: 0.85rem;">
						<i class="fas fa-shield-alt" style="color: var(--eksa-gold);"></i> 
						All account changes are logged for security purposes. 
						Last modified: <?php echo date('F d, Y h:i A'); ?>
					</p>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • MANAGEMENT SYSTEM • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-shield-alt"></i> Editing Account: <?php echo htmlspecialchars($fetch['username']); ?> <i class="fas fa-shield-alt"></i>
		</div>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script>
	// Toggle password visibility
	function togglePassword() {
		var passwordField = document.getElementById("password");
		var toggleIcon = document.getElementById("toggleIcon");
		
		if (passwordField.type === "password") {
			passwordField.type = "text";
			toggleIcon.classList.remove("fa-eye");
			toggleIcon.classList.add("fa-eye-slash");
		} else {
			passwordField.type = "password";
			toggleIcon.classList.remove("fa-eye-slash");
			toggleIcon.classList.add("fa-eye");
		}
	}
	
	// Form validation
	document.addEventListener('DOMContentLoaded', function() {
		var form = document.getElementById('editAccountForm');
		
		form.addEventListener('submit', function(e) {
			var name = document.querySelector('input[name="name"]').value.trim();
			var username = document.querySelector('input[name="username"]').value.trim();
			var password = document.querySelector('input[name="password"]').value;
			
			if (name === '' || username === '') {
				e.preventDefault();
				swal({
					title: 'Validation Error',
					text: 'Name and Username cannot be empty!',
					icon: 'error',
					button: 'OK'
				});
				return false;
			}
			
			// Only validate password if it's being changed
			if (password !== '' && password.length < 8) {
				e.preventDefault();
				swal({
					title: 'Password Too Short',
					text: 'Password must be at least 8 characters long!',
					icon: 'error',
					button: 'OK'
				});
				return false;
			}
			
			// Confirm save
			e.preventDefault();
			swal({
				title: 'Save Changes?',
				text: 'Are you sure you want to update this account?',
				icon: 'warning',
				buttons: ['Cancel', 'Save'],
				dangerMode: false,
			}).then((willSave) => {
				if (willSave) {
					form.submit();
				}
			});
		});
		
		// Animation for form fields
		var formGroups = document.querySelectorAll('.form-group');
		formGroups.forEach(function(group, index) {
			group.style.opacity = '0';
			group.style.transform = 'translateY(20px)';
			
			setTimeout(function() {
				group.style.transition = 'all 0.5s ease';
				group.style.opacity = '1';
				group.style.transform = 'translateY(0)';
			}, 100 * index);
		});
	});
</script>
</html>