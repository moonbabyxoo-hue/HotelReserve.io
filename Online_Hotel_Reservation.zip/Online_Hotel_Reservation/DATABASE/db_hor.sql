-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2026 at 12:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hor`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `username` varchar(24) NOT NULL,
  `password` varchar(24) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Staff'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `username`, `password`, `role`) VALUES
(1, 'Administrator', 'Admin', 'admin', 'Super Admin'),
(2, 'Pujan', 'Pujan@gmail.com', 'Pujan1234', 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `guest_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `lastname` varchar(40) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contactno` varchar(13) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_id`, `firstname`, `middlename`, `lastname`, `address`, `contactno`, `email`, `password`, `created_at`) VALUES
(1, 'User', '1', 'Test', 'USA', '9811111111', NULL, NULL, '2026-02-11 21:54:55'),
(2, 'User', '1', 'Test', 'USA', '9811111111', NULL, NULL, '2026-02-11 21:54:55'),
(3, 'User1', '1', 'Test1', 'London', '9811111111', NULL, NULL, '2026-02-11 21:54:55'),
(4, 'Testing', '1', 'User', 'Khairahani', '9877777777', NULL, '$2y$10$.jD0EFhoUyjviWk3Bvg2lOrk1CNLAANUrJwLFAUY8ejqv7n8msWpa', '2026-02-11 21:54:55'),
(5, 'Maybeeeee', '1', 'User', 'Khairahani', '986666666', NULL, NULL, '2026-02-11 21:54:55'),
(6, 'Hainaaaa', '2', 'Holaaa', 'America', '9899999999', NULL, NULL, '2026-02-11 21:54:55'),
(7, 'Test', '1', 'NO1', 'Sungava', '9833333333', NULL, NULL, '2026-02-11 21:54:55'),
(8, 'Aadarsha', 'Kumar', 'Jha', 'Parsa', '9855555555', NULL, NULL, '2026-02-11 21:54:55'),
(9, '1', '1', '1', '1', '1', NULL, NULL, '2026-02-11 21:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_txn_id` varchar(100) DEFAULT NULL,
  `khalti_mobile` varchar(20) DEFAULT NULL,
  `payment_status` varchar(20) NOT NULL,
  `payment_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `transaction_id`, `amount`, `payment_method`, `payment_txn_id`, `khalti_mobile`, `payment_status`, `payment_date`) VALUES
(1, 14, 3800.00, 'Cash', 'CASH2026021114485', NULL, 'Completed', '2026-02-12 02:32:13');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `reservation_code` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `room_id` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_price` decimal(10,2) NOT NULL,
  `checkin_date` date NOT NULL,
  `nights` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `service_charge` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL,
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `invoice_number`, `reservation_code`, `fullname`, `firstname`, `middlename`, `lastname`, `address`, `contactno`, `room_id`, `room_type`, `room_price`, `checkin_date`, `nights`, `subtotal`, `service_charge`, `tax`, `total`, `status`, `booking_date`) VALUES
(7, 'INV-20260211-0430', 'EKS698C9FD6061BD', 'Genesis 1 Innovation', 'Genesis', '1', 'Innovation', 'parsa', '9811111111', 3, 'Super Deluxe', 2800.00, '2026-02-12', 1, 2800.00, 280.00, 336.00, 3416.00, 'Confirmed', '2026-02-11 15:27:18'),
(8, 'INV-20260211-9196', 'EKS698CA2A437A43', 'Genesis 1 Innovation', 'Genesis', '1', 'Innovation', 'parsa', '9811111111', 3, 'Super Deluxe', 2800.00, '2026-02-12', 1, 2800.00, 280.00, 336.00, 3416.00, 'Confirmed', '2026-02-11 15:39:16'),
(9, 'INV-20260211-5239', 'EKS698CA2DAA7F0E', 'Genesis 1 Innovation', 'Genesis', '1', 'Innovation', 'parsa', '9811111111', 3, 'Super Deluxe', 2800.00, '2026-02-17', 5, 14000.00, 1400.00, 1680.00, 17080.00, 'Confirmed', '2026-02-11 15:40:10'),
(10, 'INV-20260211-9149', 'EKS698CA2FA8C4E0', 'Genesis 1 Innovation', 'Genesis', '1', 'Innovation', 'parsa', '9811111111', 3, 'Super Deluxe', 2800.00, '2026-02-17', 5, 14000.00, 1400.00, 1680.00, 17080.00, 'Confirmed', '2026-02-11 15:40:42'),
(11, 'INV-20260211-4092', 'EKS698CD36BEEDF3', 'Testing 1 User', 'Testing', '1', 'User', 'Khairahani', '9877777777', 5, 'Executive Suite', 4000.00, '2026-02-13', 1, 4000.00, 400.00, 480.00, 4880.00, 'Confirmed', '2026-02-11 19:07:23'),
(12, 'INV-20260211-1285', 'EKS698CD82E0C265', 'Testing 1 User', 'Testing', '1', 'User', 'Khairahani', '9877777777', 5, 'Executive Suite', 4000.00, '2026-02-13', 1, 4000.00, 400.00, 480.00, 4880.00, 'Confirmed', '2026-02-11 19:27:42'),
(13, 'INV-20260211-6196', 'EKS698CDB6C792E9', 'Horwwwww 1 User', 'Horwwwww', '1', 'User', 'Khairahani', '9877777777', 3, 'Super Deluxe', 2800.00, '2026-02-28', 1, 2800.00, 280.00, 336.00, 3416.00, 'Pending', '2026-02-11 19:41:32'),
(14, 'INV-20260211-8759', 'EKS698CDBC954B37', 'Hainaaaaaa 1 User', 'Hainaaaaaa', '1', 'User', 'Khairahani', '9877777777', 3, 'Super Deluxe', 2800.00, '2026-02-28', 1, 2800.00, 280.00, 336.00, 3416.00, 'Pending', '2026-02-11 19:43:05'),
(15, 'INV-20260211-7132', 'EKS698CDC00CC70F', 'Maybeeeee 1 User', 'Maybeeeee', '1', 'User', 'Khairahani', '9877777777', 2, 'Superior', 2400.00, '2026-02-28', 1, 2400.00, 240.00, 288.00, 2928.00, 'Pending', '2026-02-11 19:44:00'),
(16, 'INV-20260211-0012', 'EKS20260211000012', 'Maybeeeee 1 User', 'Maybeeeee', '1', 'User', 'Khairahani', '986666666', 2, 'Superior', 2400.00, '2026-02-26', 1, 2400.00, 240.00, 288.00, 2928.00, 'Pending', '2026-02-11 19:46:13'),
(17, 'INV-20260211-0013', 'EKS20260211000013', 'Hainaaaa 2 Holaaa', 'Hainaaaa', '2', 'Holaaa', 'America', '9899999999', 2, 'Superior', 2400.00, '2026-02-26', 1, 2400.00, 240.00, 288.00, 2928.00, 'Pending', '2026-02-11 19:47:02'),
(18, 'INV-20260211-0014', 'EKS20260211000014', 'Test 1 NO1', 'Test', '1', 'NO1', 'Sungava', '9833333333', 4, 'Jr. Suite', 3800.00, '2026-02-13', 1, 3800.00, 380.00, 456.00, 4636.00, 'Pending', '2026-02-11 20:22:33'),
(19, 'INV-20260211-0015', 'EKS20260211000015', 'Aadarsha Kumar Jha', 'Aadarsha', 'Kumar', 'Jha', 'Parsa', '9855555555', 3, 'Super Deluxe', 2800.00, '2026-02-14', 1, 2800.00, 280.00, 336.00, 3416.00, 'Pending', '2026-02-11 20:48:52'),
(20, 'INV-20260211-0016', 'EKS20260211000016', '1 1 1', '1', '1', '1', '1', '1', 2, 'Superior', 2400.00, '2026-02-17', 1, 2400.00, 240.00, 288.00, 2928.00, 'Pending', '2026-02-11 20:52:46');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `price` varchar(11) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_type`, `price`, `photo`) VALUES
(1, 'Standard', '2000', '1.jpg'),
(2, 'Superior', '2400', '3.jpg'),
(3, 'Super Deluxe', '2800', '4.jpg'),
(4, 'Jr. Suite', '3800', '5.jpg'),
(5, 'Executive Suite', '4000', '6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `room_no` int(5) DEFAULT NULL,
  `extra_bed` int(11) DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  `days` int(2) DEFAULT 1,
  `checkin` date NOT NULL,
  `checkin_time` time DEFAULT NULL,
  `checkout` date DEFAULT NULL,
  `checkout_time` time DEFAULT NULL,
  `bill` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `guest_id`, `room_id`, `room_no`, `extra_bed`, `status`, `days`, `checkin`, `checkin_time`, `checkout`, `checkout_time`, `bill`) VALUES
(1, 1, 4, 1, 0, 'Check In', 1, '2026-02-13', '05:51:01', '2026-02-14', '00:00:00', 3800.00),
(12, 5, 2, 1, 0, 'Check Out', 1, '2026-02-26', '04:55:00', '2026-02-27', '05:21:37', 2400.00),
(13, 6, 2, 3, 0, 'Check Out', 1, '2026-02-26', '05:05:40', '2026-02-27', '05:12:41', 2400.00),
(14, 7, 4, 4, 0, 'Check Out', 1, '2026-02-13', '05:22:47', '2026-02-14', '05:47:13', 3800.00),
(15, 8, 3, NULL, 0, 'Pending', 1, '2026-02-14', NULL, '2026-02-15', NULL, NULL),
(16, 9, 2, NULL, 0, 'Pending', 1, '2026-02-17', NULL, '2026-02-18', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `transaction_id` (`transaction_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`),
  ADD UNIQUE KEY `reservation_code` (`reservation_code`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `guest`
--
ALTER TABLE `guest`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`transaction_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
