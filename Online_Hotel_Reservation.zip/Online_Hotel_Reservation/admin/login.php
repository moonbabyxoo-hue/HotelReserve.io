<?php
// ==================== START SESSION AT THE VERY TOP ====================
session_start();
require_once "connect.php";

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_array();
        $_SESSION['admin_id'] = $row['admin_id'];
        $_SESSION['admin_username'] = $row['username'];
        $_SESSION['admin_name'] = $row['name'];
        
        // Redirect to admin dashboard
        header("Location: home.php");
        exit();
    } else {
        $_SESSION['login_error'] = "Invalid username or password";
        header("Location: index.php");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}
?>