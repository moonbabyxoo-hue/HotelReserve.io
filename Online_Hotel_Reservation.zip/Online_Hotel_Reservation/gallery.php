<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Gallery</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Lightbox2 for gallery -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 100px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY GALLERY CONTAINER ===== */
			.container {
				width: 95%;
				max-width: 1400px;
				margin: 40px auto !important;
				padding: 0 !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white) !important;
				padding: 50px !important;
				border-radius: 30px !important;
				box-shadow: 0 30px 60px var(--eksa-shadow) !important;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦✦✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			/* ===== LUXURY GALLERY HEADER ===== */
			.gallery-header {
				text-align: center;
				margin-bottom: 50px;
				position: relative;
			}
			
			.gallery-header h3 {
				font-size: 3rem !important;
				color: var(--eksa-navy) !important;
				margin: 0 0 20px 0 !important;
				position: relative;
				display: inline-block;
			}
			
			.gallery-header h3::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2.5rem;
			}
			
			.gallery-header h3::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2.5rem;
			}
			
			.gallery-header p {
				color: var(--eksa-navy-light);
				font-size: 1.1rem;
				max-width: 600px;
				margin: 0 auto;
			}
			
			/* ===== LUXURY GALLERY FILTER ===== */
			.gallery-filter {
				display: flex;
				justify-content: center;
				flex-wrap: wrap;
				gap: 15px;
				margin-bottom: 40px;
			}
			
			.filter-btn {
				background: transparent;
				border: 2px solid var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 10px 25px;
				border-radius: 50px;
				font-weight: 600;
				cursor: pointer;
				transition: all 0.3s ease;
				font-size: 0.95rem;
			}
			
			.filter-btn:hover,
			.filter-btn.active {
				background: var(--eksa-gold);
				color: var(--eksa-navy-dark);
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			/* ===== LUXURY GALLERY GRID ===== */
			.gallery-grid {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
				gap: 25px;
				margin-top: 30px;
			}
			
			.gallery-item {
				position: relative;
				border-radius: 15px;
				overflow: hidden;
				box-shadow: 0 15px 35px var(--eksa-shadow);
				transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
				aspect-ratio: 1 / 1;
				cursor: pointer;
			}
			
			.gallery-item:hover {
				transform: translateY(-10px) scale(1.02);
				box-shadow: 0 25px 50px var(--eksa-shadow-dark);
			}
			
			.gallery-item img {
				width: 100%;
				height: 100%;
				object-fit: cover;
				transition: transform 0.6s ease;
				display: block;
			}
			
			.gallery-item:hover img {
				transform: scale(1.1);
			}
			
			/* ===== LUXURY GALLERY OVERLAY ===== */
			.gallery-overlay {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: linear-gradient(to top, rgba(10,28,47,0.9), rgba(10,28,47,0.3));
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				opacity: 0;
				transition: all 0.4s ease;
				color: var(--eksa-white);
				padding: 20px;
				text-align: center;
			}
			
			.gallery-item:hover .gallery-overlay {
				opacity: 1;
			}
			
			.gallery-overlay i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
				transform: translateY(20px);
				transition: transform 0.4s ease;
			}
			
			.gallery-item:hover .gallery-overlay i {
				transform: translateY(0);
			}
			
			.gallery-overlay span {
				font-size: 1.1rem;
				font-weight: 600;
				letter-spacing: 2px;
				transform: translateY(20px);
				transition: transform 0.4s ease 0.1s;
			}
			
			.gallery-item:hover .gallery-overlay span {
				transform: translateY(0);
			}
			
			/* ===== LUXURY CATEGORY BADGE ===== */
			.category-badge {
				position: absolute;
				top: 15px;
				left: 15px;
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 6px 15px;
				border-radius: 50px;
				font-size: 0.8rem;
				font-weight: 700;
				z-index: 10;
				letter-spacing: 1px;
				box-shadow: 0 3px 10px rgba(0,0,0,0.2);
			}
			
			/* ===== LUXURY LIGHTBOX CUSTOMIZATION ===== */
			.lb-loader, .lightbox {
				text-align: center !important;
			}
			
			.lb-data .lb-caption {
				font-family: 'Playfair Display', serif !important;
				font-size: 1.2rem !important;
				font-weight: 600 !important;
				color: var(--eksa-gold) !important;
			}
			
			.lb-data .lb-number {
				font-family: 'Poppins', sans-serif !important;
				color: var(--eksa-white) !important;
			}
			
			/* ===== LUXURY EMPTY GALLERY ===== */
			.empty-gallery {
				text-align: center;
				padding: 60px 20px;
				background: var(--eksa-cream);
				border-radius: 20px;
			}
			
			.empty-gallery i {
				font-size: 4rem;
				color: var(--eksa-gold);
				margin-bottom: 20px;
			}
			
			.empty-gallery h4 {
				color: var(--eksa-navy);
				margin-bottom: 10px;
			}
			
			.empty-gallery p {
				color: var(--eksa-navy-light);
			}
			
			/* ===== LUXURY LOAD MORE BUTTON ===== */
			.load-more-container {
				text-align: center;
				margin-top: 50px;
			}
			
			.btn-load-more {
				background: transparent;
				border: 2px solid var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 15px 40px;
				border-radius: 50px;
				font-weight: 700;
				font-size: 1rem;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				position: relative;
				overflow: hidden;
				z-index: 1;
			}
			
			.btn-load-more::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				transition: left 0.4s ease;
				z-index: -1;
			}
			
			.btn-load-more:hover::before {
				left: 0;
			}
			
			.btn-load-more:hover {
				color: var(--eksa-navy-dark);
				border-color: transparent;
				transform: translateY(-3px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
			}
			
			.btn-load-more i {
				margin-right: 10px;
				transition: transform 0.3s ease;
			}
			
			.btn-load-more:hover i {
				transform: translateY(-3px);
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 992px) {
				.panel-body {
					padding: 40px !important;
				}
				
				.gallery-header h3 {
					font-size: 2.5rem !important;
				}
			}
			
			@media (max-width: 768px) {
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li:not(:last-child)::after {
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.panel-body {
					padding: 30px !important;
				}
				
				.gallery-header h3 {
					font-size: 2rem !important;
				}
				
				.gallery-header h3::before,
				.gallery-header h3::after {
					font-size: 1.8rem;
				}
				
				.gallery-grid {
					grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
					gap: 20px;
				}
			}
			
			@media (max-width: 480px) {
				.panel-body {
					padding: 20px !important;
				}
				
				.gallery-grid {
					grid-template-columns: 1fr;
				}
				
				.filter-btn {
					padding: 8px 20px;
					font-size: 0.85rem;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> Admin Login</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> User Login</a></li>
	</ul>
	
	<!-- LUXURY GALLERY CONTENT -->
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- GALLERY HEADER -->
				<div class="gallery-header">
					<strong><h3>Our Gallery</h3></strong>
					<p>Experience the luxury and elegance of Hotel Eksa through our visual journey</p>
				</div>
				
				<!-- GALLERY FILTER -->
				<div class="gallery-filter">
					<button class="filter-btn active" data-filter="all">All</button>
					<button class="filter-btn" data-filter="rooms">Rooms</button>
					<button class="filter-btn" data-filter="dining">Dining</button>
					<button class="filter-btn" data-filter="facilities">Facilities</button>
					<button class="filter-btn" data-filter="exterior">Exterior</button>
				</div>
				
				<!-- GALLERY GRID -->
				<div class="gallery-grid" id="galleryGrid">
					<!-- IMAGE 1 -->
					<div class="gallery-item" data-category="exterior">
						<span class="category-badge">Exterior</span>
						<a href="images/gallery/1.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Grand Exterior">
							<img src="images/gallery/1.jpg" alt="Hotel Eksa Exterior">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Grand Exterior</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 2 -->
					<div class="gallery-item" data-category="rooms">
						<span class="category-badge">Rooms</span>
						<a href="images/gallery/2.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Deluxe Suite">
							<img src="images/gallery/2.jpg" alt="Deluxe Suite">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Deluxe Suite</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 3 -->
					<div class="gallery-item" data-category="dining">
						<span class="category-badge">Dining</span>
						<a href="images/gallery/3.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Fine Dining Restaurant">
							<img src="images/gallery/3.jpg" alt="Fine Dining">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Fine Dining</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 4 -->
					<div class="gallery-item" data-category="facilities">
						<span class="category-badge">Facilities</span>
						<a href="images/gallery/4.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Infinity Pool">
							<img src="images/gallery/4.jpg" alt="Infinity Pool">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Infinity Pool</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 5 -->
					<div class="gallery-item" data-category="exterior">
						<span class="category-badge">Exterior</span>
						<a href="images/gallery/5.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Aerial View">
							<img src="images/gallery/5.jpg" alt="Aerial View">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Aerial View</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 6 -->
					<div class="gallery-item" data-category="rooms">
						<span class="category-badge">Rooms</span>
						<a href="images/gallery/6.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Executive Suite">
							<img src="images/gallery/6.jpg" alt="Executive Suite">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Executive Suite</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 7 -->
					<div class="gallery-item" data-category="facilities">
						<span class="category-badge">Facilities</span>
						<a href="images/gallery/7.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Luxury Spa">
							<img src="images/gallery/7.jpg" alt="Luxury Spa">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Luxury Spa</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 8 -->
					<div class="gallery-item" data-category="dining">
						<span class="category-badge">Dining</span>
						<a href="images/gallery/8.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Lounge Bar">
							<img src="images/gallery/8.jpg" alt="Lounge Bar">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Lounge Bar</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 9 -->
					<div class="gallery-item" data-category="facilities">
						<span class="category-badge">Facilities</span>
						<a href="images/gallery/9.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Fitness Center">
							<img src="images/gallery/9.jpg" alt="Fitness Center">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Fitness Center</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 10 -->
					<div class="gallery-item" data-category="rooms">
						<span class="category-badge">Rooms</span>
						<a href="images/gallery/10.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Standard Room">
							<img src="images/gallery/10.jpg" alt="Standard Room">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Standard Room</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 11 -->
					<div class="gallery-item" data-category="dining">
						<span class="category-badge">Dining</span>
						<a href="images/gallery/11.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Private Dining">
							<img src="images/gallery/11.jpg" alt="Private Dining">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Private Dining</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 12 -->
					<div class="gallery-item" data-category="exterior">
						<span class="category-badge">Exterior</span>
						<a href="images/gallery/12.jpg" data-lightbox="hotel-gallery" data-title="Hotel Eksa - Night View">
							<img src="images/gallery/12.jpg" alt="Night View">
							<div class="gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Night View</span>
							</div>
						</a>
					</div>
				</div>
				
				<!-- LOAD MORE BUTTON -->
				<div class="load-more-container">
					<button class="btn-load-more" id="loadMoreBtn">
						<i class="fas fa-plus-circle"></i> LOAD MORE
					</button>
				</div>
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Created by Pujan Pathak <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script src = "https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<script>
	// Add active class to current menu item
	document.addEventListener('DOMContentLoaded', function() {
		var currentPage = window.location.pathname.split('/').pop();
		var menuItems = document.querySelectorAll('#menu li a');
		
		menuItems.forEach(function(item) {
			if (item.getAttribute('href') === currentPage) {
				item.style.background = 'var(--eksa-gold)';
				item.style.color = 'var(--eksa-navy)';
			}
		});
		
		// Gallery Filter Functionality
		const filterBtns = document.querySelectorAll('.filter-btn');
		const galleryItems = document.querySelectorAll('.gallery-item');
		
		filterBtns.forEach(btn => {
			btn.addEventListener('click', function() {
				// Remove active class from all buttons
				filterBtns.forEach(btn => btn.classList.remove('active'));
				
				// Add active class to clicked button
				this.classList.add('active');
				
				const filterValue = this.getAttribute('data-filter');
				
				galleryItems.forEach(item => {
					if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
						item.style.display = 'block';
						setTimeout(() => {
							item.style.opacity = '1';
							item.style.transform = 'scale(1)';
						}, 10);
					} else {
						item.style.opacity = '0';
						item.style.transform = 'scale(0.8)';
						setTimeout(() => {
							item.style.display = 'none';
						}, 300);
					}
				});
			});
		});
		
		// Load More Functionality
		let visibleCount = 8;
		const loadMoreBtn = document.getElementById('loadMoreBtn');
		const allItems = Array.from(document.querySelectorAll('.gallery-item'));
		
		// Initially hide items beyond visibleCount
		allItems.forEach((item, index) => {
			if (index >= visibleCount) {
				item.style.display = 'none';
			}
		});
		
		if (loadMoreBtn) {
			loadMoreBtn.addEventListener('click', function() {
				const hiddenItems = allItems.filter(item => item.style.display === 'none');
				
				if (hiddenItems.length > 0) {
					// Show next 4 items
					for (let i = 0; i < 4; i++) {
						if (hiddenItems[i]) {
							hiddenItems[i].style.display = 'block';
							setTimeout(() => {
								hiddenItems[i].style.opacity = '1';
								hiddenItems[i].style.transform = 'scale(1)';
							}, 10);
						}
					}
				}
				
				// Hide button if no more items
				if (allItems.filter(item => item.style.display === 'none').length === 0) {
					loadMoreBtn.style.display = 'none';
				}
			});
		}
		
		// Lightbox options
		lightbox.option({
			'resizeDuration': 300,
			'wrapAround': true,
			'albumLabel': 'Image %1 of %2',
			'fadeDuration': 300,
			'imageFadeDuration': 300,
			'positionFromTop': 100
		});
	});
</script>
</html>