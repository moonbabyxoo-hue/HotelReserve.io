<?php
session_start();
require_once 'admin/connect.php';

// Check if form was submitted
if (!isset($_POST['add_guest'])) {
    header("Location: index.php");
    exit();
}

// Get form data
$firstname = trim($_POST['firstname']);
$middlename = trim($_POST['middlename']);
$lastname = trim($_POST['lastname']);
$fullname = $firstname . ' ' . $middlename . ' ' . $lastname;
$address = trim($_POST['address']);
$contactno = trim($_POST['contactno']);
$checkin_date = trim($_POST['date']);
$room_id = isset($_POST['room_id']) ? (int)$_POST['room_id'] : 0;

// Validate inputs
if (empty($firstname) || empty($lastname) || empty($address) || empty($contactno) || empty($checkin_date) || $room_id <= 0) {
    $_SESSION['error_message'] = "Please fill in all required fields.";
    header("Location: add_reserve.php?room_id=" . $room_id);
    exit();
}

// Calculate checkout date (1 day after checkin as default)
$checkout_date = date("Y-m-d", strtotime($checkin_date . " +1 day"));

// ================ FIX: ALWAYS CREATE NEW GUEST RECORD ================
// Instead of checking if guest exists, always create a new guest record
// This ensures each booking has unique guest information

$insert_guest = $conn->query("INSERT INTO `guest` (`firstname`, `middlename`, `lastname`, `address`, `contactno`) 
                              VALUES ('$firstname', '$middlename', '$lastname', '$address', '$contactno')");

if ($insert_guest) {
    $guest_id = $conn->insert_id;
} else {
    $_SESSION['error_message'] = "Failed to create guest record: " . $conn->error;
    header("Location: add_reserve.php?room_id=" . $room_id);
    exit();
}

// Get room details
$room_query = $conn->query("SELECT * FROM `room` WHERE `room_id` = '$room_id'");
if (!$room_query || $room_query->num_rows == 0) {
    $_SESSION['error_message'] = "Room not found.";
    header("Location: index.php");
    exit();
}
$room = $room_query->fetch_array();
$room_type = $room['room_type'];
$room_price = $room['price'];
$room_photo = $room['photo'];

// ==================== INSERT INTO TRANSACTION TABLE ====================
$status = "Pending";
$days = 1;
$extra_bed = 0;
$bill = 0.00;

$transaction_sql = "INSERT INTO `transaction` 
                    (`guest_id`, `room_id`, `room_no`, `extra_bed`, `status`, `days`, `checkin`, `checkin_time`, `checkout`, `checkout_time`, `bill`) 
                    VALUES 
                    ('$guest_id', '$room_id', NULL, '$extra_bed', '$status', '$days', '$checkin_date', NULL, '$checkout_date', NULL, NULL)";

if (!$conn->query($transaction_sql)) {
    $_SESSION['error_message'] = "Error creating transaction: " . $conn->error;
    header("Location: add_reserve.php?room_id=" . $room_id);
    exit();
}

$transaction_id = $conn->insert_id;

// ==================== INSERT INTO RESERVATIONS TABLE (FOR INVOICE) ====================
// Generate unique codes
$invoice_number = 'INV-' . date('Ymd') . '-' . str_pad($transaction_id, 4, '0', STR_PAD_LEFT);
$reservation_code = 'EKS' . date('Ymd') . str_pad($transaction_id, 6, '0', STR_PAD_LEFT);

// Create reservations table if it doesn't exist
$create_table = "CREATE TABLE IF NOT EXISTS `reservations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `invoice_number` VARCHAR(50) UNIQUE NOT NULL,
    `reservation_code` VARCHAR(50) UNIQUE NOT NULL,
    `fullname` VARCHAR(100) NOT NULL,
    `firstname` VARCHAR(50) NOT NULL,
    `middlename` VARCHAR(50),
    `lastname` VARCHAR(50) NOT NULL,
    `address` TEXT NOT NULL,
    `contactno` VARCHAR(20) NOT NULL,
    `room_id` INT NOT NULL,
    `room_type` VARCHAR(50) NOT NULL,
    `room_price` DECIMAL(10,2) NOT NULL,
    `checkin_date` DATE NOT NULL,
    `nights` INT NOT NULL DEFAULT 1,
    `subtotal` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) NOT NULL,
    `tax` DECIMAL(10,2) NOT NULL,
    `total` DECIMAL(10,2) NOT NULL,
    `status` VARCHAR(20) NOT NULL,
    `booking_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($create_table);

// Calculate totals
$subtotal = $room_price * $days;
$service_charge = $subtotal * 0.10;
$tax = $subtotal * 0.12;
$total = $subtotal + $service_charge + $tax;

// Insert into reservations table
$reservation_sql = "INSERT INTO `reservations` 
                    (`invoice_number`, `reservation_code`, `fullname`, `firstname`, `middlename`, `lastname`,
                     `address`, `contactno`, `room_id`, `room_type`, `room_price`, `checkin_date`, `nights`,
                     `subtotal`, `service_charge`, `tax`, `total`, `status`) 
                    VALUES 
                    ('$invoice_number', '$reservation_code', '$fullname', '$firstname', '$middlename', '$lastname',
                     '$address', '$contactno', '$room_id', '$room_type', '$room_price', '$checkin_date', '$days',
                     '$subtotal', '$service_charge', '$tax', '$total', '$status')";

if ($conn->query($reservation_sql)) {
    $reservation_id = $conn->insert_id;
    $_SESSION['success_message'] = "Your reservation has been submitted successfully!";
    $_SESSION['last_reservation'] = $reservation_id;
    
    // Store guest info in session for this booking
    $_SESSION['booking_guest_name'] = $fullname;
    $_SESSION['booking_guest_email'] = ''; // You can add email field if needed
    
    // Redirect to invoice page
    header("Location: invoice.php?reservation_id=" . $reservation_id);
    exit();
} else {
    $_SESSION['error_message'] = "Error creating reservation: " . $conn->error;
    header("Location: add_reserve.php?room_id=" . $room_id);
    exit();
}
?>