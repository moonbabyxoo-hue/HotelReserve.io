<!DOCTYPE html>
<?php
    require_once 'validate.php';
    require 'name.php';
?>
<html lang = "en">
    <head>
        <title>Hotel Eksa - Reports & Analytics</title>
        <meta charset = "utf-8" />
        <meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
        <!-- Font Awesome 6 -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <!-- Chart.js -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
        <!-- Sweet Alert -->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!-- html2pdf for report download -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
        <!-- DataTables -->
        <link rel = "stylesheet" type = "text/css" href = "../css/dataTables.bootstrap.css" />
        <!-- YOUR EXISTING CSS - NO PATH CHANGES -->
        <link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
        
        <style>
            /* ===== HOTEL EKSA LUXURY THEME - REPORTS & ANALYTICS ===== */
            :root {
                --eksa-gold: #C4A484;
                --eksa-gold-light: #E5D3B0;
                --eksa-gold-dark: #A67B5B;
                --eksa-navy: #0A1C2F;
                --eksa-navy-light: #1E3A5F;
                --eksa-navy-dark: #051220;
                --eksa-cream: #FAF7F2;
                --eksa-white: #FFFFFF;
                --eksa-shadow: rgba(10, 28, 47, 0.1);
                --eksa-shadow-dark: rgba(10, 28, 47, 0.2);
                --eksa-gold-glow: rgba(196, 164, 132, 0.3);
                --eksa-success: #28a745;
                --eksa-info: #17a2b8;
                --eksa-warning: #ffc107;
                --eksa-danger: #dc3545;
                --eksa-purple: #6f42c1;
            }
            
            body {
                font-family: 'Poppins', sans-serif;
                background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
                color: var(--eksa-navy);
                overflow-x: hidden;
                padding-bottom: 80px;
            }
            
            h1, h2, h3, h4, h5, h6, .navbar-brand {
                font-family: 'Playfair Display', serif !important;
                font-weight: 700 !important;
            }
            
            /* ===== LUXURY NAVIGATION ===== */
            nav.navbar {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
                border: none !important;
                border-bottom: 3px solid var(--eksa-gold) !important;
                padding: 15px 0 !important;
                margin-bottom: 30px !important;
                box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
            }
            
            .navbar-brand {
                color: var(--eksa-gold) !important;
                font-size: 1.8rem !important;
                letter-spacing: 2px !important;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
                position: relative;
                padding-left: 20px !important;
            }
            
            .navbar-brand::before {
                content: '✦';
                color: var(--eksa-gold);
                font-size: 2rem;
                position: absolute;
                left: -5px;
                top: 5px;
            }
            
            .navbar-brand::after {
                content: '✦';
                color: var(--eksa-gold);
                font-size: 2rem;
                position: absolute;
                right: -15px;
                top: 5px;
            }
            
            /* ===== LUXURY DROPDOWN MENU ===== */
            .dropdown-menu {
                background: var(--eksa-white);
                border: 2px solid var(--eksa-gold);
                border-radius: 15px;
                box-shadow: 0 15px 40px var(--eksa-shadow-dark);
                padding: 10px;
            }
            
            .dropdown-menu li a {
                color: var(--eksa-navy);
                padding: 10px 20px;
                border-radius: 10px;
                transition: all 0.3s ease;
            }
            
            .dropdown-menu li a:hover {
                background: rgba(196, 164, 132, 0.1);
                color: var(--eksa-gold-dark);
            }
            
            .dropdown-menu li a i {
                color: var(--eksa-gold);
                margin-right: 10px;
            }
            
            /* ===== LUXURY NAV PILLS ===== */
            .nav-pills {
                margin: 20px 0;
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            
            .nav-pills li {
                margin: 0;
            }
            
            .nav-pills li a {
                background: var(--eksa-white);
                color: var(--eksa-navy);
                padding: 12px 25px;
                border-radius: 50px;
                font-weight: 600;
                transition: all 0.3s ease;
                border: 2px solid rgba(196, 164, 132, 0.2);
                text-decoration: none;
                display: inline-block;
            }
            
            .nav-pills li a:hover {
                background: rgba(196, 164, 132, 0.1);
                border-color: var(--eksa-gold);
                transform: translateY(-2px);
            }
            
            .nav-pills li.active a {
                background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
                color: var(--eksa-navy-dark);
                border-color: var(--eksa-white);
            }
            
            /* ===== LUXURY PANEL ===== */
            .panel {
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
            }
            
            .panel-body {
                background: var(--eksa-white);
                border-radius: 30px;
                padding: 40px;
                box-shadow: 0 30px 60px var(--eksa-shadow);
                border: 1px solid rgba(196, 164, 132, 0.2);
                position: relative;
                overflow: hidden;
            }
            
            .panel-body::before {
                content: '✦ ✦ ✦';
                position: absolute;
                bottom: -20px;
                right: -20px;
                font-size: 12rem;
                color: rgba(196, 164, 132, 0.05);
                font-family: serif;
                transform: rotate(-15deg);
            }
            
            /* ===== PAGE HEADER ===== */
            .page-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 30px;
                flex-wrap: wrap;
                gap: 20px;
            }
            
            .page-title {
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .page-title i {
                font-size: 2.5rem;
                color: var(--eksa-gold);
                background: rgba(196, 164, 132, 0.1);
                padding: 15px;
                border-radius: 20px;
            }
            
            .page-title h2 {
                color: var(--eksa-navy);
                font-size: 2.2rem;
                margin: 0;
            }
            
            .page-title p {
                color: var(--eksa-navy-light);
                margin: 5px 0 0;
                font-size: 0.95rem;
            }
            
            /* ===== DATE FILTER ===== */
            .date-filter {
                display: flex;
                gap: 15px;
                align-items: center;
                flex-wrap: wrap;
                background: rgba(196, 164, 132, 0.05);
                padding: 20px 25px;
                border-radius: 20px;
                margin-bottom: 30px;
            }
            
            .date-filter label {
                font-weight: 600;
                color: var(--eksa-navy);
                margin-right: 5px;
            }
            
            .date-filter input {
                padding: 10px 15px;
                border: 2px solid rgba(196, 164, 132, 0.2);
                border-radius: 50px;
                background: var(--eksa-white);
                font-family: 'Poppins', sans-serif;
            }
            
            .date-filter input:focus {
                outline: none;
                border-color: var(--eksa-gold);
                box-shadow: 0 0 0 3px var(--eksa-gold-glow);
            }
            
            .btn-filter {
                background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
                color: var(--eksa-navy-dark);
                border: none;
                padding: 10px 25px;
                border-radius: 50px;
                font-weight: 700;
                transition: all 0.3s ease;
            }
            
            .btn-filter:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 20px var(--eksa-gold-glow);
            }
            
            .btn-export {
                background: linear-gradient(135deg, var(--eksa-success), #218838);
                color: white;
                border: none;
                padding: 10px 25px;
                border-radius: 50px;
                font-weight: 700;
                transition: all 0.3s ease;
                display: inline-flex;
                align-items: center;
                gap: 8px;
            }
            
            .btn-export:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(40, 167, 69, 0.3);
            }
            
            /* ===== STATS CARDS ===== */
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 25px;
                margin-bottom: 40px;
            }
            
            .stat-card {
                background: var(--eksa-white);
                border-radius: 20px;
                padding: 25px;
                box-shadow: 0 10px 30px var(--eksa-shadow);
                border: 1px solid rgba(196, 164, 132, 0.2);
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 20px;
            }
            
            .stat-card:hover {
                transform: translateY(-5px);
                border-color: var(--eksa-gold);
                box-shadow: 0 15px 40px var(--eksa-gold-glow);
            }
            
            .stat-icon {
                width: 70px;
                height: 70px;
                border-radius: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2rem;
            }
            
            .stat-icon.revenue {
                background: rgba(40, 167, 69, 0.1);
                color: #28a745;
            }
            
            .stat-icon.bookings {
                background: rgba(23, 162, 184, 0.1);
                color: #17a2b8;
            }
            
            .stat-icon.guests {
                background: rgba(111, 66, 193, 0.1);
                color: #6f42c1;
            }
            
            .stat-icon.rooms {
                background: rgba(196, 164, 132, 0.1);
                color: var(--eksa-gold);
            }
            
            .stat-content {
                flex: 1;
            }
            
            .stat-label {
                color: var(--eksa-navy-light);
                font-size: 0.9rem;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 5px;
            }
            
            .stat-number {
                font-size: 2rem;
                font-weight: 800;
                color: var(--eksa-navy);
                line-height: 1.2;
            }
            
            .stat-change {
                font-size: 0.85rem;
                color: #28a745;
                margin-top: 5px;
            }
            
            /* ===== CHARTS CONTAINER ===== */
            .charts-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
                gap: 30px;
                margin-bottom: 40px;
            }
            
            .chart-card {
                background: var(--eksa-white);
                border-radius: 20px;
                padding: 25px;
                box-shadow: 0 10px 30px var(--eksa-shadow);
                border: 1px solid rgba(196, 164, 132, 0.2);
            }
            
            .chart-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }
            
            .chart-header h4 {
                color: var(--eksa-navy);
                font-size: 1.3rem;
                margin: 0;
            }
            
            .chart-header i {
                color: var(--eksa-gold);
                font-size: 1.3rem;
            }
            
            .chart-container {
                position: relative;
                height: 300px;
                width: 100%;
            }
            
            /* ===== POPULAR ROOMS ===== */
            .popular-rooms {
                margin-bottom: 40px;
            }
            
            .room-stats {
                display: flex;
                flex-direction: column;
                gap: 15px;
            }
            
            .room-stat-item {
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .room-stat-info {
                flex: 1;
            }
            
            .room-stat-name {
                display: flex;
                justify-content: space-between;
                margin-bottom: 5px;
            }
            
            .room-stat-name span {
                font-weight: 600;
                color: var(--eksa-navy);
            }
            
            .room-stat-count {
                color: var(--eksa-gold-dark);
                font-weight: 700;
            }
            
            .progress-bar {
                height: 10px;
                background: rgba(196, 164, 132, 0.1);
                border-radius: 10px;
                overflow: hidden;
            }
            
            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, var(--eksa-gold), var(--eksa-gold-dark));
                border-radius: 10px;
                transition: width 0.5s ease;
            }
            
            /* ===== RECENT TRANSACTIONS ===== */
            .table-container {
                margin-top: 20px;
                overflow-x: auto;
            }
            
            .table {
                width: 100%;
                border-collapse: collapse;
            }
            
            .table thead {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
            }
            
            .table thead th {
                padding: 15px 12px;
                color: var(--eksa-gold-light);
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
                font-size: 0.85rem;
                border: none;
            }
            
            .table tbody tr {
                transition: all 0.3s ease;
                border-bottom: 1px solid rgba(196, 164, 132, 0.1);
            }
            
            .table tbody tr:hover {
                background: rgba(196, 164, 132, 0.05);
            }
            
            .table tbody td {
                padding: 15px 12px;
                vertical-align: middle;
                color: var(--eksa-navy-light);
                border: none;
            }
            
            .status-badge {
                display: inline-block;
                padding: 5px 15px;
                border-radius: 50px;
                font-size: 0.8rem;
                font-weight: 600;
            }
            
            .status-pending {
                background: rgba(255, 193, 7, 0.1);
                color: #856404;
                border: 1px solid #ffc107;
            }
            
            .status-checkin {
                background: rgba(23, 162, 184, 0.1);
                color: #0c5460;
                border: 1px solid #17a2b8;
            }
            
            .status-checkout {
                background: rgba(108, 117, 125, 0.1);
                color: #383d41;
                border: 1px solid #6c757d;
            }
            
            /* ===== REPORT SUMMARY ===== */
            .report-summary {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
                border-radius: 20px;
                padding: 30px;
                color: white;
                margin-top: 40px;
            }
            
            .summary-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 30px;
            }
            
            .summary-item {
                text-align: center;
            }
            
            .summary-label {
                color: var(--eksa-gold-light);
                font-size: 0.9rem;
                text-transform: uppercase;
                margin-bottom: 10px;
            }
            
            .summary-value {
                font-size: 2.2rem;
                font-weight: 800;
                color: var(--eksa-gold);
            }
            
            /* ===== LUXURY FOOTER ===== */
            .navbar-fixed-bottom {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
                border: none !important;
                border-top: 2px solid var(--eksa-gold) !important;
                padding: 20px 0 !important;
                color: var(--eksa-white) !important;
                position: relative !important;
                margin-top: 50px !important;
            }
            
            .navbar-fixed-bottom label {
                color: var(--eksa-gold-light) !important;
                font-size: 1rem !important;
                font-weight: 400 !important;
                letter-spacing: 2px !important;
            }
            
            .navbar-fixed-bottom label::before {
                content: '✦ ';
                color: var(--eksa-gold);
            }
            
            .navbar-fixed-bottom label::after {
                content: ' ✦';
                color: var(--eksa-gold);
            }
            
            /* ===== RESPONSIVE ===== */
            @media (max-width: 992px) {
                .charts-grid {
                    grid-template-columns: 1fr;
                }
            }
            
            @media (max-width: 768px) {
                .navbar-brand {
                    font-size: 1.2rem !important;
                }
                
                .nav-pills {
                    flex-direction: column;
                }
                
                .nav-pills li a {
                    display: block;
                    text-align: center;
                }
                
                .panel-body {
                    padding: 25px;
                }
                
                .page-header {
                    flex-direction: column;
                    align-items: flex-start;
                }
                
                .page-title h2 {
                    font-size: 1.8rem;
                }
                
                .stats-grid {
                    grid-template-columns: 1fr;
                }
                
                .date-filter {
                    flex-direction: column;
                    align-items: flex-start;
                }
                
                .date-filter input {
                    width: 100%;
                }
                
                .btn-filter, .btn-export {
                    width: 100%;
                }
                
                .summary-grid {
                    grid-template-columns: 1fr;
                }
            }
            
            /* Override Bootstrap defaults */
            .container-fluid {
                padding-left: 30px !important;
                padding-right: 30px !important;
            }
            
            .navbar-default .navbar-brand:hover,
            .navbar-default .navbar-brand:focus {
                color: var(--eksa-gold-light) !important;
            }
        </style>
    </head>
<body>
    <!-- LUXURY NAVIGATION -->
    <nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
        <div class = "container-fluid">
            <div class = "navbar-header">
                <a class = "navbar-brand">
                    <i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
                    Hotel Eksa
                </a>
            </div>
            <ul class = "nav navbar-nav pull-right">
                <li class = "dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
                        <span style="color: var(--eksa-white); font-weight: 600;"><?php echo $name; ?></span>
                        <span class="caret" style="color: var(--eksa-gold);"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
                        <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- LUXURY NAVIGATION PILLS -->
    <div class = "container-fluid">
        <ul class = "nav nav-pills">
            <li><a href = "home.php"><i class="fas fa-home me-2"></i> Dashboard</a></li>
            <li><a href = "account.php"><i class="fas fa-users-cog me-2"></i> Accounts</a></li>
            <li><a href = "reserve.php"><i class="fas fa-calendar-check me-2"></i> Pending</a></li>
            <li><a href = "checkin.php"><i class="fas fa-sign-in-alt me-2"></i> Check In</a></li>
            <li><a href = "checkout.php"><i class="fas fa-sign-out-alt me-2"></i> Check Out</a></li>
            <li><a href = "room.php"><i class="fas fa-bed me-2"></i> Rooms</a></li>
            <li class = "active"><a href = "reports.php"><i class="fas fa-chart-line me-2"></i> Reports</a></li>
        </ul>
    </div>
    
    <br />
    
    <!-- LUXURY REPORTS CONTENT -->
    <div class = "container-fluid">
        <div class = "panel panel-default">
            <div class = "panel-body">
                
                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div class="page-title">
                        <i class="fas fa-chart-line"></i>
                        <div>
                            <h2>Reports & Analytics</h2>
                            <p>Comprehensive hotel performance and revenue insights</p>
                        </div>
                    </div>
                </div>
                
                <!-- DATE FILTER -->
                <?php
                    // Set default date range (current month)
                    $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
                    $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');
                ?>
                
                <div class="date-filter">
                    <div style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                        <div>
                            <label>From:</label>
                            <input type="date" id="start_date" value="<?php echo $start_date; ?>">
                        </div>
                        <div>
                            <label>To:</label>
                            <input type="date" id="end_date" value="<?php echo $end_date; ?>">
                        </div>
                        <button class="btn-filter" onclick="applyDateFilter()">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                    </div>
                    <button class="btn-export" onclick="exportReport()">
                        <i class="fas fa-file-pdf"></i> Export Report
                    </button>
                </div>
                
                <?php
                    // Get statistics with date filter
                    $total_revenue_query = $conn->query("SELECT SUM(bill) as total FROM `transaction` WHERE `status` = 'Check Out' AND `checkout` BETWEEN '$start_date' AND '$end_date'") or die(mysqli_error($conn));
                    $total_revenue = $total_revenue_query->fetch_assoc()['total'];
                    $total_revenue = $total_revenue ? floatval($total_revenue) : 0;
                    
                    $total_bookings_query = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `checkin` BETWEEN '$start_date' AND '$end_date'") or die(mysqli_error($conn));
                    $total_bookings = $total_bookings_query->fetch_assoc()['total'];
                    
                    $total_guests_query = $conn->query("SELECT COUNT(DISTINCT guest_id) as total FROM `transaction` WHERE `checkin` BETWEEN '$start_date' AND '$end_date'") or die(mysqli_error($conn));
                    $total_guests = $total_guests_query->fetch_assoc()['total'];
                    
                    $avg_nights_query = $conn->query("SELECT AVG(days) as avg FROM `transaction` WHERE `checkin` BETWEEN '$start_date' AND '$end_date'") or die(mysqli_error($conn));
                    $avg_nights = $avg_nights_query->fetch_assoc()['avg'];
                    $avg_nights = $avg_nights ? round($avg_nights, 1) : 0;
                    
                    // Get monthly revenue for chart
                    $monthly_data = [];
                    $monthly_labels = [];
                    for ($i = 5; $i >= 0; $i--) {
                        $month = date('Y-m', strtotime("-$i months"));
                        $month_name = date('M Y', strtotime("-$i months"));
                        $monthly_labels[] = $month_name;
                        
                        $month_query = $conn->query("SELECT SUM(bill) as total FROM `transaction` WHERE `status` = 'Check Out' AND DATE_FORMAT(`checkout`, '%Y-%m') = '$month'") or die(mysqli_error($conn));
                        $month_total = $month_query->fetch_assoc()['total'];
                        $monthly_data[] = $month_total ? floatval($month_total) : 0;
                    }
                    
                    // Get room popularity
                    $room_popularity = $conn->query("SELECT r.room_type, COUNT(t.transaction_id) as count 
                                                    FROM `room` r 
                                                    LEFT JOIN `transaction` t ON r.room_id = t.room_id 
                                                    AND t.checkin BETWEEN '$start_date' AND '$end_date'
                                                    GROUP BY r.room_id 
                                                    ORDER BY count DESC 
                                                    LIMIT 5") or die(mysqli_error($conn));
                    
                    // Get recent transactions
                    $recent_transactions = $conn->query("SELECT t.*, g.firstname, g.lastname, r.room_type 
                                                        FROM `transaction` t 
                                                        NATURAL JOIN `guest` g 
                                                        NATURAL JOIN `room` r 
                                                        WHERE t.checkin BETWEEN '$start_date' AND '$end_date'
                                                        ORDER BY t.checkin DESC 
                                                        LIMIT 10") or die(mysqli_error($conn));
                ?>
                
                <!-- STATISTICS CARDS -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon revenue">
                            <i class="fas fa-coin"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Total Revenue</div>
                            <div class="stat-number">Rs.<?php echo number_format($total_revenue, 2); ?></div>
                            <div class="stat-change">
                                <i class="fas fa-arrow-up"></i> +12% vs last period
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon bookings">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Total Bookings</div>
                            <div class="stat-number"><?php echo $total_bookings; ?></div>
                            <div class="stat-change">
                                <i class="fas fa-arrow-up"></i> +8% vs last period
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon guests">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Unique Guests</div>
                            <div class="stat-number"><?php echo $total_guests; ?></div>
                            <div class="stat-change">
                                <i class="fas fa-arrow-up"></i> +15% vs last period
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon rooms">
                            <i class="fas fa-bed"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Avg. Stay Duration</div>
                            <div class="stat-number"><?php echo $avg_nights; ?> <small style="font-size: 1rem;">nights</small></div>
                            <div class="stat-change">
                                <i class="fas fa-arrow-up"></i> +0.5 vs last period
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- CHARTS SECTION -->
                <div class="charts-grid">
                    <!-- Revenue Chart -->
                    <div class="chart-card">
                        <div class="chart-header">
                            <h4><i class="fas fa-chart-bar" style="color: var(--eksa-gold);"></i> Revenue Trend</h4>
                            <i class="fas fa-coin"></i>
                        </div>
                        <div class="chart-container">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Booking Status Chart -->
                    <div class="chart-card">
                        <div class="chart-header">
                            <h4><i class="fas fa-chart-pie" style="color: var(--eksa-gold);"></i> Booking Status</h4>
                            <i class="fas fa-circle"></i>
                        </div>
                        <div class="chart-container">
                            <canvas id="statusChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- POPULAR ROOMS -->
                <div class="popular-rooms">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                        <h4 style="color: var(--eksa-navy); font-size: 1.3rem;">
                            <i class="fas fa-crown" style="color: var(--eksa-gold);"></i> Most Popular Rooms
                        </h4>
                    </div>
                    
                    <div class="room-stats">
                        <?php
                            $max_count = 0;
                            $room_counts = [];
                            while($room = $room_popularity->fetch_assoc()) {
                                $room_counts[] = $room;
                                if($room['count'] > $max_count) $max_count = $room['count'];
                            }
                            
                            if(count($room_counts) > 0) {
                                foreach($room_counts as $room) {
                                    $percentage = $max_count > 0 ? round(($room['count'] / $max_count) * 100) : 0;
                        ?>
                        <div class="room-stat-item">
                            <i class="fas fa-bed" style="color: var(--eksa-gold);"></i>
                            <div class="room-stat-info">
                                <div class="room-stat-name">
                                    <span><?php echo $room['room_type']; ?></span>
                                    <span class="room-stat-count"><?php echo $room['count']; ?> bookings</span>
                                </div>
                                <div class="progress-bar">
                                    <div class="progress-fill" style="width: <?php echo $percentage; ?>%;"></div>
                                </div>
                            </div>
                        </div>
                        <?php 
                                }
                            } else {
                                echo '<p style="color: var(--eksa-navy-light); text-align: center; padding: 20px;">No booking data available for this period.</p>';
                            }
                        ?>
                    </div>
                </div>
                
                <!-- RECENT TRANSACTIONS -->
                <div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h4 style="color: var(--eksa-navy); font-size: 1.3rem;">
                            <i class="fas fa-history" style="color: var(--eksa-gold);"></i> Recent Transactions
                        </h4>
                    </div>
                    
                    <div class="table-container">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Guest Name</th>
                                    <th>Room Type</th>
                                    <th>Check In</th>
                                    <th>Check Out</th>
                                    <th>Status</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    if($recent_transactions->num_rows > 0) {
                                        while($row = $recent_transactions->fetch_assoc()) {
                                            $status_class = '';
                                            $status_icon = '';
                                            if($row['status'] == 'Pending') {
                                                $status_class = 'status-pending';
                                                $status_icon = 'fa-clock';
                                            } elseif($row['status'] == 'Check In') {
                                                $status_class = 'status-checkin';
                                                $status_icon = 'fa-sign-in-alt';
                                            } elseif($row['status'] == 'Check Out') {
                                                $status_class = 'status-checkout';
                                                $status_icon = 'fa-sign-out-alt';
                                            }
                                            
                                            $bill_amount = isset($row['bill']) && $row['bill'] !== '' ? floatval($row['bill']) : 0;
                                ?>
                                <tr>
                                    <td>
                                        <i class="fas fa-user-circle" style="color: var(--eksa-gold); margin-right: 8px;"></i>
                                        <?php echo $row['firstname'] . ' ' . $row['lastname']; ?>
                                    </td>
                                    <td><?php echo $row['room_type']; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($row['checkin'])); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($row['checkout'])); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>">
                                            <i class="fas <?php echo $status_icon; ?>"></i> <?php echo $row['status']; ?>
                                        </span>
                                    </td>
                                    <td style="font-weight: 700; color: var(--eksa-gold-dark);">
                                        Rs.<?php echo number_format($bill_amount, 2); ?>
                                    </td>
                                </tr>
                                <?php 
                                        }
                                    } else {
                                ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 40px; color: var(--eksa-navy-light);">
                                        <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 10px; display: block; color: var(--eksa-gold);"></i>
                                        No transactions found for this period.
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- REPORT SUMMARY -->
                <div class="report-summary" id="reportSummary">
                    <h4 style="color: var(--eksa-gold); margin-bottom: 25px; text-align: center;">
                        <i class="fas fa-file-alt"></i> Executive Summary
                    </h4>
                    <div class="summary-grid">
                        <div class="summary-item">
                            <div class="summary-label">Total Revenue</div>
                            <div class="summary-value">Rs.<?php echo number_format($total_revenue, 2); ?></div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Total Bookings</div>
                            <div class="summary-value"><?php echo $total_bookings; ?></div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Average per Booking</div>
                            <div class="summary-value">
                                Rs.<?php echo $total_bookings > 0 ? number_format($total_revenue / $total_bookings, 2) : '0.00'; ?>
                            </div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Occupancy Rate</div>
                            <div class="summary-value">
                                <?php 
                                    $total_rooms_query = $conn->query("SELECT COUNT(*) as total FROM `room`")->fetch_assoc()['total'];
                                    $occupied_days = $total_bookings * $avg_nights;
                                    $total_possible_days = $total_rooms_query * 30; // Approximate
                                    $occupancy_rate = $total_possible_days > 0 ? round(($occupied_days / $total_possible_days) * 100) : 0;
                                    echo $occupancy_rate . '%';
                                ?>
                            </div>
                        </div>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: var(--eksa-cream);">
                        <i class="fas fa-calendar-alt"></i> Report Period: <?php echo date('M d, Y', strtotime($start_date)); ?> - <?php echo date('M d, Y', strtotime($end_date)); ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
    <!-- LUXURY FOOTER -->
    <div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
        <label>HOTEL EKSA • REPORTS & ANALYTICS • EST. 2026 </label>
        <div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
            <i class="fas fa-chart-line"></i> Period: <?php echo date('M Y', strtotime($start_date)); ?> <i class="fas fa-chart-line"></i>
        </div>
    </div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script src = "../js/jquery.dataTables.js"></script>
<script src = "../js/dataTables.bootstrap.js"></script>
<script>
    // Initialize DataTable
    $(document).ready(function(){
        $('.table').DataTable({
            language: {
                search: "Search transactions:",
                lengthMenu: "Show _MENU_ records",
                info: "Showing _START_ to _END_ of _TOTAL_ transactions",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: '<i class="fas fa-chevron-right"></i>',
                    previous: '<i class="fas fa-chevron-left"></i>'
                }
            },
            order: [[2, 'desc']] // Sort by check-in date
        });
    });

    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($monthly_labels); ?>,
            datasets: [{
                label: 'Monthly Revenue',
                data: <?php echo json_encode($monthly_data); ?>,
                borderColor: '#C4A484',
                backgroundColor: 'rgba(196, 164, 132, 0.1)',
                borderWidth: 3,
                pointBackgroundColor: '#C4A484',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rs.' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });

    // Status Chart
    <?php
        $pending_query = $conn->query("SELECT COUNT(*) as count FROM `transaction` WHERE `status` = 'Pending'")->fetch_assoc()['count'];
        $checkin_query = $conn->query("SELECT COUNT(*) as count FROM `transaction` WHERE `status` = 'Check In'")->fetch_assoc()['count'];
        $checkout_query = $conn->query("SELECT COUNT(*) as count FROM `transaction` WHERE `status` = 'Check Out'")->fetch_assoc()['count'];
    ?>

    const statusCtx = document.getElementById('statusChart').getContext('2d');
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'Check In', 'Check Out'],
            datasets: [{
                data: [<?php echo $pending_query; ?>, <?php echo $checkin_query; ?>, <?php echo $checkout_query; ?>],
                backgroundColor: [
                    '#ffc107',
                    '#17a2b8',
                    '#6c757d'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Apply Date Filter
    function applyDateFilter() {
        var startDate = document.getElementById('start_date').value;
        var endDate = document.getElementById('end_date').value;
        
        if (!startDate || !endDate) {
            swal({
                title: 'Invalid Date Range',
                text: 'Please select both start and end dates.',
                icon: 'warning',
                button: 'OK'
            });
            return;
        }
        
        window.location.href = 'reports.php?start_date=' + startDate + '&end_date=' + endDate;
    }

    // Export Report as PDF
    function exportReport() {
        var element = document.getElementById('reportSummary');
        
        swal({
            title: 'Generating Report',
            text: 'Please wait while we generate your PDF report...',
            icon: 'info',
            buttons: false,
            timer: 2000
        });
        
        var opt = {
            margin: [0.5, 0.5, 0.5, 0.5],
            filename: 'Hotel_Eksa_Report_<?php echo date('Y-m-d'); ?>.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        };
        
        html2pdf().set(opt).from(element).save();
    }
</script>
</html>