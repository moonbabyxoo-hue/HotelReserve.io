<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Dine & Lounge</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Lightbox2 for gallery -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
				--eksa-wine: #722F37;
				--eksa-wine-light: #A0524D;
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 100px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY DINE CONTAINER ===== */
			.container {
				width: 95%;
				max-width: 1400px;
				margin: 40px auto !important;
				padding: 0 !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white) !important;
				padding: 50px !important;
				border-radius: 30px !important;
				box-shadow: 0 30px 60px var(--eksa-shadow) !important;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '🍷 ✦ 🍽️';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 8rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-10deg);
				opacity: 0.5;
			}
			
			/* ===== LUXURY DINE HEADER ===== */
			.dine-header {
				text-align: center;
				margin-bottom: 50px;
				position: relative;
			}
			
			.dine-header h3 {
				font-size: 3rem !important;
				color: var(--eksa-navy) !important;
				margin: 0 0 20px 0 !important;
				position: relative;
				display: inline-block;
			}
			
			.dine-header h3::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2.5rem;
			}
			
			.dine-header h3::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2.5rem;
			}
			
			.dine-header p {
				color: var(--eksa-navy-light);
				font-size: 1.1rem;
				max-width: 700px;
				margin: 0 auto;
			}
			
			/* ===== LUXURY DINE FEATURE SECTION ===== */
			.dine-feature {
				display: flex;
				flex-wrap: wrap;
				gap: 40px;
				margin-bottom: 60px;
				background: linear-gradient(135deg, var(--eksa-cream), var(--eksa-white));
				padding: 40px;
				border-radius: 30px;
				align-items: center;
			}
			
			.dine-feature-content {
				flex: 1;
				min-width: 300px;
			}
			
			.dine-feature-content h4 {
				color: var(--eksa-navy);
				font-size: 2rem;
				margin-bottom: 20px;
				position: relative;
			}
			
			.dine-feature-content h4::after {
				content: '';
				position: absolute;
				bottom: -10px;
				left: 0;
				width: 80px;
				height: 3px;
				background: var(--eksa-gold);
			}
			
			.dine-feature-content p {
				color: var(--eksa-navy-light);
				font-size: 1rem;
				line-height: 1.8;
				margin-bottom: 20px;
			}
			
			.dine-feature-stats {
				display: flex;
				gap: 30px;
				margin-top: 30px;
			}
			
			.stat-item {
				text-align: center;
			}
			
			.stat-item i {
				font-size: 2rem;
				color: var(--eksa-gold);
				margin-bottom: 10px;
			}
			
			.stat-number {
				font-size: 1.5rem;
				font-weight: 700;
				color: var(--eksa-navy);
			}
			
			.stat-label {
				font-size: 0.9rem;
				color: var(--eksa-navy-light);
			}
			
			.dine-feature-image {
				flex: 0 0 300px;
				position: relative;
			}
			
			.dine-feature-image img {
				width: 100%;
				height: 300px;
				object-fit: cover;
				border-radius: 20px;
				box-shadow: 0 20px 40px var(--eksa-shadow-dark);
				border: 5px solid var(--eksa-white);
				outline: 2px solid var(--eksa-gold);
			}
			
			/* ===== LUXURY DINE CATEGORIES ===== */
			.dine-categories {
				display: flex;
				justify-content: center;
				flex-wrap: wrap;
				gap: 20px;
				margin-bottom: 40px;
			}
			
			.category-card {
				background: linear-gradient(135deg, var(--eksa-white), var(--eksa-cream));
				padding: 30px;
				border-radius: 20px;
				text-align: center;
				flex: 1;
				min-width: 200px;
				box-shadow: 0 10px 30px var(--eksa-shadow);
				transition: all 0.4s ease;
				border: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.category-card:hover {
				transform: translateY(-10px);
				border-color: var(--eksa-gold);
				box-shadow: 0 20px 40px var(--eksa-gold-glow);
			}
			
			.category-card i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
			}
			
			.category-card h4 {
				color: var(--eksa-navy);
				font-size: 1.3rem;
				margin-bottom: 10px;
			}
			
			.category-card p {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
			}
			
			/* ===== LUXURY MENU PREVIEW ===== */
			.menu-preview {
				margin: 60px 0;
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				padding: 50px;
				border-radius: 30px;
				color: var(--eksa-white);
				position: relative;
				overflow: hidden;
			}
			
			.menu-preview::before {
				content: '🍽️';
				position: absolute;
				top: -30px;
				left: -30px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				transform: rotate(15deg);
			}
			
			.menu-preview h4 {
				color: var(--eksa-gold);
				font-size: 2rem;
				margin-bottom: 30px;
				text-align: center;
			}
			
			.menu-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
				gap: 30px;
			}
			
			.menu-item {
				display: flex;
				align-items: center;
				gap: 15px;
				padding: 15px;
				background: rgba(255,255,255,0.05);
				border-radius: 15px;
				transition: all 0.3s ease;
				border: 1px solid rgba(196,164,132,0.2);
			}
			
			.menu-item:hover {
				background: rgba(196,164,132,0.1);
				border-color: var(--eksa-gold);
				transform: translateX(10px);
			}
			
			.menu-item i {
				font-size: 1.8rem;
				color: var(--eksa-gold);
			}
			
			.menu-item-content {
				flex: 1;
			}
			
			.menu-item-content h5 {
				color: var(--eksa-gold-light);
				font-size: 1.1rem;
				margin-bottom: 5px;
			}
			
			.menu-item-content p {
				color: var(--eksa-white);
				font-size: 0.9rem;
				opacity: 0.8;
			}
			
			.menu-price {
				color: var(--eksa-gold);
				font-weight: 700;
				font-size: 1.1rem;
			}
			
			/* ===== LUXURY DINE GALLERY ===== */
			.dine-gallery-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 30px;
			}
			
			.dine-gallery-header h4 {
				color: var(--eksa-navy);
				font-size: 1.8rem;
				position: relative;
			}
			
			.dine-gallery-header h4::after {
				content: '';
				position: absolute;
				bottom: -10px;
				left: 0;
				width: 60px;
				height: 3px;
				background: var(--eksa-gold);
			}
			
			.dine-filter {
				display: flex;
				gap: 10px;
				flex-wrap: wrap;
			}
			
			.dine-filter-btn {
				background: transparent;
				border: 2px solid var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 8px 20px;
				border-radius: 50px;
				font-weight: 600;
				cursor: pointer;
				transition: all 0.3s ease;
				font-size: 0.9rem;
			}
			
			.dine-filter-btn:hover,
			.dine-filter-btn.active {
				background: var(--eksa-gold);
				color: var(--eksa-navy-dark);
			}
			
			.dine-gallery-grid {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
				gap: 25px;
				margin-top: 30px;
			}
			
			.dine-gallery-item {
				position: relative;
				border-radius: 15px;
				overflow: hidden;
				box-shadow: 0 15px 35px var(--eksa-shadow);
				transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
				aspect-ratio: 1 / 1;
				cursor: pointer;
			}
			
			.dine-gallery-item:hover {
				transform: translateY(-10px) scale(1.02);
				box-shadow: 0 25px 50px var(--eksa-shadow-dark);
			}
			
			.dine-gallery-item img {
				width: 100%;
				height: 100%;
				object-fit: cover;
				transition: transform 0.6s ease;
				display: block;
			}
			
			.dine-gallery-item:hover img {
				transform: scale(1.1);
			}
			
			.dine-gallery-overlay {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: linear-gradient(to top, rgba(10,28,47,0.9), rgba(10,28,47,0.3));
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				opacity: 0;
				transition: all 0.4s ease;
				color: var(--eksa-white);
				padding: 20px;
				text-align: center;
			}
			
			.dine-gallery-item:hover .dine-gallery-overlay {
				opacity: 1;
			}
			
			.dine-gallery-overlay i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
				transform: translateY(20px);
				transition: transform 0.4s ease;
			}
			
			.dine-gallery-item:hover .dine-gallery-overlay i {
				transform: translateY(0);
			}
			
			.dine-gallery-overlay span {
				font-size: 1.1rem;
				font-weight: 600;
				letter-spacing: 2px;
				transform: translateY(20px);
				transition: transform 0.4s ease 0.1s;
			}
			
			.dine-gallery-item:hover .dine-gallery-overlay span {
				transform: translateY(0);
			}
			
			.dine-category-badge {
				position: absolute;
				top: 15px;
				left: 15px;
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 6px 15px;
				border-radius: 50px;
				font-size: 0.8rem;
				font-weight: 700;
				z-index: 10;
				letter-spacing: 1px;
				box-shadow: 0 3px 10px rgba(0,0,0,0.2);
			}
			
			/* ===== LUXURY RESERVATION CTA ===== */
			.reservation-cta {
				margin-top: 60px;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				padding: 50px;
				border-radius: 30px;
				text-align: center;
				color: var(--eksa-navy);
				position: relative;
				overflow: hidden;
			}
			
			.reservation-cta::before {
				content: '🍷';
				position: absolute;
				bottom: -20px;
				left: -20px;
				font-size: 10rem;
				color: rgba(10,28,47,0.1);
				transform: rotate(-15deg);
			}
			
			.reservation-cta::after {
				content: '🍽️';
				position: absolute;
				top: -20px;
				right: -20px;
				font-size: 10rem;
				color: rgba(10,28,47,0.1);
				transform: rotate(15deg);
			}
			
			.reservation-cta h4 {
				font-size: 2.2rem;
				margin-bottom: 20px;
				color: var(--eksa-navy-dark);
			}
			
			.reservation-cta p {
				font-size: 1.1rem;
				margin-bottom: 30px;
				max-width: 600px;
				margin-left: auto;
				margin-right: auto;
			}
			
			.btn-reservation {
				background: var(--eksa-navy);
				color: var(--eksa-white);
				border: 2px solid var(--eksa-white);
				padding: 15px 40px;
				border-radius: 50px;
				font-size: 1.1rem;
				font-weight: 700;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				display: inline-block;
				text-decoration: none;
			}
			
			.btn-reservation:hover {
				background: var(--eksa-white);
				color: var(--eksa-navy);
				border-color: var(--eksa-navy);
				transform: translateY(-3px);
				box-shadow: 0 15px 30px rgba(0,0,0,0.2);
			}
			
			.btn-reservation i {
				margin-right: 10px;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 992px) {
				.panel-body {
					padding: 40px !important;
				}
				
				.dine-feature {
					flex-direction: column;
				}
				
				.dine-feature-image {
					flex: 0 0 100%;
				}
				
				.dine-header h3 {
					font-size: 2.5rem !important;
				}
			}
			
			@media (max-width: 768px) {
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li:not(:last-child)::after {
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.panel-body {
					padding: 30px !important;
				}
				
				.dine-header h3 {
					font-size: 2rem !important;
				}
				
				.dine-header h3::before,
				.dine-header h3::after {
					font-size: 1.8rem;
				}
				
				.dine-gallery-grid {
					grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
				}
				
				.dine-feature-stats {
					flex-direction: column;
					gap: 20px;
				}
				
				.dine-gallery-header {
					flex-direction: column;
					gap: 20px;
				}
			}
			
			@media (max-width: 480px) {
				.panel-body {
					padding: 20px !important;
				}
				
				.dine-gallery-grid {
					grid-template-columns: 1fr;
				}
				
				.reservation-cta h4 {
					font-size: 1.6rem;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> Admin Login</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> User Login</a></li>
	</ul>
	
	<!-- LUXURY DINE & LOUNGE CONTENT -->
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- DINE HEADER -->
				<div class="dine-header">
					<strong><h3>Dine & Lounge</h3></strong>
					<p>Experience culinary excellence at Hotel Eksa. Our award-winning chefs create unforgettable dining experiences.</p>
				</div>
				
				<!-- DINE FEATURE SECTION -->
				<div class="dine-feature">
					<div class="dine-feature-content">
						<h4>Eksa Fine Dining</h4>
						<p>Indulge in a symphony of flavors at our signature restaurant. Led by Executive Chef Michael Chen, our culinary team crafts exquisite dishes using the finest locally-sourced ingredients and international techniques. Each plate is a work of art, designed to delight all your senses.</p>
						<div class="dine-feature-stats">
							<div class="stat-item">
								<i class="fas fa-star"></i>
								<div class="stat-number">2</div>
								<div class="stat-label">Michelin Stars</div>
							</div>
							<div class="stat-item">
								<i class="fas fa-wine-glass-alt"></i>
								<div class="stat-number">500+</div>
								<div class="stat-label">Wine Selection</div>
							</div>
							<div class="stat-item">
								<i class="fas fa-users"></i>
								<div class="stat-number">200</div>
								<div class="stat-label">Daily Guests</div>
							</div>
						</div>
					</div>
					<div class="dine-feature-image">
						<img src="images/dine/1.jpg" alt="Eksa Fine Dining">
					</div>
				</div>
				
				<!-- DINE CATEGORIES -->
				<div class="dine-categories">
					<div class="category-card">
						<i class="fas fa-utensils"></i>
						<h4>Fine Dining</h4>
						<p>Contemporary cuisine with panoramic views</p>
					</div>
					<div class="category-card">
						<i class="fas fa-wine-glass-alt"></i>
						<h4>Wine Bar</h4>
						<p>Curated selection from world-class vineyards</p>
					</div>
					<div class="category-card">
						<i class="fas fa-mug-hot"></i>
						<h4>Lobby Lounge</h4>
						<p>Artisanal coffee and afternoon tea</p>
					</div>
					<div class="category-card">
						<i class="fas fa-cocktail"></i>
						<h4>Rooftop Bar</h4>
						<p>Signature cocktails with city views</p>
					</div>
				</div>
				
				<!-- MENU PREVIEW -->
				<div class="menu-preview">
					<h4>Signature Dishes</h4>
					<div class="menu-grid">
						<div class="menu-item">
							<i class="fas fa-fish"></i>
							<div class="menu-item-content">
								<h5>Pan-Seared Sea Bass</h5>
								<p>With saffron risotto and lemon butter sauce</p>
							</div>
							<div class="menu-price">$48</div>
						</div>
						<div class="menu-item">
							<i class="fas fa-drumstick-bite"></i>
							<div class="menu-item-content">
								<h5>Wagyu Beef Tenderloin</h5>
								<p>With truffle mashed potatoes and red wine reduction</p>
							</div>
							<div class="menu-price">$75</div>
						</div>
						<div class="menu-item">
							<i class="fas fa-carrot"></i>
							<div class="menu-item-content">
								<h5>Wild Mushroom Risotto</h5>
								<p>With aged parmesan and truffle oil</p>
							</div>
							<div class="menu-price">$32</div>
						</div>
						<div class="menu-item">
							<i class="fas fa-cake"></i>
							<div class="menu-item-content">
								<h5>Molten Chocolate Cake</h5>
								<p>With vanilla bean ice cream</p>
							</div>
							<div class="menu-price">$16</div>
						</div>
					</div>
				</div>
				
				<!-- DINE GALLERY HEADER WITH FILTER -->
				<div class="dine-gallery-header">
					<h4>Culinary Gallery</h4>
					<div class="dine-filter">
						<button class="dine-filter-btn active" data-filter="all">All</button>
						<button class="dine-filter-btn" data-filter="restaurant">Restaurant</button>
						<button class="dine-filter-btn" data-filter="dishes">Dishes</button>
						<button class="dine-filter-btn" data-filter="bar">Bar</button>
						<button class="dine-filter-btn" data-filter="events">Events</button>
					</div>
				</div>
				
				<!-- DINE GALLERY GRID -->
				<div class="dine-gallery-grid" id="dineGalleryGrid">
					<!-- IMAGE 1 - Restaurant -->
					<div class="dine-gallery-item" data-category="restaurant">
						<span class="dine-category-badge">Restaurant</span>
						<a href="images/dine/1.jpg" data-lightbox="dine-gallery" data-title="Eksa Fine Dining Restaurant">
							<img src="images/dine/1.jpg" alt="Fine Dining Restaurant">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Fine Dining</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 2 - Dishes -->
					<div class="dine-gallery-item" data-category="dishes">
						<span class="dine-category-badge">Dishes</span>
						<a href="images/dine/2.jpg" data-lightbox="dine-gallery" data-title="Signature Wagyu Beef">
							<img src="images/dine/2.jpg" alt="Signature Dish">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Wagyu Beef</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 3 - Bar -->
					<div class="dine-gallery-item" data-category="bar">
						<span class="dine-category-badge">Bar</span>
						<a href="images/dine/3.jpg" data-lightbox="dine-gallery" data-title="Rooftop Bar & Lounge">
							<img src="images/dine/3.jpg" alt="Rooftop Bar">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Rooftop Bar</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 4 - Events -->
					<div class="dine-gallery-item" data-category="events">
						<span class="dine-category-badge">Events</span>
						<a href="images/dine/4.jpg" data-lightbox="dine-gallery" data-title="Private Dining Room">
							<img src="images/dine/4.jpg" alt="Private Dining">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Private Dining</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 5 - Dishes -->
					<div class="dine-gallery-item" data-category="dishes">
						<span class="dine-category-badge">Dishes</span>
						<a href="images/dine/5.jpg" data-lightbox="dine-gallery" data-title="Pan-Seared Sea Bass">
							<img src="images/dine/5.jpg" alt="Sea Bass">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Sea Bass</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 6 - Restaurant -->
					<div class="dine-gallery-item" data-category="restaurant">
						<span class="dine-category-badge">Restaurant</span>
						<a href="images/dine/6.jpg" data-lightbox="dine-gallery" data-title="Main Dining Area">
							<img src="images/dine/6.jpg" alt="Main Dining">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Main Dining</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 7 - Bar -->
					<div class="dine-gallery-item" data-category="bar">
						<span class="dine-category-badge">Bar</span>
						<a href="images/dine/7.jpg" data-lightbox="dine-gallery" data-title="Signature Cocktails">
							<img src="images/dine/7.jpg" alt="Cocktails">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Signature Cocktails</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 8 - Events -->
					<div class="dine-gallery-item" data-category="events">
						<span class="dine-category-badge">Events</span>
						<a href="images/dine/8.jpg" data-lightbox="dine-gallery" data-title="Wine Tasting Event">
							<img src="images/dine/8.jpg" alt="Wine Tasting">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Wine Tasting</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 9 - Dishes -->
					<div class="dine-gallery-item" data-category="dishes">
						<span class="dine-category-badge">Dishes</span>
						<a href="images/dine/9.jpg" data-lightbox="dine-gallery" data-title="Wild Mushroom Risotto">
							<img src="images/dine/9.jpg" alt="Risotto">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Mushroom Risotto</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 10 - Restaurant -->
					<div class="dine-gallery-item" data-category="restaurant">
						<span class="dine-category-badge">Restaurant</span>
						<a href="images/dine/10.jpg" data-lightbox="dine-gallery" data-title="Chef's Table">
							<img src="images/dine/10.jpg" alt="Chef's Table">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Chef's Table</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 11 - Bar -->
					<div class="dine-gallery-item" data-category="bar">
						<span class="dine-category-badge">Bar</span>
						<a href="images/dine/11.jpg" data-lightbox="dine-gallery" data-title="Wine Cellar">
							<img src="images/dine/11.jpg" alt="Wine Cellar">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Wine Cellar</span>
							</div>
						</a>
					</div>
					
					<!-- IMAGE 12 - Events -->
					<div class="dine-gallery-item" data-category="events">
						<span class="dine-category-badge">Events</span>
						<a href="images/dine/12.jpg" data-lightbox="dine-gallery" data-title="Holiday Celebration">
							<img src="images/dine/12.jpg" alt="Holiday Event">
							<div class="dine-gallery-overlay">
								<i class="fas fa-search-plus"></i>
								<span>Holiday Events</span>
							</div>
						</a>
					</div>
				</div>
				
				<!-- RESERVATION CTA -->
				<div class="reservation-cta">
					<h4>Reserve Your Table</h4>
					<p>Experience the finest culinary journey at Hotel Eksa. Book your table now for an unforgettable dining experience.</p>
					<a href="reservation.php" class="btn-reservation">
						<i class="fas fa-calendar-check"></i> MAKE A RESERVATION
					</a>
				</div>
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Created by Pujan Pathak <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script src = "https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<script>
	// Add active class to current menu item
	document.addEventListener('DOMContentLoaded', function() {
		var currentPage = window.location.pathname.split('/').pop();
		var menuItems = document.querySelectorAll('#menu li a');
		
		menuItems.forEach(function(item) {
			if (item.getAttribute('href') === currentPage) {
				item.style.background = 'var(--eksa-gold)';
				item.style.color = 'var(--eksa-navy)';
			}
		});
		
		// Dine Gallery Filter Functionality
		const filterBtns = document.querySelectorAll('.dine-filter-btn');
		const galleryItems = document.querySelectorAll('.dine-gallery-item');
		
		filterBtns.forEach(btn => {
			btn.addEventListener('click', function() {
				// Remove active class from all buttons
				filterBtns.forEach(btn => btn.classList.remove('active'));
				
				// Add active class to clicked button
				this.classList.add('active');
				
				const filterValue = this.getAttribute('data-filter');
				
				galleryItems.forEach(item => {
					if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
						item.style.display = 'block';
						setTimeout(() => {
							item.style.opacity = '1';
							item.style.transform = 'scale(1)';
						}, 10);
					} else {
						item.style.opacity = '0';
						item.style.transform = 'scale(0.8)';
						setTimeout(() => {
							item.style.display = 'none';
						}, 300);
					}
				});
			});
		});
		
		// Lightbox options
		lightbox.option({
			'resizeDuration': 300,
			'wrapAround': true,
			'albumLabel': 'Image %1 of %2',
			'fadeDuration': 300,
			'imageFadeDuration': 300,
			'positionFromTop': 100
		});
	});
</script>
</html>