<?php
session_start();
require_once 'connect.php';

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if form was submitted
if (!isset($_POST['confirm_checkout'])) {
    $_SESSION['error_message'] = "No form submission detected.";
    header("location: checkout.php");
    exit();
}

// Get form data
$transaction_id = isset($_POST['transaction_id']) ? (int)$_POST['transaction_id'] : 0;
$bill_amount = isset($_POST['bill_amount']) ? floatval($_POST['bill_amount']) : 0;

// Validate
if ($transaction_id <= 0) {
    $_SESSION['error_message'] = "Invalid transaction ID.";
    header("location: checkout.php");
    exit();
}

if ($bill_amount <= 0) {
    $_SESSION['error_message'] = "Invalid bill amount.";
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}

// Check if transaction exists and is checked in
$check_query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'");

if (!$check_query) {
    $_SESSION['error_message'] = "Database error: " . $conn->error;
    header("location: checkout.php");
    exit();
}

if ($check_query->num_rows == 0) {
    $_SESSION['error_message'] = "Transaction not found or guest already checked out.";
    header("location: checkout.php");
    exit();
}

$transaction = $check_query->fetch_array();
$guest_name = $transaction['firstname'] . ' ' . $transaction['lastname'];

// Get current time for checkout time (Philippine Time +8)
$checkout_time = date("H:i:s", strtotime("+8 HOURS"));

// ================ UPDATE TRANSACTION TO CHECK OUT STATUS ================
$update_sql = "UPDATE `transaction` SET 
                `status` = 'Check Out', 
                `checkout_time` = '$checkout_time',
                `bill` = '$bill_amount'
                WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'";

if ($conn->query($update_sql)) {
    // Verify the update was successful
    $verify_query = $conn->query("SELECT * FROM `transaction` WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check Out'");
    
    if ($verify_query && $verify_query->num_rows > 0) {
        // Success
        $_SESSION['success_message'] = "Guest $guest_name has been checked out successfully. Total bill: Rs. " . number_format($bill_amount, 2);
        header("location: checkout.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to update status. Please try again.";
        header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
        exit();
    }
} else {
    $_SESSION['error_message'] = "Database error: " . $conn->error;
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}
?>