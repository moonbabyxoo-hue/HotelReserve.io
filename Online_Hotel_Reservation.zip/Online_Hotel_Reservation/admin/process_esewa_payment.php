<?php
session_start();
require_once 'connect.php';

if (!isset($_POST['process_esewa'])) {
    header("location: checkout.php");
    exit();
}

$transaction_id = isset($_POST['transaction_id']) ? (int)$_POST['transaction_id'] : 0;
$bill_amount = isset($_POST['bill_amount']) ? floatval($_POST['bill_amount']) : 0;
$esewa_txn_id = isset($_POST['esewa_txn_id']) ? trim($_POST['esewa_txn_id']) : '';

if ($transaction_id <= 0 || $bill_amount <= 0) {
    $_SESSION['error_message'] = "Invalid transaction data.";
    header("location: checkout.php");
    exit();
}

if (empty($esewa_txn_id)) {
    $_SESSION['error_message'] = "Please enter eSewa transaction ID.";
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}

// Check if transaction exists and is checked in
$check_query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'");

if ($check_query->num_rows == 0) {
    $_SESSION['error_message'] = "Transaction not found or guest already checked out.";
    header("location: checkout.php");
    exit();
}

$transaction = $check_query->fetch_array();
$guest_name = $transaction['firstname'] . ' ' . $transaction['lastname'];

// Get current time for checkout time
$checkout_time = date("H:i:s", strtotime("+8 HOURS"));

// Record eSewa payment
$payment_sql = "INSERT INTO `payments` 
                (`transaction_id`, `amount`, `payment_method`, `payment_txn_id`, `payment_status`, `payment_date`) 
                VALUES 
                ('$transaction_id', '$bill_amount', 'eSewa', '$esewa_txn_id', 'Completed', NOW())";

if (!$conn->query($payment_sql)) {
    $_SESSION['error_message'] = "Error recording payment: " . $conn->error;
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}

// Update transaction to Check Out status
$update_sql = "UPDATE `transaction` SET 
                `status` = 'Check Out', 
                `checkout_time` = '$checkout_time',
                `bill` = '$bill_amount'
                WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'";

if ($conn->query($update_sql)) {
    $_SESSION['success_message'] = "eSewa payment successful! Guest $guest_name has been checked out. Bill: Rs. " . number_format($bill_amount, 2);
    header("location: checkout.php");
} else {
    $_SESSION['error_message'] = "Error processing checkout: " . $conn->error;
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
}
exit();
?>