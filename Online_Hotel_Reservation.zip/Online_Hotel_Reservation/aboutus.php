<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - About Us</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 100px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY CONTAINER ===== */
			.container {
				width: 90%;
				max-width: 1400px;
				margin: 40px auto !important;
				padding: 0 !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white) !important;
				padding: 50px !important;
				border-radius: 30px !important;
				box-shadow: 0 20px 50px var(--eksa-shadow) !important;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦';
				position: absolute;
				top: 20px;
				right: 30px;
				font-size: 8rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
			}
			
			/* ===== LUXURY ABOUT SECTION ===== */
			.about-header {
				position: relative;
				margin-bottom: 40px;
			}
			
			.about-header h3 {
				font-size: 3rem !important;
				color: var(--eksa-navy) !important;
				margin: 0 0 20px 0 !important;
				position: relative;
				display: inline-block;
			}
			
			.about-header h3::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2.5rem;
			}
			
			.about-header h3::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2.5rem;
			}
			
			.about-content {
				display: flex;
				flex-wrap: wrap;
				gap: 40px;
				margin-bottom: 60px;
				align-items: center;
			}
			
			.about-text {
				flex: 1;
				min-width: 300px;
			}
			
			.about-text p {
				font-size: 1.1rem !important;
				line-height: 1.8 !important;
				color: var(--eksa-navy-light) !important;
				margin-bottom: 20px !important;
				position: relative;
				padding-left: 20px;
				border-left: 4px solid var(--eksa-gold);
			}
			
			.about-image {
				flex: 0 0 300px;
			}
			
			.about-image img {
				width: 100%;
				height: 300px;
				object-fit: cover;
				border-radius: 20px;
				box-shadow: 0 15px 40px var(--eksa-shadow-dark);
				border: 5px solid var(--eksa-white);
				outline: 2px solid var(--eksa-gold);
				transition: all 0.4s ease;
			}
			
			.about-image img:hover {
				transform: scale(1.02);
				box-shadow: 0 20px 50px rgba(196, 164, 132, 0.4);
			}
			
			/* ===== LUXURY ROOM CARDS ===== */
			.section-title {
				font-size: 2.5rem !important;
				color: var(--eksa-navy) !important;
				margin: 60px 0 40px !important;
				position: relative;
				text-align: center;
			}
			
			.section-title::after {
				content: '';
				position: absolute;
				bottom: -15px;
				left: 50%;
				transform: translateX(-50%);
				width: 100px;
				height: 3px;
				background: linear-gradient(to right, transparent, var(--eksa-gold), transparent);
			}
			
			.room-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
				gap: 30px;
				margin: 40px 0;
			}
			
			.room-card {
				background: linear-gradient(135deg, var(--eksa-white), var(--eksa-cream));
				border-radius: 20px;
				overflow: hidden;
				box-shadow: 0 10px 30px var(--eksa-shadow);
				transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
			}
			
			.room-card:hover {
				transform: translateY(-15px);
				box-shadow: 0 25px 50px var(--eksa-shadow-dark);
				border-color: var(--eksa-gold);
			}
			
			.room-image {
				position: relative;
				overflow: hidden;
				height: 250px;
			}
			
			.room-image img {
				width: 100%;
				height: 100%;
				object-fit: cover;
				transition: transform 0.8s ease;
			}
			
			.room-card:hover .room-image img {
				transform: scale(1.1);
			}
			
			.room-badge {
				position: absolute;
				top: 20px;
				right: 20px;
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 8px 20px;
				border-radius: 50px;
				font-weight: 700;
				font-size: 0.9rem;
				z-index: 10;
				box-shadow: 0 5px 15px rgba(0,0,0,0.2);
			}
			
			.room-info {
				padding: 25px;
				text-align: center;
			}
			
			.room-info h4 {
				color: var(--eksa-navy);
				font-size: 1.5rem;
				margin-bottom: 10px;
				font-weight: 700;
			}
			
			.room-type {
				color: var(--eksa-gold-dark);
				font-size: 0.9rem;
				text-transform: uppercase;
				letter-spacing: 2px;
				margin-bottom: 15px;
			}
			
			.room-price {
				font-size: 1.8rem;
				font-weight: 800;
				color: var(--eksa-navy);
				margin-bottom: 15px;
			}
			
			.room-price small {
				font-size: 0.9rem;
				color: var(--eksa-gold);
				font-weight: 400;
			}
			
			.room-price span {
				color: var(--eksa-gold-dark);
				font-size: 1rem;
			}
			
			.btn-book {
				background: transparent;
				border: 2px solid var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 12px 30px;
				border-radius: 50px;
				font-weight: 700;
				transition: all 0.3s ease;
				display: inline-block;
				text-decoration: none;
				width: 100%;
				position: relative;
				overflow: hidden;
				z-index: 1;
			}
			
			.btn-book::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				transition: left 0.4s ease;
				z-index: -1;
			}
			
			.btn-book:hover::before {
				left: 0;
			}
			
			.btn-book:hover {
				color: var(--eksa-navy-dark);
				border-color: transparent;
				transform: translateY(-3px);
				box-shadow: 0 10px 25px var(--eksa-gold-glow);
			}
			
			/* ===== LUXURY AMENITIES ===== */
			.amenities-section {
				margin-top: 60px;
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				padding: 50px;
				border-radius: 30px;
				color: var(--eksa-white);
				position: relative;
				overflow: hidden;
			}
			
			.amenities-section::before {
				content: '✦✦✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
			}
			
			.amenities-section h3 {
				color: var(--eksa-gold) !important;
				font-size: 2.2rem !important;
				margin-bottom: 30px !important;
				position: relative;
				display: inline-block;
			}
			
			.amenities-section h3::after {
				content: '';
				position: absolute;
				bottom: -10px;
				left: 0;
				width: 80px;
				height: 3px;
				background: var(--eksa-gold);
			}
			
			.amenities-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
				gap: 20px;
			}
			
			.amenity-item {
				display: flex;
				align-items: center;
				gap: 15px;
				padding: 12px 20px;
				background: rgba(255, 255, 255, 0.05);
				border-radius: 50px;
				transition: all 0.3s ease;
				border: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.amenity-item:hover {
				background: rgba(196, 164, 132, 0.1);
				border-color: var(--eksa-gold);
				transform: translateX(10px);
			}
			
			.amenity-item i {
				color: var(--eksa-gold);
				font-size: 1.2rem;
				width: 25px;
				text-align: center;
			}
			
			.amenity-item label {
				color: var(--eksa-white);
				font-size: 0.95rem;
				font-weight: 400;
				margin: 0;
				cursor: pointer;
			}
			
			/* ===== LUXURY HR ===== */
			.luxury-hr {
				margin: 60px 0;
				position: relative;
				text-align: center;
			}
			
			.luxury-hr hr {
				border: none !important;
				height: 2px !important;
				background: linear-gradient(to right, transparent, var(--eksa-gold), transparent) !important;
				position: relative;
			}
			
			.luxury-hr i {
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				background: var(--eksa-white);
				color: var(--eksa-gold);
				padding: 10px;
				font-size: 1.2rem;
				border-radius: 50%;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 992px) {
				.about-content {
					flex-direction: column;
				}
				
				.about-image {
					flex: 0 0 100%;
				}
				
				.panel-body {
					padding: 30px !important;
				}
				
				.about-header h3 {
					font-size: 2rem !important;
				}
			}
			
			@media (max-width: 768px) {
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li:not(:last-child)::after {
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.amenities-grid {
					grid-template-columns: 1fr;
				}
				
				.section-title {
					font-size: 2rem !important;
				}
			}
			
			@media (max-width: 480px) {
				.panel-body {
					padding: 20px !important;
				}
				
				.room-price {
					font-size: 1.4rem;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> Admin Login</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> User Login</a></li>
	</ul>
	
	<!-- LUXURY ABOUT CONTENT -->
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- ABOUT HEADER -->
				<div class="about-header">
					<strong><h3>About Hotel Eksa</h3></strong>
				</div>
				
				<!-- ABOUT CONTENT WITH IMAGE -->
				<div class="about-content">
					<div class="about-text">
						<p>Hotel Eksa unveils a celebrated balance of nostalgia and contemporary style, capturing its original Southern elegance, luxury, and decadence. Machuca tiles form cool geometric patterns in the hallways. Handcrafted hardwood floors contrast modern furnishings and amenities in our dramatic suites.</p>
						<p>The Hotel Eksa lifestyle offers guests the finest sensory indulgences: soothing organic toiletries, heirloom recipes passed through generations, and unmatched privacy and tranquility. Every corner tells a story of sophistication and timeless beauty.</p>
						<p style="border-left-color: var(--eksa-gold-dark);"><i class="fas fa-quote-left" style="color: var(--eksa-gold); margin-right: 10px;"></i> Where luxury meets legacy, and every guest becomes family.</p>
					</div>
					<div class="about-image">
						<img src = "images/about.jpg" alt="Hotel Eksa Luxury" />
					</div>
				</div>
				
				<!-- LUXURY DIVIDER -->
				<div class="luxury-hr">
					<hr style = "border:1px dotted #000;" />
					<i class="fas fa-star"></i>
				</div>
				
				<!-- ROOMS SECTION TITLE -->
				<h3 class="section-title">≼ Our Signature Rooms ≽</h3>
				
				<!-- ROOM GRID - ROW 1 -->
				<div class="room-grid">
					<div class="room-card">
						<div class="room-image">
							<img src = "images/1.jpg" alt="Standard Room" />
							<div class="room-badge">Best Value</div>
						</div>
						<div class="room-info">
							<h4>Standard Room</h4>
							<div class="room-type">Cozy Comfort</div>
							<div class="room-price">Rs.2,000 <small>/ night</small></div>
							<center><label style="color: var(--eksa-gold-dark);">Small Size Bed</label></center>
							<a href="reservation.php" class="btn-book">
								<i class="fas fa-calendar-check me-2"></i> Book Now
							</a>
						</div>
					</div>
					
					<div class="room-card">
						<div class="room-image">
							<img src = "images/2.jpg" alt="Extra Bed" />
							<div class="room-badge">Flexible</div>
						</div>
						<div class="room-info">
							<h4>Extra Bed</h4>
							<div class="room-type">Additional Comfort</div>
							<div class="room-price">Rs.800 <small>/ night</small></div>
							<center><label style="color: var(--eksa-gold-dark);">Rollaway Bed</label></center>
							<a href="reservation.php" class="btn-book">
								<i class="fas fa-calendar-check me-2"></i> Book Now
							</a>
						</div>
					</div>
					
					<div class="room-card">
						<div class="room-image">
							<img src = "images/3.jpg" alt="Superior Room" />
							<div class="room-badge">Popular</div>
						</div>
						<div class="room-info">
							<h4>Superior Room</h4>
							<div class="room-type">Medium Size Bed</div>
							<div class="room-price">Rs.2,400 <small>/ night</small></div>
							<center><label style="color: var(--eksa-gold-dark);">1 Medium Size Bed</label></center>
							<a href="reservation.php" class="btn-book">
								<i class="fas fa-calendar-check me-2"></i> Book Now
							</a>
						</div>
					</div>
				</div>
				
				<!-- ROOM GRID - ROW 2 -->
				<div class="room-grid">
					<div class="room-card">
						<div class="room-image">
							<img src = "images/4.jpg" alt="Super Deluxe" />
							<div class="room-badge">Luxury</div>
						</div>
						<div class="room-info">
							<h4>Super Deluxe</h4>
							<div class="room-type">2 Medium Beds</div>
							<div class="room-price">Rs.2,800 <small>/ night</small></div>
							<center><label style="color: var(--eksa-gold-dark);">2 Medium Size Beds</label></center>
							<a href="reservation.php" class="btn-book">
								<i class="fas fa-calendar-check me-2"></i> Book Now
							</a>
						</div>
					</div>
					
					<div class="room-card">
						<div class="room-image">
							<img src = "images/5.jpg" alt="Jr. Suite" />
							<div class="room-badge">Elegant</div>
						</div>
						<div class="room-info">
							<h4>Jr. Suite</h4>
							<div class="room-type">Matrimonial Bed</div>
							<div class="room-price">Rs.3,800 <small>/ night</small></div>
							<center><label style="color: var(--eksa-gold-dark);">Matrimonial Bed</label></center>
							<a href="reservation.php" class="btn-book">
								<i class="fas fa-calendar-check me-2"></i> Book Now
							</a>
						</div>
					</div>
					
					<div class="room-card">
						<div class="room-image">
							<img src = "images/6.jpg" alt="Executive Suite" />
							<div class="room-badge">Premium</div>
						</div>
						<div class="room-info">
							<h4>Executive Suite</h4>
							<div class="room-type">King Size Bed</div>
							<div class="room-price">Rs.4,000 <small>/ night</small></div>
							<center><label style="color: var(--eksa-gold-dark);">Matrimonial Bed</label></center>
							<a href="reservation.php" class="btn-book">
								<i class="fas fa-calendar-check me-2"></i> Book Now
							</a>
						</div>
					</div>
				</div>
				
				<!-- LUXURY AMENITIES SECTION -->
				<div class="amenities-section">
					<strong><h3><i class="fas fa-concierge-bell me-3" style="color: var(--eksa-gold);"></i> Amenities & Services</h3></strong>
					<div class="amenities-grid">
						<div class="amenity-item">
							<i class="fas fa-clock"></i>
							<label>24 Hour room service</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-tv"></i>
							<label>21" Flat screen TV with cable service</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-shower"></i>
							<label>Hot & cold shower</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-wine-bottle"></i>
							<label>Refrigerator and mini bar</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-mug-hot"></i>
							<label>Coffee & tea set, bottled water</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-wind"></i>
							<label>Hair dryer in suite rooms</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-shield-alt"></i>
							<label>Personal safety boxes in every room</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-tshirt"></i>
							<label>Laundry & pressing</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-wifi"></i>
							<label>Free use Wifi</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-spa"></i>
							<label>In room massage services</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-lock"></i>
							<label>Personal Safe in Every Room</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-glass-cheers"></i>
							<label>Mini Bar</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-building"></i>
							<label>7 Function & Meeting Rooms</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-car"></i>
							<label>Airport Transfers & City Tour</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-swimmer"></i>
							<label>Swimming Pool</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-gift"></i>
							<label>Gift Shop</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-briefcase"></i>
							<label>Business Center</label>
						</div>
						<div class="amenity-item">
							<i class="fas fa-parking"></i>
							<label>Free Parking for Guest</label>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Crafted with Elegance <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script>
	// Add active class to current menu item
	document.addEventListener('DOMContentLoaded', function() {
		var currentPage = window.location.pathname.split('/').pop();
		var menuItems = document.querySelectorAll('#menu li a');
		
		menuItems.forEach(function(item) {
			if (item.getAttribute('href') === currentPage) {
				item.style.background = 'var(--eksa-gold)';
				item.style.color = 'var(--eksa-navy)';
			}
		});
	});
</script>
</html>