<?php
// navbar.php
// Check if user is logged in
$is_logged_in = isset($_SESSION['user_id']);
$user_name = '';

if ($is_logged_in && isset($_SESSION['user_name'])) {
    $user_name = $_SESSION['user_name'];
} elseif ($is_logged_in && isset($_SESSION['user_id'])) {
    // Fetch user name from database if not in session
    require_once 'admin/connect.php';
    $user_id = $_SESSION['user_id'];
    $query = $conn->query("SELECT firstname, lastname FROM `guest` WHERE `guest_id` = '$user_id'");
    if ($query && $query->num_rows > 0) {
        $user = $query->fetch_array();
        $user_name = $user['firstname'] . ' ' . $user['lastname'];
        $_SESSION['user_name'] = $user_name;
    }
}
?>
<!-- LUXURY NAVIGATION -->
<nav style="background-color:rgba(0, 0, 0, 0.1);" class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
                Hotel Eksa
            </a>
        </div>
        
        <ul class="nav navbar-nav">
            <li <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
            </li>
            <li <?php echo basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? 'class="active"' : ''; ?>>
                <a href="aboutus.php"><i class="fas fa-info-circle"></i> About us</a>
            </li>
            <li <?php echo basename($_SERVER['PHP_SELF']) == 'contactus.php' ? 'class="active"' : ''; ?>>
                <a href="contactus.php"><i class="fas fa-phone-alt"></i> Contact us</a>
            </li>
            <li <?php echo basename($_SERVER['PHP_SELF']) == 'gallery.php' ? 'class="active"' : ''; ?>>
                <a href="gallery.php"><i class="fas fa-images"></i> Gallery</a>
            </li>
            <li <?php echo basename($_SERVER['PHP_SELF']) == 'dineandlounge.php' ? 'class="active"' : ''; ?>>
                <a href="dineandlounge.php"><i class="fas fa-utensils"></i> Dine & Lounge</a>
            </li>
            <li <?php echo basename($_SERVER['PHP_SELF']) == 'reservation.php' ? 'class="active"' : ''; ?>>
                <a href="reservation.php"><i class="fas fa-calendar-check"></i> Make a reservation</a>
            </li>
        </ul>
        
        <ul class="nav navbar-nav pull-right">
            <?php if ($is_logged_in): ?>
                <!-- User is logged in - Show user info and logout -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
                        <span style="color: var(--eksa-white); font-weight: 600;"><?php echo htmlspecialchars($user_name); ?></span>
                        <span class="caret" style="color: var(--eksa-gold);"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="user_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                        <li><a href="my_bookings.php"><i class="fas fa-calendar-check"></i> My Bookings</a></li>
                        <li><a href="user_profile.php"><i class="fas fa-user-edit"></i> Edit Profile</a></li>
                        <li class="divider"></li>
                        <li><a href="user_logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            <?php else: ?>
                <!-- User not logged in - Show login/register -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user" style="color: var(--eksa-gold);"></i> 
                        <span style="color: var(--eksa-white);">Account</span>
                        <span class="caret" style="color: var(--eksa-gold);"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="user_login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                        <li><a href="user_login.php#register"><i class="fas fa-user-plus"></i> Register</a></li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<style>
    /* Navbar active state */
    .nav.navbar-nav li.active a {
        background: rgba(196, 164, 132, 0.2) !important;
        color: var(--eksa-gold) !important;
        border-radius: 30px;
    }
    
    .nav.navbar-nav li a {
        transition: all 0.3s ease;
    }
    
    .nav.navbar-nav li a:hover {
        background: rgba(196, 164, 132, 0.1) !important;
        color: var(--eksa-gold) !important;
    }
    
    /* Dropdown menu styling */
    .dropdown-menu {
        background: linear-gradient(145deg, var(--eksa-navy), var(--eksa-navy-dark));
        border: 2px solid var(--eksa-gold);
        border-radius: 15px;
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
        padding: 10px;
    }
    
    .dropdown-menu li a {
        color: white !important;
        padding: 10px 20px;
        border-radius: 10px;
        transition: all 0.3s ease;
    }
    
    .dropdown-menu li a i {
        color: var(--eksa-gold);
        margin-right: 10px;
    }
    
    .dropdown-menu li a:hover {
        background: rgba(196, 164, 132, 0.2) !important;
        color: var(--eksa-gold) !important;
    }
    
    .divider {
        height: 1px;
        background: rgba(196, 164, 132, 0.3);
        margin: 10px 0;
    }
</style>