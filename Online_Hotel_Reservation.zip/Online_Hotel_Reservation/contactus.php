<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Contact Us</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 100px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY CONTACT CONTAINER ===== */
			.container {
				width: 90%;
				max-width: 1200px;
				margin: 40px auto !important;
				padding: 0 !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white) !important;
				padding: 60px !important;
				border-radius: 30px !important;
				box-shadow: 0 30px 60px var(--eksa-shadow) !important;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦✦✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			.panel-body::after {
				content: '✦✦✦';
				position: absolute;
				top: -20px;
				left: -20px;
				font-size: 8rem;
				color: rgba(196, 164, 132, 0.03);
				font-family: serif;
				transform: rotate(15deg);
			}
			
			/* ===== LUXURY CONTACT HEADER ===== */
			.contact-header {
				text-align: center;
				margin-bottom: 50px;
				position: relative;
			}
			
			.contact-header h3 {
				font-size: 3rem !important;
				color: var(--eksa-navy) !important;
				margin: 0 0 20px 0 !important;
				position: relative;
				display: inline-block;
			}
			
			.contact-header h3::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2.5rem;
			}
			
			.contact-header h3::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2.5rem;
			}
			
			.contact-header p {
				color: var(--eksa-navy-light);
				font-size: 1.1rem;
				max-width: 600px;
				margin: 0 auto;
				position: relative;
			}
			
			/* ===== LUXURY HOTEL IMAGE ===== */
			.hotel-image-container {
				position: relative;
				width: 100%;
				max-width: 500px;
				margin: 0 auto 50px;
				border-radius: 20px;
				overflow: hidden;
				box-shadow: 0 20px 40px var(--eksa-shadow-dark);
				border: 5px solid var(--eksa-white);
				outline: 2px solid var(--eksa-gold);
				transform: rotate(0deg);
				transition: all 0.5s ease;
			}
			
			.hotel-image-container:hover {
				transform: rotate(1deg) scale(1.02);
				box-shadow: 0 30px 60px rgba(196, 164, 132, 0.4);
			}
			
			.hotel-image-container img {
				width: 100%;
				height: 350px;
				object-fit: cover;
				display: block;
				transition: transform 0.8s ease;
			}
			
			.hotel-image-container:hover img {
				transform: scale(1.1);
			}
			
			.image-overlay {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, rgba(10,28,47,0.3), rgba(10,28,47,0.6));
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				opacity: 0;
				transition: opacity 0.4s ease;
				color: var(--eksa-white);
			}
			
			.hotel-image-container:hover .image-overlay {
				opacity: 1;
			}
			
			.image-overlay i {
				font-size: 3rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
			}
			
			.image-overlay span {
				font-size: 1.2rem;
				font-weight: 600;
				letter-spacing: 3px;
			}
			
			/* ===== LUXURY CONTACT INFO CARDS ===== */
			.contact-info-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
				gap: 30px;
				margin: 50px 0;
			}
			
			.contact-card {
				background: linear-gradient(135deg, var(--eksa-white), var(--eksa-cream));
				padding: 40px 30px;
				border-radius: 20px;
				text-align: center;
				box-shadow: 0 15px 35px var(--eksa-shadow);
				transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
				overflow: hidden;
			}
			
			.contact-card:hover {
				transform: translateY(-15px);
				box-shadow: 0 25px 50px var(--eksa-shadow-dark);
				border-color: var(--eksa-gold);
			}
			
			.contact-card::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(90deg, transparent, rgba(196, 164, 132, 0.1), transparent);
				transition: left 0.6s ease;
			}
			
			.contact-card:hover::before {
				left: 100%;
			}
			
			.card-icon {
				width: 80px;
				height: 80px;
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				border-radius: 50%;
				display: flex;
				align-items: center;
				justify-content: center;
				margin: 0 auto 25px;
				border: 3px solid var(--eksa-gold);
				transition: all 0.3s ease;
			}
			
			.contact-card:hover .card-icon {
				transform: scale(1.1);
				background: linear-gradient(135deg, var(--eksa-navy-dark), var(--eksa-navy));
				border-color: var(--eksa-white);
			}
			
			.card-icon i {
				font-size: 2rem;
				color: var(--eksa-gold);
				transition: all 0.3s ease;
			}
			
			.contact-card:hover .card-icon i {
				color: var(--eksa-white);
				transform: scale(1.1);
			}
			
			.contact-card h4 {
				color: var(--eksa-navy);
				font-size: 1.5rem;
				margin-bottom: 15px;
				font-weight: 700;
			}
			
			.contact-card p {
				color: var(--eksa-navy-light);
				font-size: 1.1rem;
				margin: 5px 0;
				line-height: 1.6;
			}
			
			.contact-card .highlight {
				color: var(--eksa-gold-dark);
				font-weight: 700;
			}
			
			/* ===== LUXURY CONTACT FORM ===== */
			.contact-form-section {
				margin-top: 60px;
				background: linear-gradient(135deg, var(--eksa-cream), var(--eksa-white));
				padding: 50px;
				border-radius: 30px;
				position: relative;
				overflow: hidden;
			}
			
			.contact-form-section::before {
				content: '✉';
				position: absolute;
				bottom: -30px;
				right: -30px;
				font-size: 15rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(15deg);
			}
			
			.form-header {
				text-align: center;
				margin-bottom: 40px;
			}
			
			.form-header h4 {
				color: var(--eksa-navy);
				font-size: 2rem;
				margin-bottom: 15px;
				position: relative;
				display: inline-block;
			}
			
			.form-header h4::after {
				content: '';
				position: absolute;
				bottom: -10px;
				left: 50%;
				transform: translateX(-50%);
				width: 80px;
				height: 3px;
				background: linear-gradient(to right, transparent, var(--eksa-gold), transparent);
			}
			
			.form-header p {
				color: var(--eksa-navy-light);
				font-size: 1rem;
			}
			
			.contact-form {
				display: grid;
				grid-template-columns: repeat(2, 1fr);
				gap: 20px;
				max-width: 800px;
				margin: 0 auto;
			}
			
			.form-group {
				position: relative;
			}
			
			.form-group.full-width {
				grid-column: span 2;
			}
			
			.form-group input,
			.form-group textarea {
				width: 100%;
				padding: 15px 20px;
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 15px;
				font-size: 1rem;
				transition: all 0.3s ease;
				background: var(--eksa-white);
				font-family: 'Poppins', sans-serif;
			}
			
			.form-group input:focus,
			.form-group textarea:focus {
				outline: none;
				border-color: var(--eksa-gold);
				box-shadow: 0 0 0 5px var(--eksa-gold-glow);
				transform: translateY(-2px);
			}
			
			.form-group input::placeholder,
			.form-group textarea::placeholder {
				color: #999;
				font-weight: 300;
			}
			
			.form-group textarea {
				height: 150px;
				resize: none;
			}
			
			.btn-send {
				grid-column: span 2;
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				color: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				padding: 15px 40px;
				border-radius: 50px;
				font-size: 1.1rem;
				font-weight: 700;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				position: relative;
				overflow: hidden;
				z-index: 1;
				margin-top: 20px;
			}
			
			.btn-send::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				transition: left 0.4s ease;
				z-index: -1;
			}
			
			.btn-send:hover::before {
				left: 0;
			}
			
			.btn-send:hover {
				color: var(--eksa-navy-dark);
				border-color: transparent;
				transform: translateY(-3px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
			}
			
			.btn-send i {
				margin-right: 10px;
				transition: transform 0.3s ease;
			}
			
			.btn-send:hover i {
				transform: translateX(5px);
			}
			
			/* ===== LUXURY MAP SECTION ===== */
			.map-section {
				margin-top: 50px;
				text-align: center;
			}
			
			.map-placeholder {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				padding: 40px;
				border-radius: 20px;
				color: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				position: relative;
				overflow: hidden;
			}
			
			.map-placeholder::before {
				content: '📍';
				position: absolute;
				bottom: -20px;
				left: -20px;
				font-size: 8rem;
				color: rgba(196, 164, 132, 0.1);
				transform: rotate(-15deg);
			}
			
			.map-placeholder i {
				font-size: 3rem;
				color: var(--eksa-gold);
				margin-bottom: 20px;
			}
			
			.map-placeholder h4 {
				color: var(--eksa-gold);
				font-size: 1.8rem;
				margin-bottom: 15px;
			}
			
			.map-placeholder p {
				color: var(--eksa-cream);
				font-size: 1.1rem;
				margin-bottom: 20px;
			}
			
			.btn-map {
				background: transparent;
				color: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				padding: 12px 30px;
				border-radius: 50px;
				font-weight: 600;
				transition: all 0.3s ease;
				display: inline-block;
				text-decoration: none;
			}
			
			.btn-map:hover {
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				transform: translateY(-3px);
				box-shadow: 0 10px 25px var(--eksa-gold-glow);
			}
			
			/* ===== LUXURY SOCIAL MEDIA ===== */
			.social-section {
				margin-top: 50px;
				text-align: center;
			}
			
			.social-section h4 {
				color: var(--eksa-navy);
				font-size: 1.5rem;
				margin-bottom: 25px;
				position: relative;
				display: inline-block;
			}
			
			.social-icons {
				display: flex;
				justify-content: center;
				gap: 20px;
				flex-wrap: wrap;
			}
			
			.social-icon {
				width: 55px;
				height: 55px;
				border-radius: 50%;
				display: flex;
				align-items: center;
				justify-content: center;
				color: var(--eksa-white);
				font-size: 1.5rem;
				transition: all 0.4s ease;
				text-decoration: none;
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				border: 2px solid var(--eksa-gold);
			}
			
			.social-icon:hover {
				transform: translateY(-8px) scale(1.1);
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				border-color: var(--eksa-navy);
				box-shadow: 0 10px 25px var(--eksa-gold-glow);
			}
			
			/* ===== LUXURY BUSINESS HOURS ===== */
			.hours-section {
				margin-top: 50px;
				background: linear-gradient(135deg, var(--eksa-cream), var(--eksa-white));
				padding: 40px;
				border-radius: 20px;
				border: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.hours-section h4 {
				color: var(--eksa-navy);
				font-size: 1.5rem;
				margin-bottom: 25px;
				text-align: center;
			}
			
			.hours-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
				gap: 15px;
				max-width: 600px;
				margin: 0 auto;
			}
			
			.hour-item {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 12px 20px;
				background: var(--eksa-white);
				border-radius: 50px;
				transition: all 0.3s ease;
				border: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.hour-item:hover {
				background: rgba(196, 164, 132, 0.1);
				border-color: var(--eksa-gold);
				transform: translateX(5px);
			}
			
			.hour-item span:first-child {
				font-weight: 600;
				color: var(--eksa-navy);
			}
			
			.hour-item span:last-child {
				color: var(--eksa-gold-dark);
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 992px) {
				.panel-body {
					padding: 40px !important;
				}
				
				.contact-header h3 {
					font-size: 2.5rem !important;
				}
			}
			
			@media (max-width: 768px) {
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li:not(:last-child)::after {
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.panel-body {
					padding: 30px !important;
				}
				
				.contact-form {
					grid-template-columns: 1fr;
				}
				
				.form-group.full-width {
					grid-column: span 1;
				}
				
				.btn-send {
					grid-column: span 1;
				}
				
				.contact-header h3 {
					font-size: 2rem !important;
				}
				
				.contact-header h3::before,
				.contact-header h3::after {
					font-size: 1.8rem;
				}
				
				.hotel-image-container img {
					height: 250px;
				}
			}
			
			@media (max-width: 480px) {
				.panel-body {
					padding: 20px !important;
				}
				
				.contact-card {
					padding: 30px 20px;
				}
				
				.contact-form-section {
					padding: 30px 20px;
				}
				
				.hour-item {
					flex-direction: column;
					gap: 5px;
					text-align: center;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> Admin Login</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> User Login</a></li>
	</ul>
	
	<!-- LUXURY CONTENT -->
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- CONTACT HEADER -->
				<div class="contact-header">
					<strong><h3>Contact Hotel Eksa</h3></strong>
					<p>Experience unparalleled luxury and personalized service</p>
				</div>
				
				<!-- HOTEL IMAGE WITH OVERLAY -->
				<div class="hotel-image-container">
					<img src = "images/hotel.jpg" alt="Hotel Eksa Luxury" />
					<div class="image-overlay">
						<i class="fas fa-crown"></i>
						<span>HOTEL EKSA</span>
					</div>
				</div>
				
				<!-- CONTACT INFO CARDS -->
				<div class="contact-info-grid">
					<div class="contact-card">
						<div class="card-icon">
							<i class="fas fa-phone-alt"></i>
						</div>
						<h4>Phone</h4>
						<p class="highlight">+977 9811111111</p>
						<p>+977 9800000000</p>
						<p style="margin-top: 10px; font-size: 0.9rem;">24/7 Services</p>
					</div>
					
					<div class="contact-card">
						<div class="card-icon">
							<i class="fas fa-envelope"></i>
						</div>
						<h4>Email</h4>
						<p class="highlight">reservations@hoteleksa.com</p>
						<p>services@hoteleksa.com</p>
						<p style="margin-top: 10px; font-size: 0.9rem;">events@hoteleksa.com</p>
					</div>
					
					<div class="contact-card">
						<div class="card-icon">
							<i class="fas fa-map-marker-alt"></i>
						</div>
						<h4>Location</h4>
						<p>Khairahani-06, Parsa</p>
						<p>Chitwan, Nepal</p>
						<p style="margin-top: 10px; color: var(--eksa-gold-dark);">View on map →</p>
					</div>
				</div>
				
				<!-- CONTACT FORM -->
				<div class="contact-form-section">
					<div class="form-header">
						<h4>Send us a Message</h4>
						<p>We'll respond within 24 hours</p>
					</div>
					
					<form class="contact-form" id="contactForm">
						<div class="form-group">
							<input type="text" placeholder="Your Full Name" required>
						</div>
						<div class="form-group">
							<input type="email" placeholder="Your Email" required>
						</div>
						<div class="form-group full-width">
							<input type="text" placeholder="Subject" required>
						</div>
						<div class="form-group full-width">
							<textarea placeholder="Your Message" required></textarea>
						</div>
						<button type="submit" class="btn-send">
							<i class="fas fa-paper-plane"></i> SEND MESSAGE
						</button>
					</form>
				</div>
				
				<!-- MAP SECTION -->
				<!-- Location Card with Google Maps Embed -->
<div class="contact-card" style="padding: 0; overflow: hidden; border-radius: 20px;">
    <!-- Google Maps Embed -->
    <div style="width: 100%; height: 250px;">
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3535.434059317608!2d84.56702667426322!3d27.61107037623781!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3994e90044fba867%3A0xcdba1ebb8e896e07!2sKhairahani%208%20parsa!5e0!3m2!1sen!2snp!4v1770844261534!5m2!1sen!2snp" 
            width="100%" 
            height="100%" 
            style="border: 0;" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    </div>
    
    <!-- Location Info -->
    <div style="padding: 20px; text-align: center; background: white;">
        <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 10px;">
            <i class="fas fa-map-marker-alt" style="color: var(--eksa-gold); font-size: 1.5rem;"></i>
            <h4 style="color: var(--eksa-navy); margin: 0; font-size: 1.3rem;">Our Location</h4>
        </div>
        <p style="margin: 5px 0; color: var(--eksa-navy); font-weight: 600;">Hotel Eksa</p>
        <p style="margin: 5px 0; color: var(--eksa-navy-light);">Khairahani-06, Parsa</p>
        <p style="margin: 5px 0; color: var(--eksa-navy-light);">Chitwan, Nepal</p>
        <a href="https://www.google.com/maps/search/Khairahani-06,+Parsa,+Chitwan,+Nepal" 
           target="_blank" 
           style="display: inline-block; margin-top: 15px; color: var(--eksa-gold-dark); font-weight: 600; text-decoration: none;">
            <i class="fas fa-directions"></i> Get Directions 
            <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</div>
				
				<!-- SOCIAL MEDIA -->
				<div class="social-section">
					<h4>Follow Us</h4>
					<div class="social-icons">
						<a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
						<a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
						<a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
						<a href="#" class="social-icon"><i class="fab fa-youtube"></i></a>
						<a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
					</div>
				</div>
				
				<!-- BUSINESS HOURS -->
				<div class="hours-section">
					<h4>Business Hours</h4>
					<div class="hours-grid">
						<div class="hour-item">
							<span>Monday - Friday</span>
							<span>9:00 AM - 10:00 PM</span>
						</div>
						<div class="hour-item">
							<span>Saturday</span>
							<span>10:00 AM - 11:00 PM</span>
						</div>
						<div class="hour-item">
							<span>Sunday</span>
							<span>10:00 AM - 9:00 PM</span>
						</div>
						<div class="hour-item">
							<span>Holidays</span>
							<span>11:00 AM - 8:00 PM</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Created by Pujan Pathak <i class="fas fa-heart"></i>
		</div>
	</div>
	
	<script>
		// Contact form submission
		document.getElementById('contactForm').addEventListener('submit', function(e) {
			e.preventDefault();
			
			swal({
				title: 'Message Sent!',
				text: 'Thank you for contacting Hotel Eksa. We will respond within 24 hours.',
				icon: 'success',
				button: 'OK'
			}).then(() => {
				this.reset();
			});
		});
		
		// Add active class to current menu item
		document.addEventListener('DOMContentLoaded', function() {
			var currentPage = window.location.pathname.split('/').pop();
			var menuItems = document.querySelectorAll('#menu li a');
			
			menuItems.forEach(function(item) {
				if (item.getAttribute('href') === currentPage) {
					item.style.background = 'var(--eksa-gold)';
					item.style.color = 'var(--eksa-navy)';
				}
			});
		});
	</script>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script src = "https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</html>