<?php
// ==================== START SESSION AT THE VERY TOP ====================
session_start();
require_once 'connect.php';

// Disable error reporting in production
error_reporting(0);
ini_set('display_errors', 0);

// Check if form was submitted
if (!isset($_POST['add_form'])) {
    $_SESSION['error_message'] = "No form submission detected.";
    header("location: reserve.php");
    exit();
}

// Get and sanitize form data
$room_no = isset($_POST['room_no']) ? (int)$_POST['room_no'] : 0;
$days = isset($_POST['days']) ? (int)$_POST['days'] : 0;
$extra_bed = isset($_POST['extra_bed']) ? (int)$_POST['extra_bed'] : 0;
$transaction_id = isset($_REQUEST['transaction_id']) ? (int)$_REQUEST['transaction_id'] : 0;

// Validate inputs
if ($transaction_id <= 0) {
    $_SESSION['error_message'] = "Invalid transaction ID.";
    header("location: reserve.php");
    exit();
}

if ($room_no <= 0) {
    $_SESSION['error_message'] = "Please enter a valid room number.";
    header("location: confirm_reserve.php?transaction_id=" . $transaction_id);
    exit();
}

if ($days <= 0) {
    $_SESSION['error_message'] = "Please enter a valid number of nights.";
    header("location: confirm_reserve.php?transaction_id=" . $transaction_id);
    exit();
}

if ($extra_bed < 0) {
    $extra_bed = 0;
}

// Check if transaction exists
$check_transaction = $conn->query("SELECT * FROM `transaction` WHERE `transaction_id` = '$transaction_id'") or die(mysqli_error($conn));

if ($check_transaction->num_rows == 0) {
    $_SESSION['error_message'] = "Transaction not found.";
    header("location: reserve.php");
    exit();
}

$transaction_data = $check_transaction->fetch_array();

// Check if transaction is already checked in
if ($transaction_data['status'] == 'Check In') {
    $_SESSION['error_message'] = "This guest is already checked in.";
    header("location: checkin.php");
    exit();
}

// Check if room is already occupied by ANOTHER transaction
$check_room = $conn->query("SELECT * FROM `transaction` WHERE `room_no` = '$room_no' AND `status` = 'Check In' AND `transaction_id` != '$transaction_id'") or die(mysqli_error($conn));

if ($check_room->num_rows > 0) {
    $_SESSION['error_message'] = "Room #$room_no is not available. Please select another room.";
    header("location: confirm_reserve.php?transaction_id=" . $transaction_id);
    exit();
}

// Get guest details for success message
$guest_query = $conn->query("SELECT * FROM `guest` WHERE `guest_id` = '{$transaction_data['guest_id']}'") or die(mysqli_error($conn));
$guest_data = $guest_query->fetch_array();
$guest_name = $guest_data['firstname'] . ' ' . $guest_data['lastname'];

// Get room details for price
$room_query = $conn->query("SELECT * FROM `room` WHERE `room_id` = '{$transaction_data['room_id']}'") or die(mysqli_error($conn));
$room_data = $room_query->fetch_array();
$room_price = isset($room_data['price']) ? floatval($room_data['price']) : 0;

// Calculate totals
$room_total = $room_price * $days;
$extra_bed_total = 800 * $extra_bed;
$total_bill = $room_total + $extra_bed_total;

// Calculate checkout date
$checkin_date = $transaction_data['checkin'];
$checkout_date = date("Y-m-d", strtotime($checkin_date . " + " . $days . " days"));

// Get current time for check-in time (Philippine Time +8)
$checkin_time = date("H:i:s", strtotime("+8 HOURS"));

// ==================== UPDATE THE TRANSACTION ====================
$update_sql = "UPDATE `transaction` SET 
                `room_no` = '$room_no', 
                `days` = '$days', 
                `extra_bed` = '$extra_bed', 
                `status` = 'Check In', 
                `checkin_time` = '$checkin_time', 
                `checkout` = '$checkout_date', 
                `bill` = '$total_bill' 
                WHERE `transaction_id` = '$transaction_id'";

$update_query = $conn->query($update_sql);

if ($update_query) {
    // Verify the update was successful
    $verify_query = $conn->query("SELECT * FROM `transaction` WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'");
    
    if ($verify_query && $verify_query->num_rows > 0) {
        // Success - set success message
        $_SESSION['success_message'] = "Guest $guest_name has been successfully checked into Room #$room_no.";
        
        // Redirect to checkin.php
        header("location: checkin.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to update status. Please try again.";
        header("location: confirm_reserve.php?transaction_id=" . $transaction_id);
        exit();
    }
} else {
    $_SESSION['error_message'] = "Database error: " . mysqli_error($conn);
    header("location: confirm_reserve.php?transaction_id=" . $transaction_id);
    exit();
}
?>