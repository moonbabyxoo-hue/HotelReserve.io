<?php
session_start();
require_once 'connect.php';

// Get POST data from AJAX
$transaction_id = isset($_POST['transaction_id']) ? (int)$_POST['transaction_id'] : 0;
$bill_amount = isset($_POST['bill_amount']) ? floatval($_POST['bill_amount']) : 0;
$khalti_token = isset($_POST['khalti_token']) ? $_POST['khalti_token'] : '';
$khalti_txn_id = isset($_POST['khalti_txn_id']) ? $_POST['khalti_txn_id'] : '';
$khalti_mobile = isset($_POST['khalti_mobile']) ? $_POST['khalti_mobile'] : '';

if ($transaction_id <= 0 || $bill_amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid transaction data']);
    exit();
}

// Verify Khalti payment with Khalti API
$args = http_build_query(array(
    'token' => $khalti_token,
    'amount'  => $bill_amount * 100 // Amount in paisa
));

$url = "https://khalti.com/api/v2/payment/verify/";

# Make the call using API.
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $args);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// Replace with your Khalti secret key
$headers = ['Authorization: Key test_secret_key_f59e8b7d18b4499ca40f68195a846e9b'];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Execute curl
$response = curl_exec($ch);
$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($status_code == 200) {
    // Payment verified successfully
    $response_data = json_decode($response, true);
    
    // Check if transaction exists and is checked in
    $check_query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'");
    
    if ($check_query->num_rows == 0) {
        echo json_encode(['status' => 'error', 'message' => 'Transaction not found']);
        exit();
    }
    
    $transaction = $check_query->fetch_array();
    $guest_name = $transaction['firstname'] . ' ' . $transaction['lastname'];
    
    // Get current time for checkout time
    $checkout_time = date("H:i:s", strtotime("+8 HOURS"));
    
    // Record Khalti payment
    $payment_sql = "INSERT INTO `payments` 
                    (`transaction_id`, `amount`, `payment_method`, `payment_txn_id`, `khalti_mobile`, `payment_status`, `payment_date`) 
                    VALUES 
                    ('$transaction_id', '$bill_amount', 'Khalti', '$khalti_txn_id', '$khalti_mobile', 'Completed', NOW())";
    $conn->query($payment_sql);
    
    // Update transaction to Check Out status
    $update_sql = "UPDATE `transaction` SET 
                    `status` = 'Check Out', 
                    `checkout_time` = '$checkout_time',
                    `bill` = '$bill_amount'
                    WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'";
    
    if ($conn->query($update_sql)) {
        echo json_encode([
            'status' => 'success', 
            'message' => 'Payment successful! Guest checked out.',
            'guest_name' => $guest_name,
            'bill_amount' => $bill_amount
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Payment verification failed']);
}
exit();
?>