<?php
session_start();
require_once 'connect.php';

// Check if form was submitted
if (!isset($_POST['confirm_cash_payment'])) {
    $_SESSION['error_message'] = "No form submission detected.";
    header("location: checkout.php");
    exit();
}

// Get form data
$transaction_id = isset($_POST['transaction_id']) ? (int)$_POST['transaction_id'] : 0;
$bill_amount = isset($_POST['bill_amount']) ? floatval($_POST['bill_amount']) : 0;
$cash_received = isset($_POST['cash_received']) ? 1 : 0;

// Validate
if ($transaction_id <= 0) {
    $_SESSION['error_message'] = "Invalid transaction ID.";
    header("location: checkout.php");
    exit();
}

if ($bill_amount <= 0) {
    $_SESSION['error_message'] = "Invalid bill amount.";
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}

if ($cash_received != 1) {
    $_SESSION['error_message'] = "Please confirm cash payment received.";
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}

// Check if transaction exists and is checked in
$check_query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'");

if (!$check_query) {
    $_SESSION['error_message'] = "Database error: " . $conn->error;
    header("location: checkout.php");
    exit();
}

if ($check_query->num_rows == 0) {
    $_SESSION['error_message'] = "Transaction not found or guest already checked out.";
    header("location: checkout.php");
    exit();
}

$transaction = $check_query->fetch_array();
$guest_name = $transaction['firstname'] . ' ' . $transaction['lastname'];

// Get current time for checkout time
$checkout_time = date("H:i:s", strtotime("+8 HOURS"));
$payment_txn_id = 'CASH' . date('Ymd') . $transaction_id . rand(100, 999);

// Record cash payment
$payment_sql = "INSERT INTO `payments` 
                (`transaction_id`, `amount`, `payment_method`, `payment_txn_id`, `payment_status`, `payment_date`) 
                VALUES 
                ('$transaction_id', '$bill_amount', 'Cash', '$payment_txn_id', 'Completed', NOW())";

if (!$conn->query($payment_sql)) {
    $_SESSION['error_message'] = "Error recording payment: " . $conn->error;
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}

// Update transaction to Check Out status
$update_sql = "UPDATE `transaction` SET 
                `status` = 'Check Out', 
                `checkout_time` = '$checkout_time',
                `bill` = '$bill_amount'
                WHERE `transaction_id` = '$transaction_id' AND `status` = 'Check In'";

if ($conn->query($update_sql)) {
    $_SESSION['success_message'] = "Cash payment received! Guest $guest_name has been checked out. Total bill: Rs. " . number_format($bill_amount, 2);
    header("location: checkout.php");
    exit();
} else {
    $_SESSION['error_message'] = "Error processing checkout: " . $conn->error;
    header("location: confirm_checkout.php?transaction_id=" . $transaction_id);
    exit();
}
?>