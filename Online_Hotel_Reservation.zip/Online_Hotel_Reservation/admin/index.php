<?php
// ==================== START SESSION AT THE VERY TOP ====================
session_start();
require_once "connect.php";
?><!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Admin Login</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - ADMIN ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				height: 100vh;
				display: flex;
				flex-direction: column;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY ADMIN LOGIN CARD ===== */
			.container {
				position: relative;
				z-index: 10;
				flex: 1;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			
			.login-wrapper {
				width: 100%;
				max-width: 450px;
				margin: 0 auto;
				padding: 20px;
			}
			
			.login-card {
				background: var(--eksa-white);
				border-radius: 30px;
				overflow: hidden;
				box-shadow: 0 30px 60px var(--eksa-shadow-dark);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
				animation: slideUp 0.6s ease-out;
			}
			
			.login-card::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 8rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			.login-header {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				padding: 40px 30px;
				text-align: center;
				border-bottom: 3px solid var(--eksa-gold);
				position: relative;
			}
			
			.login-header i {
				font-size: 3.5rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
				background: rgba(255,255,255,0.1);
				padding: 20px;
				border-radius: 50%;
				border: 2px solid var(--eksa-gold);
			}
			
			.login-header h4 {
				color: var(--eksa-gold);
				font-size: 2rem;
				margin: 0;
				letter-spacing: 3px;
			}
			
			.login-header p {
				color: var(--eksa-gold-light);
				margin: 10px 0 0;
				font-size: 0.9rem;
				opacity: 0.9;
			}
			
			.login-body {
				padding: 40px;
				background: var(--eksa-white);
			}
			
			.form-group {
				margin-bottom: 25px;
				position: relative;
			}
			
			.form-group label {
				display: block;
				margin-bottom: 10px;
				font-weight: 600;
				color: var(--eksa-navy);
				font-size: 0.95rem;
				letter-spacing: 1px;
			}
			
			.form-group label i {
				color: var(--eksa-gold);
				margin-right: 8px;
			}
			
			.input-group {
				position: relative;
				display: flex;
				align-items: center;
			}
			
			.input-icon {
				position: absolute;
				left: 15px;
				color: var(--eksa-gold);
				font-size: 1.1rem;
				z-index: 10;
			}
			
			.form-control {
				width: 100%;
				padding: 14px 20px 14px 45px;
				border: 2px solid rgba(196, 164, 132, 0.2);
				border-radius: 15px;
				font-size: 0.95rem;
				transition: all 0.3s ease;
				background: var(--eksa-cream);
				font-family: 'Poppins', sans-serif;
			}
			
			.form-control:focus {
				outline: none;
				border-color: var(--eksa-gold);
				box-shadow: 0 0 0 5px var(--eksa-gold-glow);
				background: var(--eksa-white);
				transform: translateY(-2px);
			}
			
			.btn-login {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border: 2px solid var(--eksa-white);
				padding: 16px 30px;
				border-radius: 50px;
				font-size: 1.1rem;
				font-weight: 700;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				width: 100%;
				position: relative;
				overflow: hidden;
				z-index: 1;
				margin-top: 15px;
			}
			
			.btn-login::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				transition: left 0.4s ease;
				z-index: -1;
			}
			
			.btn-login:hover::before {
				left: 0;
			}
			
			.btn-login:hover {
				color: var(--eksa-gold);
				border-color: var(--eksa-gold);
				transform: translateY(-3px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
			}
			
			.btn-login i {
				margin-right: 10px;
			}
			
			.login-footer {
				margin-top: 30px;
				text-align: center;
				padding-top: 20px;
				border-top: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.login-footer a {
				color: var(--eksa-gold-dark);
				text-decoration: none;
				font-size: 0.9rem;
				transition: all 0.3s ease;
				display: inline-flex;
				align-items: center;
				gap: 8px;
			}
			
			.login-footer a:hover {
				color: var(--eksa-navy);
				transform: translateX(5px);
			}
			
			/* ===== LUXURY DECORATION ===== */
			.decoration {
				position: fixed;
				bottom: 100px;
				left: 50px;
				font-size: 10rem;
				color: rgba(196, 164, 132, 0.03);
				font-family: serif;
				transform: rotate(-15deg);
				pointer-events: none;
				z-index: 1;
			}
			
			.decoration-right {
				position: fixed;
				top: 100px;
				right: 50px;
				font-size: 10rem;
				color: rgba(196, 164, 132, 0.03);
				font-family: serif;
				transform: rotate(15deg);
				pointer-events: none;
				z-index: 1;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 0 !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== ANIMATIONS ===== */
			@keyframes slideUp {
				from {
					opacity: 0;
					transform: translateY(50px);
				}
				to {
					opacity: 1;
					transform: translateY(0);
				}
			}
			
			@keyframes fadeIn {
				from { opacity: 0; }
				to { opacity: 1; }
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 768px) {
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.login-body {
					padding: 30px;
				}
				
				.decoration,
				.decoration-right {
					display: none;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.col-md-4 {
				width: 100% !important;
				padding: 0 !important;
			}
		</style>
	</head>
<body>
	<!-- DECORATIVE ELEMENTS -->
	<div class="decoration">✦</div>
	<div class="decoration-right">✦</div>
	
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<div class = "container">
		<div class = "login-wrapper">
			<div class = "login-card">
				
				<!-- LUXURY HEADER -->
				<div class = "login-header">
					<i class="fas fa-crown"></i>
					<h4>ADMIN PANEL</h4>
					<p>Hotel Eksa • Management System</p>
				</div>
				
				<!-- LUXURY BODY -->
				<div class = "login-body">
					<form method = "POST" action="login.php">
						<div class = "form-group">
							<label><i class="fas fa-user"></i> Username</label>
							<div class="input-group">
								<i class="fas fa-user input-icon"></i>
								<input type = "text" name = "username" class = "form-control" placeholder = "Enter your username" required = "required" />
							</div>
						</div>
						
						<div class = "form-group">
							<label><i class="fas fa-lock"></i> Password</label>
							<div class="input-group">
								<i class="fas fa-lock input-icon"></i>
								<input type = "password" name = "password" class = "form-control" placeholder = "Enter your password" required = "required" id="password" />
								<i class="fas fa-eye" style="position: absolute; right: 15px; color: var(--eksa-gold); cursor: pointer; z-index: 20;" onclick="togglePassword()"></i>
							</div>
						</div>
						
						<div class = "form-group">
							<button type="submit" name = "login" class = "btn-login">
								<i class="fas fa-sign-in-alt"></i> LOGIN TO DASHBOARD
							</button>
						</div>
						
						<div class = "login-footer">
							<a href="../index.php">
								<i class="fas fa-arrow-left"></i> Back to Website
							</a>
						</div>
					</form>
					
					<!-- DEFAULT ADMIN CREDENTIALS HINT -->
					<div style="margin-top: 20px; padding: 15px; background: rgba(196,164,132,0.05); border-radius: 10px; border-left: 4px solid var(--eksa-gold);">
						<p style="margin: 0; font-size: 0.85rem; color: var(--eksa-navy-light);">
							<i class="fas fa-info-circle" style="color: var(--eksa-gold);"></i> 
							Default Admin: <strong style="color: var(--eksa-navy);">Admin</strong> / <strong style="color: var(--eksa-navy);">admin</strong>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • MANAGEMENT SYSTEM • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-shield-alt"></i> Authorized Personnel Only <i class="fas fa-shield-alt"></i>
		</div>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script>
	// Toggle password visibility
	function togglePassword() {
		var passwordField = document.getElementById("password");
		var icon = event.currentTarget;
		
		if (passwordField.type === "password") {
			passwordField.type = "text";
			icon.classList.remove("fa-eye");
			icon.classList.add("fa-eye-slash");
		} else {
			passwordField.type = "password";
			icon.classList.remove("fa-eye-slash");
			icon.classList.add("fa-eye");
		}
	}
	
	// Add animation to form inputs
	document.addEventListener('DOMContentLoaded', function() {
		const formControls = document.querySelectorAll('.form-control');
		formControls.forEach((input, index) => {
			input.style.animation = `fadeIn 0.5s ease ${index * 0.1}s both`;
		});
	});
</script>
</html>