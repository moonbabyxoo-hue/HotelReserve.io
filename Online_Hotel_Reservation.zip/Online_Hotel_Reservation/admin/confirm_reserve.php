<!DOCTYPE html>
<?php
    require_once 'validate.php';
    require 'name.php';
?>
<html lang = "en">
    <head>
        <title>Hotel Eksa - Confirm Check-In</title>
        <meta charset = "utf-8" />
        <meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
        <!-- Font Awesome 6 -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <!-- Sweet Alert -->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
        
        <style>
            /* ===== HOTEL EKSA LUXURY THEME - CONFIRM CHECK-IN ===== */
            :root {
                --eksa-gold: #C4A484;
                --eksa-gold-light: #E5D3B0;
                --eksa-gold-dark: #A67B5B;
                --eksa-navy: #0A1C2F;
                --eksa-navy-light: #1E3A5F;
                --eksa-navy-dark: #051220;
                --eksa-cream: #FAF7F2;
                --eksa-white: #FFFFFF;
                --eksa-shadow: rgba(10, 28, 47, 0.1);
                --eksa-shadow-dark: rgba(10, 28, 47, 0.2);
                --eksa-gold-glow: rgba(196, 164, 132, 0.3);
                --eksa-success: #28a745;
                --eksa-success-dark: #218838;
                --eksa-info: #17a2b8;
                --eksa-danger: #dc3545;
            }
            
            body {
                font-family: 'Poppins', sans-serif;
                background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
                color: var(--eksa-navy);
                overflow-x: hidden;
                padding-bottom: 80px;
            }
            
            h1, h2, h3, h4, h5, h6, .navbar-brand {
                font-family: 'Playfair Display', serif !important;
                font-weight: 700 !important;
            }
            
            /* ===== LUXURY NAVIGATION ===== */
            nav.navbar {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
                border: none !important;
                border-bottom: 3px solid var(--eksa-gold) !important;
                padding: 15px 0 !important;
                margin-bottom: 30px !important;
                box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
            }
            
            .navbar-brand {
                color: var(--eksa-gold) !important;
                font-size: 1.8rem !important;
                letter-spacing: 2px !important;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
                position: relative;
                padding-left: 20px !important;
            }
            
            .navbar-brand::before {
                content: '✦';
                color: var(--eksa-gold);
                font-size: 2rem;
                position: absolute;
                left: -5px;
                top: 5px;
            }
            
            .navbar-brand::after {
                content: '✦';
                color: var(--eksa-gold);
                font-size: 2rem;
                position: absolute;
                right: -15px;
                top: 5px;
            }
            
            /* ===== LUXURY DROPDOWN MENU ===== */
            .dropdown-menu {
                background: var(--eksa-white);
                border: 2px solid var(--eksa-gold);
                border-radius: 15px;
                box-shadow: 0 15px 40px var(--eksa-shadow-dark);
                padding: 10px;
            }
            
            .dropdown-menu li a {
                color: var(--eksa-navy);
                padding: 10px 20px;
                border-radius: 10px;
                transition: all 0.3s ease;
            }
            
            .dropdown-menu li a:hover {
                background: rgba(196, 164, 132, 0.1);
                color: var(--eksa-gold-dark);
            }
            
            .dropdown-menu li a i {
                color: var(--eksa-gold);
                margin-right: 10px;
            }
            
            /* ===== LUXURY NAV PILLS ===== */
            .nav-pills {
                margin: 20px 0;
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            
            .nav-pills li {
                margin: 0;
            }
            
            .nav-pills li a {
                background: var(--eksa-white);
                color: var(--eksa-navy);
                padding: 12px 25px;
                border-radius: 50px;
                font-weight: 600;
                transition: all 0.3s ease;
                border: 2px solid rgba(196, 164, 132, 0.2);
                text-decoration: none;
                display: inline-block;
            }
            
            .nav-pills li a:hover {
                background: rgba(196, 164, 132, 0.1);
                border-color: var(--eksa-gold);
                transform: translateY(-2px);
            }
            
            .nav-pills li.active a {
                background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
                color: var(--eksa-navy-dark);
                border-color: var(--eksa-white);
            }
            
            /* ===== LUXURY PANEL ===== */
            .panel {
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
            }
            
            .panel-body {
                background: var(--eksa-white);
                border-radius: 30px;
                padding: 40px;
                box-shadow: 0 30px 60px var(--eksa-shadow);
                border: 1px solid rgba(196, 164, 132, 0.2);
                position: relative;
                overflow: hidden;
            }
            
            .panel-body::before {
                content: '✦ ✦ ✦';
                position: absolute;
                bottom: -20px;
                right: -20px;
                font-size: 12rem;
                color: rgba(196, 164, 132, 0.05);
                font-family: serif;
                transform: rotate(-15deg);
            }
            
            /* ===== PAGE HEADER ===== */
            .page-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 30px;
                flex-wrap: wrap;
                gap: 20px;
            }
            
            .page-title {
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .page-title i {
                font-size: 2.5rem;
                color: var(--eksa-gold);
                background: rgba(196, 164, 132, 0.1);
                padding: 15px;
                border-radius: 20px;
            }
            
            .page-title h2 {
                color: var(--eksa-navy);
                font-size: 2.2rem;
                margin: 0;
            }
            
            .page-title p {
                color: var(--eksa-navy-light);
                margin: 5px 0 0;
                font-size: 0.95rem;
            }
            
            /* ===== SESSION MESSAGES ===== */
            .error-message {
                background: rgba(220, 53, 69, 0.1);
                border-left: 5px solid #dc3545;
                border-radius: 10px;
                padding: 15px 20px;
                margin-bottom: 30px;
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .error-message i {
                color: #dc3545;
                font-size: 1.5rem;
            }
            
            .error-message h5 {
                color: #dc3545;
                margin: 0 0 5px;
            }
            
            .error-message p {
                color: var(--eksa-navy);
                margin: 0;
            }
            
            .success-message {
                background: rgba(40, 167, 69, 0.1);
                border-left: 5px solid #28a745;
                border-radius: 10px;
                padding: 15px 20px;
                margin-bottom: 30px;
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .success-message i {
                color: #28a745;
                font-size: 1.5rem;
            }
            
            .success-message h5 {
                color: #28a745;
                margin: 0 0 5px;
            }
            
            .success-message p {
                color: var(--eksa-navy);
                margin: 0;
            }
            
            /* ===== GUEST INFO CARD ===== */
            .guest-info-card {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
                border-radius: 20px;
                padding: 30px;
                color: white;
                margin-bottom: 40px;
                display: flex;
                flex-wrap: wrap;
                gap: 30px;
                align-items: center;
            }
            
            .guest-avatar {
                width: 100px;
                height: 100px;
                background: rgba(196, 164, 132, 0.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                border: 3px solid var(--eksa-gold);
            }
            
            .guest-avatar i {
                font-size: 3rem;
                color: var(--eksa-gold);
            }
            
            .guest-details {
                flex: 1;
            }
            
            .guest-name {
                font-size: 2rem;
                font-weight: 700;
                margin-bottom: 10px;
                color: var(--eksa-gold);
            }
            
            .guest-info-row {
                display: flex;
                flex-wrap: wrap;
                gap: 20px;
            }
            
            .guest-info-item {
                display: flex;
                align-items: center;
                gap: 10px;
                background: rgba(255,255,255,0.1);
                padding: 8px 20px;
                border-radius: 50px;
            }
            
            .guest-info-item i {
                color: var(--eksa-gold);
            }
            
            /* ===== ROOM INFO CARD ===== */
            .room-info-card {
                background: rgba(196, 164, 132, 0.05);
                border-radius: 20px;
                padding: 30px;
                margin-bottom: 30px;
                border: 1px solid rgba(196, 164, 132, 0.3);
            }
            
            .room-info-header {
                display: flex;
                align-items: center;
                gap: 15px;
                margin-bottom: 20px;
            }
            
            .room-info-header i {
                font-size: 2rem;
                color: var(--eksa-gold);
            }
            
            .room-info-header h4 {
                color: var(--eksa-navy);
                font-size: 1.5rem;
                margin: 0;
            }
            
            .room-details-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
            }
            
            .room-detail-item {
                background: var(--eksa-white);
                padding: 20px;
                border-radius: 15px;
                box-shadow: 0 5px 20px var(--eksa-shadow);
            }
            
            .room-detail-label {
                color: var(--eksa-navy-light);
                font-size: 0.85rem;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 5px;
            }
            
            .room-detail-value {
                font-size: 1.5rem;
                font-weight: 700;
                color: var(--eksa-navy);
            }
            
            .room-detail-value small {
                font-size: 0.9rem;
                font-weight: 400;
                color: var(--eksa-navy-light);
            }
            
            /* ===== FORM STYLES ===== */
            .form-section {
                margin-top: 40px;
            }
            
            .form-section-title {
                display: flex;
                align-items: center;
                gap: 15px;
                margin-bottom: 30px;
            }
            
            .form-section-title i {
                font-size: 1.8rem;
                color: var(--eksa-gold);
                background: rgba(196, 164, 132, 0.1);
                padding: 12px;
                border-radius: 15px;
            }
            
            .form-section-title h3 {
                color: var(--eksa-navy);
                font-size: 1.8rem;
                margin: 0;
            }
            
            .form-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 25px;
                margin-bottom: 30px;
            }
            
            .form-group {
                margin-bottom: 0;
            }
            
            .form-group label {
                display: block;
                margin-bottom: 10px;
                font-weight: 600;
                color: var(--eksa-navy);
                font-size: 0.95rem;
                letter-spacing: 1px;
            }
            
            .form-group label i {
                color: var(--eksa-gold);
                margin-right: 8px;
            }
            
            .form-control {
                width: 100%;
                padding: 14px 18px;
                border: 2px solid rgba(196, 164, 132, 0.2);
                border-radius: 15px;
                font-size: 1rem;
                transition: all 0.3s ease;
                background: var(--eksa-cream);
                font-family: 'Poppins', sans-serif;
            }
            
            .form-control:focus {
                outline: none;
                border-color: var(--eksa-gold);
                box-shadow: 0 0 0 5px var(--eksa-gold-glow);
                background: var(--eksa-white);
                transform: translateY(-2px);
            }
            
            .extra-bed-note {
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 15px 20px;
                background: rgba(220, 53, 69, 0.05);
                border-radius: 12px;
                margin-top: 10px;
                border-left: 4px solid #dc3545;
            }
            
            .extra-bed-note i {
                color: #dc3545;
                font-size: 1.2rem;
            }
            
            .extra-bed-note span {
                color: #dc3545;
                font-weight: 700;
            }
            
            /* ===== BUTTON STYLES ===== */
            .btn-submit {
                background: linear-gradient(135deg, var(--eksa-success), var(--eksa-success-dark));
                color: white;
                border: none;
                padding: 16px 40px;
                border-radius: 50px;
                font-size: 1.1rem;
                font-weight: 700;
                letter-spacing: 2px;
                cursor: pointer;
                transition: all 0.4s ease;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 12px;
                border: 2px solid transparent;
                margin-top: 20px;
            }
            
            .btn-submit:hover {
                background: var(--eksa-success-dark);
                transform: translateY(-3px);
                box-shadow: 0 15px 30px rgba(40, 167, 69, 0.3);
                border-color: var(--eksa-white);
            }
            
            .btn-cancel {
                background: transparent;
                color: var(--eksa-navy);
                border: 2px solid var(--eksa-gold);
                padding: 16px 40px;
                border-radius: 50px;
                font-size: 1rem;
                font-weight: 600;
                transition: all 0.3s ease;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                text-decoration: none;
                margin-left: 15px;
            }
            
            .btn-cancel:hover {
                background: var(--eksa-gold);
                color: var(--eksa-navy-dark);
                transform: translateY(-2px);
                text-decoration: none;
            }
            
            /* ===== LUXURY FOOTER ===== */
            .navbar-fixed-bottom {
                background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
                border: none !important;
                border-top: 2px solid var(--eksa-gold) !important;
                padding: 20px 0 !important;
                color: var(--eksa-white) !important;
                position: relative !important;
                margin-top: 50px !important;
            }
            
            .navbar-fixed-bottom label {
                color: var(--eksa-gold-light) !important;
                font-size: 1rem !important;
                font-weight: 400 !important;
                letter-spacing: 2px !important;
            }
            
            .navbar-fixed-bottom label::before {
                content: '✦ ';
                color: var(--eksa-gold);
            }
            
            .navbar-fixed-bottom label::after {
                content: ' ✦';
                color: var(--eksa-gold);
            }
            
            /* ===== RESPONSIVE ===== */
            @media (max-width: 768px) {
                .navbar-brand {
                    font-size: 1.2rem !important;
                }
                
                .nav-pills {
                    flex-direction: column;
                }
                
                .nav-pills li a {
                    display: block;
                    text-align: center;
                }
                
                .panel-body {
                    padding: 30px;
                }
                
                .page-header {
                    flex-direction: column;
                    align-items: flex-start;
                }
                
                .page-title h2 {
                    font-size: 1.8rem;
                }
                
                .guest-info-card {
                    flex-direction: column;
                    text-align: center;
                }
                
                .guest-info-row {
                    justify-content: center;
                }
                
                .form-grid {
                    grid-template-columns: 1fr;
                }
                
                .btn-submit, .btn-cancel {
                    width: 100%;
                    margin-left: 0;
                    margin-bottom: 10px;
                }
            }
            
            /* Override Bootstrap defaults */
            .container-fluid {
                padding-left: 30px !important;
                padding-right: 30px !important;
            }
            
            .navbar-default .navbar-brand:hover,
            .navbar-default .navbar-brand:focus {
                color: var(--eksa-gold-light) !important;
            }
        </style>
    </head>
<body>
    <!-- LUXURY NAVIGATION -->
    <nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
        <div class = "container-fluid">
            <div class = "navbar-header">
                <a class = "navbar-brand">
                    <i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
                    Hotel Eksa
                </a>
            </div>
            <ul class = "nav navbar-nav pull-right">
                <li class = "dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
                        <span style="color: var(--eksa-white); font-weight: 600;"><?php echo $name; ?></span>
                        <span class="caret" style="color: var(--eksa-gold);"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
                        <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- LUXURY NAVIGATION PILLS -->
    <div class = "container-fluid">
        <ul class = "nav nav-pills">
            <li><a href = "home.php"><i class="fas fa-home me-2"></i> Dashboard</a></li>
            <li><a href = "account.php"><i class="fas fa-users-cog me-2"></i> Accounts</a></li>
            <li><a href = "reserve.php"><i class="fas fa-calendar-check me-2"></i> Pending</a></li>
            <li><a href = "checkin.php"><i class="fas fa-sign-in-alt me-2"></i> Check In</a></li>
            <li><a href = "checkout.php"><i class="fas fa-sign-out-alt me-2"></i> Check Out</a></li>
            <li><a href = "room.php"><i class="fas fa-bed me-2"></i> Rooms</a></li>
            <li><a href = "reports.php"><i class="fas fa-chart-line me-2"></i> Reports</a></li>
        </ul>
    </div>
    
    <br />
    
    <!-- LUXURY CONFIRM CHECK-IN CONTENT -->
    <div class = "container-fluid">
        <div class = "panel panel-default">
            <div class = "panel-body">
                
                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div class="page-title">
                        <i class="fas fa-check-circle"></i>
                        <div>
                            <h2>Confirm Check-In</h2>
                            <p>Verify guest information and assign room details</p>
                        </div>
                    </div>
                </div>
                
                <!-- SESSION MESSAGES -->
                <?php
                if (isset($_SESSION['error_message'])) {
                    echo '<div class="error-message">';
                    echo '<i class="fas fa-exclamation-circle"></i>';
                    echo '<div><h5>Error</h5>';
                    echo '<p style="color: var(--eksa-navy); margin: 0;">' . $_SESSION['error_message'] . '</p></div>';
                    echo '</div>';
                    unset($_SESSION['error_message']);
                }
                
                if (isset($_SESSION['success_message'])) {
                    echo '<div class="success-message">';
                    echo '<i class="fas fa-check-circle"></i>';
                    echo '<div><h5>Success</h5>';
                    echo '<p style="color: var(--eksa-navy); margin: 0;">' . $_SESSION['success_message'] . '</p></div>';
                    echo '</div>';
                    unset($_SESSION['success_message']);
                }
                ?>
                
                <?php
                    // Check if transaction_id is set
                    if(!isset($_REQUEST['transaction_id'])) {
                        echo '<script>window.location.href="reserve.php";</script>';
                        exit();
                    }
                    
                    $query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` NATURAL JOIN `room` WHERE `transaction_id` = '$_REQUEST[transaction_id]'") or die(mysqli_error($conn));
                    
                    if($query->num_rows == 0) {
                        echo '<script>window.location.href="reserve.php";</script>';
                        exit();
                    }
                    
                    $fetch = $query->fetch_array();
                    
                    // Check if already checked in
                    if($fetch['status'] == 'Check In') {
                        $_SESSION['error_message'] = "This guest is already checked in.";
                        echo '<script>window.location.href="checkin.php";</script>';
                        exit();
                    }
                    
                    // Calculate stay duration
                    $checkin = new DateTime($fetch['checkin']);
                    $checkout = new DateTime($fetch['checkout']);
                    $stay_duration = $checkin->diff($checkout)->days;
                    if($stay_duration <= 0) $stay_duration = 1;
                    
                    // Safe number formatting with null/empty checks
                    $room_price = isset($fetch['price']) && $fetch['price'] !== '' ? floatval($fetch['price']) : 0;
                    $bill_amount = isset($fetch['bill']) && $fetch['bill'] !== '' ? floatval($fetch['bill']) : 0;
                ?>
                
                <!-- GUEST INFORMATION CARD -->
                <div class="guest-info-card">
                    <div class="guest-avatar">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <div class="guest-details">
                        <div class="guest-name">
                            <?php echo $fetch['firstname'] . ' ' . $fetch['middlename'] . ' ' . $fetch['lastname']; ?>
                        </div>
                        <div class="guest-info-row">
                            <div class="guest-info-item">
                                <i class="fas fa-phone-alt"></i>
                                <?php echo $fetch['contactno']; ?>
                            </div>
                            <div class="guest-info-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <?php echo $fetch['address']; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- ROOM INFORMATION CARD -->
                <div class="room-info-card">
                    <div class="room-info-header">
                        <i class="fas fa-bed"></i>
                        <h4><?php echo $fetch['room_type']; ?></h4>
                    </div>
                    
                    <div class="room-details-grid">
                        <div class="room-detail-item">
                            <div class="room-detail-label">Reservation Date</div>
                            <div class="room-detail-value">
                                <?php echo date('M d, Y', strtotime($fetch['checkin'])); ?>
                                <small>to <?php echo date('M d, Y', strtotime($fetch['checkout'])); ?></small>
                            </div>
                        </div>
                        <div class="room-detail-item">
                            <div class="room-detail-label">Stay Duration</div>
                            <div class="room-detail-value">
                                <?php echo $stay_duration; ?> <small>nights</small>
                            </div>
                        </div>
                        <div class="room-detail-item">
                            <div class="room-detail-label">Rate per Night</div>
                            <div class="room-detail-value">
                                Rs. <?php echo number_format($room_price, 2); ?>
                            </div>
                        </div>
                        <div class="room-detail-item">
                            <div class="room-detail-label">Total Bill</div>
                            <div class="room-detail-value">
                                Rs. <?php echo number_format($bill_amount, 2); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- CHECK-IN FORM - FIXED ACTION -->
                <div class="form-section">
                    <div class="form-section-title">
                        <i class="fas fa-key"></i>
                        <h3>Assign Room & Confirm Check-In</h3>
                    </div>
                    
                    <!-- FIXED: Removed enctype, added proper action -->
                    <form method="POST" action="save_form.php">
                        <input type="hidden" name="transaction_id" value="<?php echo $fetch['transaction_id']; ?>">
                        
                        <div class="form-grid">
                            <!-- Room Number -->
                            <div class = "form-group">
                                <label><i class="fas fa-door-open"></i> Room Number *</label>
                                <input type="number" min="1" max="999" name="room_no" class="form-control" placeholder="Enter room number" required>
                                <small style="color: var(--eksa-navy-light);">Assign an available room number</small>
                            </div>
                            
                            <!-- Number of Days -->
                            <div class = "form-group">
                                <label><i class="fas fa-calendar-alt"></i> Number of Nights *</label>
                                <input type="number" min="1" max="99" name="days" class="form-control" value="<?php echo $stay_duration; ?>" required>
                                <small style="color: var(--eksa-navy-light);">Total nights of stay</small>
                            </div>
                            
                            <!-- Extra Bed -->
                            <div class = "form-group">
                                <label><i class="fas fa-bed"></i> Extra Bed</label>
                                <input type="number" min="0" max="5" name="extra_bed" class="form-control" value="0" placeholder="Number of extra beds">
                                <small style="color: var(--eksa-navy-light);">Rs. 800 per night</small>
                            </div>
                        </div>
                        
                        <!-- Extra Bed Cost Note -->
                        <div class="extra-bed-note">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span>Extra bed cost: Rs. 800.00 per night</span>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div style="margin-top: 40px; display: flex; gap: 15px; flex-wrap: wrap;">
                            <button type="submit" name="add_form" class="btn-submit">
                                <i class="fas fa-check-circle"></i> CONFIRM CHECK-IN
                            </button>
                            <a href="reserve.php" class="btn-cancel">
                                <i class="fas fa-times-circle"></i> CANCEL
                            </a>
                        </div>
                    </form>
                </div>
                
                <!-- CHECK-IN GUIDELINES -->
                <div style="margin-top: 40px; padding: 20px; background: rgba(196,164,132,0.03); border-radius: 15px; border: 1px dashed var(--eksa-gold);">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <i class="fas fa-clipboard-list" style="font-size: 2rem; color: var(--eksa-gold);"></i>
                        <div>
                            <h5 style="color: var(--eksa-navy); margin-bottom: 5px;">Check-In Guidelines</h5>
                            <p style="color: var(--eksa-navy-light); margin: 0; font-size: 0.9rem;">
                                <strong>Room Number:</strong> Assign a unique, available room number. | 
                                <strong>Nights:</strong> Pre-filled from reservation, can be adjusted. | 
                                <strong>Extra Bed:</strong> Rs. 800 per night, add if requested by guest.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
    <!-- LUXURY FOOTER -->
    <div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
        <label>HOTEL EKSA • CHECK-IN MANAGEMENT • EST. 2024 </label>
        <div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
            <i class="fas fa-user-check"></i> Confirming: <?php echo $fetch['firstname'] . ' ' . $fetch['lastname']; ?> <i class="fas fa-user-check"></i>
        </div>
    </div>

    <!-- SIMPLE JAVASCRIPT - NO CONFLICTS -->
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script>
    // Simple confirmation - no preventDefault issues
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.querySelector('form');
        
        if (form) {
            form.addEventListener('submit', function(e) {
                var roomNo = document.querySelector('input[name="room_no"]').value;
                var days = document.querySelector('input[name="days"]').value;
                
                // Validate Room Number
                if (!roomNo || roomNo < 1) {
                    e.preventDefault();
                    alert('Please enter a valid room number');
                    return false;
                }
                
                // Validate Nights
                if (!days || days < 1) {
                    e.preventDefault();
                    alert('Please enter a valid number of nights');
                    return false;
                }
                
                // Simple confirmation
                return confirm('Are you sure you want to check in this guest?');
            });
        }
    });
    </script>
</body>
</html>