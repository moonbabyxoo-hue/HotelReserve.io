<?php
// Start session to store reservation data
session_start();

// Get form data from POST with fallbacks
$firstname = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
$middlename = isset($_POST['middlename']) ? trim($_POST['middlename']) : '';
$lastname = isset($_POST['lastname']) ? trim($_POST['lastname']) : '';
$address = isset($_POST['address']) ? trim($_POST['address']) : '';
$contactno = isset($_POST['contactno']) ? trim($_POST['contactno']) : '';
$checkin_date = isset($_POST['date']) ? trim($_POST['date']) : '';

// Calculate nights and total
$room_id = isset($_REQUEST['room_id']) ? $_REQUEST['room_id'] : 0;

// Get room details from database
require_once 'admin/connect.php';
$room_query = $conn->query("SELECT * FROM `room` WHERE `room_id` = '$room_id'") or die(mysql_error());
$room_fetch = $room_query->fetch_array();

$room_type = isset($room_fetch['room_type']) ? $room_fetch['room_type'] : 'Deluxe Room';
$room_price = isset($room_fetch['price']) ? $room_fetch['price'] : 0;
$room_photo = isset($room_fetch['photo']) ? $room_fetch['photo'] : '1.jpg';

// Calculate nights from check-in date to today
$nights = 1;
if (!empty($checkin_date)) {
    $checkin = new DateTime($checkin_date);
    $today = new DateTime();
    $interval = $today->diff($checkin);
    $nights = max(1, $interval->days);
}

// Calculate totals
$subtotal = $room_price * $nights;
$service_charge = $subtotal * 0.10;
$tax = $subtotal * 0.12;
$total = $subtotal + $service_charge + $tax;

// Generate unique invoice number
$invoice_number = 'INV-' . date('Ymd') . '-' . str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
$reservation_code = 'EKS' . strtoupper(uniqid());
?>
<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Reservation Confirmation</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<!-- html2pdf for invoice download -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 100px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY CONFIRMATION CONTAINER ===== */
			.container {
				width: 95%;
				max-width: 1200px;
				margin: 40px auto !important;
				padding: 0 !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white) !important;
				padding: 50px !important;
				border-radius: 30px !important;
				box-shadow: 0 30px 60px var(--eksa-shadow) !important;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			/* ===== LUXURY INVOICE ===== */
			.invoice-container {
				max-width: 800px;
				margin: 0 auto;
				background: var(--eksa-white);
				border-radius: 20px;
				position: relative;
				z-index: 10;
			}
			
			.invoice-header {
				text-align: center;
				margin-bottom: 40px;
				position: relative;
			}
			
			.invoice-header h3 {
				font-size: 2.5rem !important;
				color: var(--eksa-navy) !important;
				margin: 0 0 10px 0 !important;
				position: relative;
				display: inline-block;
			}
			
			.invoice-header h3::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2rem;
			}
			
			.invoice-header h3::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2rem;
			}
			
			.invoice-header p {
				color: var(--eksa-navy-light);
				font-size: 1rem;
				letter-spacing: 2px;
			}
			
			.success-badge {
				background: linear-gradient(135deg, #28a745, #20c997);
				color: white;
				padding: 12px 30px;
				border-radius: 50px;
				display: inline-block;
				font-weight: 700;
				margin-bottom: 30px;
				box-shadow: 0 10px 25px rgba(40, 167, 69, 0.3);
			}
			
			.success-badge i {
				margin-right: 10px;
			}
			
			/* ===== INVOICE CARD ===== */
			.invoice-card {
				background: linear-gradient(135deg, var(--eksa-white), var(--eksa-cream));
				border-radius: 20px;
				padding: 40px;
				box-shadow: 0 15px 40px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				margin-bottom: 30px;
			}
			
			.invoice-title {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 30px;
				padding-bottom: 20px;
				border-bottom: 2px solid var(--eksa-gold);
			}
			
			.invoice-title h4 {
				color: var(--eksa-navy);
				font-size: 1.8rem;
				margin: 0;
			}
			
			.invoice-title span {
				color: var(--eksa-gold-dark);
				font-weight: 600;
				background: rgba(196, 164, 132, 0.1);
				padding: 8px 20px;
				border-radius: 50px;
				font-size: 0.9rem;
			}
			
			.invoice-logo {
				display: flex;
				align-items: center;
				gap: 15px;
				margin-bottom: 30px;
			}
			
			.invoice-logo i {
				font-size: 2.5rem;
				color: var(--eksa-gold);
			}
			
			.invoice-logo h2 {
				color: var(--eksa-navy);
				font-size: 1.8rem;
				margin: 0;
			}
			
			/* ===== HOTEL INFO ===== */
			.hotel-info {
				display: flex;
				justify-content: space-between;
				margin-bottom: 30px;
				padding: 20px;
				background: rgba(196, 164, 132, 0.05);
				border-radius: 15px;
			}
			
			.hotel-address {
				flex: 1;
			}
			
			.hotel-address h5 {
				color: var(--eksa-gold-dark);
				font-size: 1rem;
				margin-bottom: 5px;
			}
			
			.hotel-address p {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
				margin: 0;
			}
			
			.invoice-date {
				text-align: right;
			}
			
			.invoice-date p {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
				margin-bottom: 5px;
			}
			
			.invoice-date strong {
				color: var(--eksa-navy);
			}
			
			/* ===== GUEST INFO ===== */
			.guest-info {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				color: white;
				padding: 25px;
				border-radius: 15px;
				margin-bottom: 30px;
			}
			
			.guest-info h5 {
				color: var(--eksa-gold);
				font-size: 1.1rem;
				margin-bottom: 15px;
				display: flex;
				align-items: center;
				gap: 10px;
			}
			
			.guest-details {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
				gap: 15px;
			}
			
			.guest-item {
				display: flex;
				align-items: center;
				gap: 10px;
			}
			
			.guest-item i {
				color: var(--eksa-gold);
				width: 20px;
			}
			
			.guest-item span {
				color: var(--eksa-white);
				font-size: 0.95rem;
			}
			
			/* ===== RESERVATION CODE ===== */
			.reservation-code {
				background: rgba(196, 164, 132, 0.1);
				border: 2px dashed var(--eksa-gold);
				padding: 15px;
				border-radius: 10px;
				margin-bottom: 30px;
				text-align: center;
			}
			
			.reservation-code span {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
				display: block;
				margin-bottom: 5px;
			}
			
			.reservation-code strong {
				color: var(--eksa-navy);
				font-size: 1.4rem;
				letter-spacing: 3px;
				font-family: monospace;
			}
			
			/* ===== ROOM INFO ===== */
			.room-info-card {
				display: flex;
				gap: 20px;
				margin-bottom: 30px;
				padding: 20px;
				background: var(--eksa-white);
				border-radius: 15px;
				border: 1px solid rgba(196, 164, 132, 0.3);
			}
			
			.room-info-image {
				width: 120px;
				height: 120px;
				border-radius: 10px;
				overflow: hidden;
				border: 3px solid var(--eksa-gold);
			}
			
			.room-info-image img {
				width: 100%;
				height: 100%;
				object-fit: cover;
			}
			
			.room-info-details {
				flex: 1;
			}
			
			.room-info-details h5 {
				color: var(--eksa-navy);
				font-size: 1.3rem;
				margin-bottom: 10px;
			}
			
			.room-meta {
				display: flex;
				flex-wrap: wrap;
				gap: 15px;
			}
			
			.room-meta span {
				font-size: 0.9rem;
				color: var(--eksa-navy-light);
				background: rgba(196, 164, 132, 0.1);
				padding: 5px 12px;
				border-radius: 50px;
			}
			
			.room-meta i {
				color: var(--eksa-gold);
				margin-right: 5px;
			}
			
			/* ===== INVOICE TABLE ===== */
			.invoice-table {
				width: 100%;
				margin-bottom: 30px;
				border-collapse: collapse;
			}
			
			.invoice-table th {
				background: var(--eksa-cream);
				color: var(--eksa-navy);
				padding: 15px;
				text-align: left;
				font-weight: 700;
				border-bottom: 2px solid var(--eksa-gold);
			}
			
			.invoice-table td {
				padding: 15px;
				border-bottom: 1px solid rgba(196, 164, 132, 0.2);
				color: var(--eksa-navy-light);
			}
			
			.invoice-table tr:last-child td {
				border-bottom: none;
			}
			
			.invoice-table .total-row {
				background: rgba(196, 164, 132, 0.05);
				font-weight: 700;
			}
			
			.invoice-table .total-row td {
				color: var(--eksa-navy);
				font-size: 1.1rem;
			}
			
			/* ===== INVOICE SUMMARY ===== */
			.invoice-summary {
				margin-top: 30px;
				padding-top: 20px;
				border-top: 2px dashed var(--eksa-gold);
			}
			
			.summary-row {
				display: flex;
				justify-content: space-between;
				padding: 10px 0;
				color: var(--eksa-navy-light);
			}
			
			.summary-row.total {
				font-size: 1.4rem;
				font-weight: 800;
				color: var(--eksa-navy);
				margin-top: 10px;
				padding-top: 15px;
				border-top: 2px solid var(--eksa-gold);
			}
			
			.summary-row.total span:last-child {
				color: var(--eksa-gold-dark);
			}
			
			/* ===== INVOICE FOOTER ===== */
			.invoice-footer {
				text-align: center;
				margin-top: 40px;
				padding-top: 30px;
				border-top: 1px solid rgba(196, 164, 132, 0.2);
			}
			
			.invoice-footer p {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
				margin-bottom: 10px;
			}
			
			.invoice-footer .signature {
				font-family: 'Playfair Display', serif;
				color: var(--eksa-gold-dark);
				font-size: 1.2rem;
				margin-top: 20px;
			}
			
			/* ===== ACTION BUTTONS ===== */
			.action-buttons {
				display: flex;
				justify-content: center;
				gap: 20px;
				margin-top: 40px;
				flex-wrap: wrap;
			}
			
			.btn-download, .btn-back {
				padding: 14px 35px;
				border-radius: 50px;
				font-size: 1rem;
				font-weight: 700;
				letter-spacing: 1px;
				cursor: pointer;
				transition: all 0.4s ease;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				gap: 12px;
				text-decoration: none;
				border: none;
			}
			
			.btn-download {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border: 2px solid var(--eksa-white);
			}
			
			.btn-download:hover {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				color: var(--eksa-gold);
				border-color: var(--eksa-gold);
				transform: translateY(-3px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
			}
			
			.btn-back {
				background: transparent;
				color: var(--eksa-navy);
				border: 2px solid var(--eksa-gold);
			}
			
			.btn-back:hover {
				background: var(--eksa-gold);
				color: var(--eksa-navy-dark);
				transform: translateY(-3px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
			}
			
			/* ===== NO DATA WARNING ===== */
			.no-data-warning {
				text-align: center;
				padding: 60px 20px;
				background: rgba(255, 99, 71, 0.05);
				border-radius: 20px;
				border: 2px solid tomato;
			}
			
			.no-data-warning i {
				font-size: 4rem;
				color: tomato;
				margin-bottom: 20px;
			}
			
			.no-data-warning h4 {
				color: tomato;
				margin-bottom: 15px;
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 768px) {
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li:not(:last-child)::after {
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.panel-body {
					padding: 30px !important;
				}
				
				.invoice-card {
					padding: 25px;
				}
				
				.invoice-title {
					flex-direction: column;
					text-align: center;
					gap: 15px;
				}
				
				.hotel-info {
					flex-direction: column;
					gap: 15px;
				}
				
				.invoice-date {
					text-align: left;
				}
				
				.room-info-card {
					flex-direction: column;
					align-items: center;
					text-align: center;
				}
				
				.room-info-image {
					width: 150px;
					height: 150px;
				}
				
				.action-buttons {
					flex-direction: column;
					align-items: center;
				}
				
				.btn-download, .btn-back {
					width: 100%;
				}
			}
			
			@media (max-width: 480px) {
				.panel-body {
					padding: 20px !important;
				}
				
				.invoice-header h3 {
					font-size: 1.8rem !important;
				}
				
				.guest-details {
					grid-template-columns: 1fr;
				}
			}
			
			/* Print styles for PDF */
			@media print {
				nav, #menu, .navbar-fixed-bottom, .action-buttons {
					display: none !important;
				}
				
				.panel-body {
					box-shadow: none !important;
					padding: 0 !important;
				}
				
				.invoice-card {
					box-shadow: none !important;
					border: 1px solid #ccc !important;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
			
			.well {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
				margin-bottom: 0 !important;
				padding: 0 !important;
			}
			
			.col-md-4 {
				width: 100% !important;
				padding: 0 !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "rulesandregulation.php"><i class="fas fa-book me-2"></i> Rules</a></li>
	</ul>
	
	<!-- LUXURY CONFIRMATION CONTENT -->
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<?php if (empty($firstname) || empty($lastname) || empty($address) || empty($contactno) || empty($checkin_date)): ?>
				
				<!-- NO DATA WARNING -->
				<div class="no-data-warning">
					<i class="fas fa-exclamation-triangle"></i>
					<h4>No Reservation Data Found</h4>
					<p style="color: var(--eksa-navy-light); margin-bottom: 30px;">Please complete the reservation form first.</p>
					<a href="reservation.php" class="btn-back" style="display: inline-flex;">
						<i class="fas fa-arrow-left"></i> Back to Reservations
					</a>
				</div>
				
				<?php else: ?>
				
				<!-- INVOICE CONTAINER -->
				<div class="invoice-container" id="invoiceContent">
					
					<!-- INVOICE HEADER -->
					<div class="invoice-header">
						<div class="success-badge">
							<i class="fas fa-check-circle"></i> RESERVATION CONFIRMED
						</div>
						<strong><h3>Booking Invoice</h3></strong>
						<p>YOUR STAY AT HOTEL EKSA IS CONFIRMED</p>
					</div>
					
					<!-- INVOICE CARD -->
					<div class="invoice-card">
						
						<!-- INVOICE TITLE -->
						<div class="invoice-title">
							<h4>INVOICE</h4>
							<span><i class="fas fa-clock"></i> <?php echo date('F d, Y'); ?></span>
						</div>
						
						<!-- HOTEL LOGO & INFO -->
						<div class="invoice-logo">
							<i class="fas fa-h-square"></i>
							<h2>HOTEL EKSA</h2>
						</div>
						
						<!-- HOTEL ADDRESS & INVOICE DATE -->
						<div class="hotel-info">
							<div class="hotel-address">
								<h5><i class="fas fa-map-marker-alt"></i> HOTEL ADDRESS</h5>
								<p>Khairahani-06, Parsa</p>
								<p>Chitwan, Nepal</p>
								<p><i class="fas fa-phone"></i> +977 9800000000</p>
								<p><i class="fas fa-envelope"></i> reservations@hoteleksa.com</p>
							</div>
							<div class="invoice-date">
								<h5><i class="fas fa-calendar-alt"></i> INVOICE DETAILS</h5>
								<p><strong>Invoice No:</strong> <?php echo $invoice_number; ?></p>
								<p><strong>Date:</strong> <?php echo date('F d, Y'); ?></p>
								<p><strong>Status:</strong> <span style="color: #28a745;">Confirmed</span></p>
							</div>
						</div>
						
						<!-- RESERVATION CODE -->
						<div class="reservation-code">
							<span><i class="fas fa-ticket-alt"></i> YOUR RESERVATION CODE</span>
							<strong><?php echo $reservation_code; ?></strong>
						</div>
						
						<!-- GUEST INFORMATION - DYNAMIC FROM FORM -->
						<div class="guest-info">
							<h5><i class="fas fa-user-circle"></i> GUEST INFORMATION</h5>
							<div class="guest-details">
								<div class="guest-item">
									<i class="fas fa-user"></i>
									<span><?php echo htmlspecialchars($firstname . ' ' . $middlename . ' ' . $lastname); ?></span>
								</div>
								<div class="guest-item">
									<i class="fas fa-map-marker-alt"></i>
									<span><?php echo htmlspecialchars($address); ?></span>
								</div>
								<div class="guest-item">
									<i class="fas fa-phone-alt"></i>
									<span><?php echo htmlspecialchars($contactno); ?></span>
								</div>
								<div class="guest-item">
									<i class="fas fa-calendar-check"></i>
									<span>Check-in: <?php echo date('F d, Y', strtotime($checkin_date)); ?></span>
								</div>
							</div>
						</div>
						
						<!-- ROOM INFORMATION -->
						<div class="room-info-card">
							<div class="room-info-image">
								<img src="photo/<?php echo $room_photo; ?>" alt="<?php echo $room_type; ?>">
							</div>
							<div class="room-info-details">
								<h5><?php echo $room_type; ?></h5>
								<div class="room-meta">
									<span><i class="fas fa-wifi"></i> Free WiFi</span>
									<span><i class="fas fa-snowflake"></i> AC</span>
									<span><i class="fas fa-tv"></i> Smart TV</span>
									<span><i class="fas fa-coffee"></i> Coffee</span>
								</div>
								<p style="margin-top: 10px; color: var(--eksa-gold-dark); font-weight: 700;">
									Rs. <?php echo number_format($room_price, 2); ?> / night
								</p>
							</div>
						</div>
						
						<!-- BOOKING DETAILS TABLE -->
						<table class="invoice-table">
							<thead>
								<tr>
									<th>Description</th>
									<th>Rate</th>
									<th>Nights</th>
									<th>Amount</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><?php echo $room_type; ?> - Standard Rate</td>
									<td>Rs. <?php echo number_format($room_price, 2); ?></td>
									<td><?php echo $nights; ?></td>
									<td>Rs. <?php echo number_format($subtotal, 2); ?></td>
								</tr>
								<tr>
									<td>Service Charge (10%)</td>
									<td>-</td>
									<td>-</td>
									<td>Rs. <?php echo number_format($service_charge, 2); ?></td>
								</tr>
								<tr>
									<td>Tax (12%)</td>
									<td>-</td>
									<td>-</td>
									<td>Rs. <?php echo number_format($tax, 2); ?></td>
								</tr>
								<tr class="total-row">
									<td colspan="3" style="text-align: right; font-weight: 700;">TOTAL AMOUNT</td>
									<td style="color: var(--eksa-gold-dark); font-weight: 800; font-size: 1.2rem;">
										Rs. <?php echo number_format($total, 2); ?>
									</td>
								</tr>
							</tbody>
						</table>
						
						<!-- INVOICE SUMMARY -->
						<div class="invoice-summary">
							<div class="summary-row">
								<span>Subtotal:</span>
								<span>Rs. <?php echo number_format($subtotal, 2); ?></span>
							</div>
							<div class="summary-row">
								<span>Service Charge (10%):</span>
								<span>Rs. <?php echo number_format($service_charge, 2); ?></span>
							</div>
							<div class="summary-row">
								<span>Tax (12%):</span>
								<span>Rs. <?php echo number_format($tax, 2); ?></span>
							</div>
							<div class="summary-row total">
								<span>TOTAL AMOUNT:</span>
								<span>Rs. <?php echo number_format($total, 2); ?></span>
							</div>
						</div>
						
						<!-- INVOICE FOOTER -->
						<div class="invoice-footer">
							<p><i class="fas fa-check-circle" style="color: #28a745;"></i> This is a confirmed reservation. Please present this invoice upon check-in.</p>
							<p><i class="fas fa-clock"></i> Check-in: 3:00 PM | Check-out: 12:00 PM</p>
							<p><i class="fas fa-credit-card"></i> Payment will be collected at the hotel.</p>
							<p><i class="fas fa-info-circle"></i> Reservation Code: <strong><?php echo $reservation_code; ?></strong></p>
							<div class="signature">
								Hotel Eksa Management
							</div>
						</div>
					</div>
				</div>
				
				<!-- ACTION BUTTONS -->
				<div class="action-buttons">
					<button class="btn-download" id="downloadInvoice">
						<i class="fas fa-download"></i> 
						Download Invoice (PDF)
					</button>
					<a href="reservation.php" class="btn-back">
						<i class="fas fa-arrow-left"></i> 
						Back to Reservations
					</a>
				</div>
				
				<!-- THANK YOU MESSAGE -->
				<div style="text-align: center; margin-top: 30px; padding: 20px; background: rgba(196, 164, 132, 0.05); border-radius: 15px;">
					<h4 style="color: var(--eksa-navy); margin-bottom: 10px;">
						<i class="fas fa-heart" style="color: var(--eksa-gold);"></i> 
						THANK YOU, <?php echo strtoupper(htmlspecialchars($firstname)); ?>!
					</h4>
					<p style="color: var(--eksa-navy-light);">
						We look forward to welcoming you to Hotel Eksa on <?php echo date('F d, Y', strtotime($checkin_date)); ?>.
						Please present your reservation code <strong style="color: var(--eksa-gold-dark);"><?php echo $reservation_code; ?></strong> at the front desk.
					</p>
				</div>
				
				<?php endif; ?>
				
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Created by Pujan Pathak <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script>
	// Add active class to current menu item
	document.addEventListener('DOMContentLoaded', function() {
		var currentPage = window.location.pathname.split('/').pop();
		var menuItems = document.querySelectorAll('#menu li a');
		
		menuItems.forEach(function(item) {
			if (item.getAttribute('href') === currentPage) {
				item.style.background = 'var(--eksa-gold)';
				item.style.color = 'var(--eksa-navy)';
			}
		});
		
		<?php if (!empty($firstname)): ?>
		// Download Invoice as PDF
		document.getElementById('downloadInvoice').addEventListener('click', function() {
			var element = document.getElementById('invoiceContent');
			var opt = {
				margin:        [0.5, 0.5, 0.5, 0.5],
				filename:     'Hotel_Eksa_Invoice_<?php echo $invoice_number; ?>.pdf',
				image:        { type: 'jpeg', quality: 0.98 },
				html2canvas:  { scale: 2, letterRendering: true, useCORS: true },
				jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
			};
			
			// Show loading message
			swal({
				title: 'Generating Invoice',
				text: 'Please wait while we generate your PDF...',
				icon: 'info',
				buttons: false,
				timer: 2000
			});
			
			// Generate PDF
			html2pdf().set(opt).from(element).save();
		});
		
		// Auto-show success message when page loads
		swal({
			title: 'Reservation Confirmed!',
			text: 'Your booking has been successfully submitted. Your reservation code is <?php echo $reservation_code; ?>',
			icon: 'success',
			button: 'View Invoice'
		});
		<?php endif; ?>
	});
</script>
</html>