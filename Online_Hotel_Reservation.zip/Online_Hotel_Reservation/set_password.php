<?php
session_start();
require_once 'admin/connect.php';

// Redirect if no temp user
if (!isset($_SESSION['temp_user_id'])) {
    header("Location: user_login.php");
    exit();
}

$user_id = $_SESSION['temp_user_id'];
$user_email = $_SESSION['temp_user_email'];
$error = '';
$success = '';

if (isset($_POST['set_password'])) {
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    if (empty($password)) {
        $error = "Password is required.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $update = $conn->query("UPDATE `guest` SET `password` = '$hashed_password' WHERE `guest_id` = '$user_id'");
        
        if ($update) {
            unset($_SESSION['temp_user_id']);
            unset($_SESSION['temp_user_email']);
            $success = "Password set successfully! Please login.";
        } else {
            $error = "Failed to set password. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Eksa - Set Password</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
    <style>
        /* Same styles as user_login.php */
        :root {
            --eksa-gold: #C4A484;
            --eksa-gold-dark: #A67B5B;
            --eksa-navy: #0A1C2F;
            --eksa-navy-dark: #051220;
            --eksa-cream: #FAF7F2;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--eksa-cream) 0%, #fff 100%);
            color: var(--eksa-navy);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            max-width: 450px;
        }
        
        .card {
            background: white;
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.1);
            border: 1px solid rgba(196,164,132,0.2);
        }
        
        .hotel-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .hotel-logo i {
            font-size: 3rem;
            color: var(--eksa-gold);
            background: rgba(196,164,132,0.1);
            padding: 20px;
            border-radius: 20px;
            margin-bottom: 15px;
        }
        
        .hotel-logo h1 {
            font-family: 'Playfair Display', serif;
            color: var(--eksa-navy);
            font-size: 1.8rem;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--eksa-gold);
        }
        
        .form-control {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid rgba(196,164,132,0.2);
            border-radius: 15px;
            font-family: 'Poppins', sans-serif;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--eksa-gold);
            box-shadow: 0 0 0 5px rgba(196,164,132,0.2);
        }
        
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--eksa-gold);
            cursor: pointer;
        }
        
        .btn-submit {
            background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
            color: var(--eksa-navy-dark);
            border: none;
            padding: 16px;
            border-radius: 50px;
            font-weight: 700;
            width: 100%;
            transition: all 0.3s ease;
        }
        
        .btn-submit:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(196,164,132,0.3);
        }
        
        .alert {
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 25px;
        }
        
        .alert-danger {
            background: rgba(220,53,69,0.1);
            color: #dc3545;
            border-left: 5px solid #dc3545;
        }
        
        .alert-success {
            background: rgba(40,167,69,0.1);
            color: #28a745;
            border-left: 5px solid #28a745;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="hotel-logo">
                <i class="fas fa-h-square"></i>
                <h1>Hotel Eksa</h1>
                <p style="color: var(--eksa-navy-light);">Set Your Password</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
                <div class="text-center mt-4">
                    <a href="user_login.php" class="btn-submit" style="display: inline-block; text-decoration: none; padding: 12px 30px;">Go to Login</a>
                </div>
            <?php else: ?>
                <p style="color: var(--eksa-navy-light); margin-bottom: 25px;">
                    Please set a password for your account: <strong><?php echo htmlspecialchars($user_email); ?></strong>
                </p>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label style="font-weight: 600; margin-bottom: 8px; display: block;">
                            <i class="fas fa-lock" style="color: var(--eksa-gold);"></i> New Password
                        </label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" class="form-control" name="password" id="password" 
                                   placeholder="Enter new password" required minlength="6">
                            <i class="fas fa-eye password-toggle" onclick="togglePassword('password', this)"></i>
                        </div>
                        <small style="color: var(--eksa-navy-light);">Minimum 6 characters</small>
                    </div>
                    
                    <div class="form-group">
                        <label style="font-weight: 600; margin-bottom: 8px; display: block;">
                            <i class="fas fa-lock" style="color: var(--eksa-gold);"></i> Confirm Password
                        </label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" class="form-control" name="confirm_password" id="confirm_password" 
                                   placeholder="Confirm new password" required>
                            <i class="fas fa-eye password-toggle" onclick="togglePassword('confirm_password', this)"></i>
                        </div>
                    </div>
                    
                    <button type="submit" name="set_password" class="btn-submit">
                        <i class="fas fa-save"></i> SET PASSWORD
                    </button>
                </form>
                
                <div class="text-center mt-4">
                    <a href="user_login.php" style="color: var(--eksa-gold-dark); text-decoration: none;">
                        <i class="fas fa-arrow-left"></i> Back to Login
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword(inputId, element) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
                element.classList.remove('fa-eye');
                element.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                element.classList.remove('fa-eye-slash');
                element.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>