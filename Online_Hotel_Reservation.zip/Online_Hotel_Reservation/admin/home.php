<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Admin Dashboard</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Chart.js for analytics -->
		<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - ADMIN DASHBOARD ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 80px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 30px !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY DROPDOWN MENU ===== */
			.dropdown-menu {
				background: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				border-radius: 15px;
				box-shadow: 0 15px 40px var(--eksa-shadow-dark);
				padding: 10px;
			}
			
			.dropdown-menu li a {
				color: var(--eksa-navy);
				padding: 10px 20px;
				border-radius: 10px;
				transition: all 0.3s ease;
			}
			
			.dropdown-menu li a:hover {
				background: rgba(196, 164, 132, 0.1);
				color: var(--eksa-gold-dark);
			}
			
			.dropdown-menu li a i {
				color: var(--eksa-gold);
				margin-right: 10px;
			}
			
			/* ===== LUXURY NAV PILLS ===== */
			.nav-pills {
				margin: 20px 0;
				display: flex;
				flex-wrap: wrap;
				gap: 10px;
			}
			
			.nav-pills li {
				margin: 0;
			}
			
			.nav-pills li a {
				background: var(--eksa-white);
				color: var(--eksa-navy);
				padding: 12px 25px;
				border-radius: 50px;
				font-weight: 600;
				transition: all 0.3s ease;
				border: 2px solid rgba(196, 164, 132, 0.2);
				text-decoration: none;
				display: inline-block;
			}
			
			.nav-pills li a:hover {
				background: rgba(196, 164, 132, 0.1);
				border-color: var(--eksa-gold);
				transform: translateY(-2px);
			}
			
			.nav-pills li.active a {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				border-color: var(--eksa-white);
			}
			
			/* ===== LUXURY DASHBOARD CARDS ===== */
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white);
				border-radius: 30px;
				padding: 40px;
				box-shadow: 0 30px 60px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			.welcome-section {
				text-align: center;
				margin-bottom: 40px;
			}
			
			.welcome-section h2 {
				color: var(--eksa-navy);
				font-size: 2.8rem;
				margin-bottom: 10px;
			}
			
			.welcome-section h2 span {
				color: var(--eksa-gold-dark);
			}
			
			.welcome-section p {
				color: var(--eksa-navy-light);
				font-size: 1.1rem;
			}
			
			.admin-badge {
				display: inline-block;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				color: var(--eksa-navy-dark);
				padding: 8px 25px;
				border-radius: 50px;
				font-weight: 700;
				margin-bottom: 20px;
			}
			
			.admin-badge i {
				margin-right: 10px;
			}
			
			/* ===== STATISTICS CARDS ===== */
			.stats-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
				gap: 25px;
				margin-bottom: 40px;
			}
			
			.stat-card {
				background: var(--eksa-white);
				border-radius: 20px;
				padding: 25px;
				box-shadow: 0 15px 35px var(--eksa-shadow);
				border: 1px solid rgba(196, 164, 132, 0.2);
				transition: all 0.4s ease;
				position: relative;
				overflow: hidden;
			}
			
			.stat-card:hover {
				transform: translateY(-10px);
				border-color: var(--eksa-gold);
				box-shadow: 0 25px 50px var(--eksa-gold-glow);
			}
			
			.stat-icon {
				width: 60px;
				height: 60px;
				background: rgba(196, 164, 132, 0.1);
				border-radius: 15px;
				display: flex;
				align-items: center;
				justify-content: center;
				margin-bottom: 20px;
			}
			
			.stat-icon i {
				font-size: 2rem;
				color: var(--eksa-gold);
			}
			
			.stat-label {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
				text-transform: uppercase;
				letter-spacing: 1px;
			}
			
			.stat-number {
				font-size: 2.5rem;
				font-weight: 800;
				color: var(--eksa-navy);
				line-height: 1.2;
				margin-top: 5px;
			}
			
			.stat-change {
				margin-top: 15px;
				font-size: 0.85rem;
				color: #28a745;
			}
			
			/* ===== LUXURY HERO IMAGE ===== */
			.hero-image-container {
				position: relative;
				border-radius: 20px;
				overflow: hidden;
				box-shadow: 0 20px 40px var(--eksa-shadow-dark);
				border: 5px solid var(--eksa-white);
				outline: 2px solid var(--eksa-gold);
				margin-bottom: 30px;
			}
			
			.hero-image-container img {
				width: 100%;
				height: auto;
				max-height: 500px;
				object-fit: cover;
				display: block;
				transition: transform 0.8s ease;
			}
			
			.hero-image-container:hover img {
				transform: scale(1.05);
			}
			
			.image-overlay {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, rgba(10,28,47,0.7), rgba(10,28,47,0.3));
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				opacity: 0;
				transition: opacity 0.5s ease;
				color: var(--eksa-white);
			}
			
			.hero-image-container:hover .image-overlay {
				opacity: 1;
			}
			
			.image-overlay i {
				font-size: 4rem;
				color: var(--eksa-gold);
				margin-bottom: 20px;
			}
			
			.image-overlay h3 {
				color: var(--eksa-white);
				font-size: 2rem;
				margin-bottom: 10px;
			}
			
			.image-overlay p {
				font-size: 1.1rem;
				color: var(--eksa-gold-light);
			}
			
			/* ===== QUICK ACTIONS ===== */
			.quick-actions {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
				gap: 20px;
				margin-top: 40px;
			}
			
			.action-btn {
				background: var(--eksa-white);
				border: 2px solid rgba(196, 164, 132, 0.3);
				border-radius: 15px;
				padding: 25px;
				text-align: center;
				transition: all 0.4s ease;
				text-decoration: none;
				color: var(--eksa-navy);
			}
			
			.action-btn:hover {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				border-color: var(--eksa-white);
				transform: translateY(-5px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
				color: var(--eksa-navy-dark);
			}
			
			.action-btn i {
				font-size: 2rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
				transition: all 0.3s ease;
			}
			
			.action-btn:hover i {
				color: var(--eksa-navy-dark);
				transform: scale(1.1);
			}
			
			.action-btn h4 {
				font-size: 1.2rem;
				margin-bottom: 5px;
			}
			
			.action-btn p {
				font-size: 0.85rem;
				opacity: 0.8;
				margin: 0;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 768px) {
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.nav-pills {
					flex-direction: column;
				}
				
				.nav-pills li a {
					display: block;
					text-align: center;
				}
				
				.panel-body {
					padding: 30px;
				}
				
				.welcome-section h2 {
					font-size: 2rem;
				}
				
				.stats-grid {
					grid-template-columns: 1fr;
				}
				
				.quick-actions {
					grid-template-columns: 1fr;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 30px !important;
				padding-right: 30px !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
			<ul class = "nav navbar-nav pull-right">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						<i class="fas fa-user-circle" style="color: var(--eksa-gold); font-size: 1.2rem;"></i> 
						<span style="color: var(--eksa-white); font-weight: 600;"><?php echo $name; ?></span>
						<span class="caret" style="color: var(--eksa-gold);"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
						<li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
						<li class="divider"></li>
						<li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	
	<!-- LUXURY NAVIGATION PILLS -->
	<div class = "container-fluid">
		<ul class = "nav nav-pills">
			<li class = "active"><a href = "home.php"><i class="fas fa-home me-2"></i> Dashboard</a></li>
			<li><a href = "account.php"><i class="fas fa-users-cog me-2"></i> Accounts</a></li>
			<li><a href = "reserve.php"><i class="fas fa-calendar-check me-2"></i> Pending</a></li>
			<li><a href = "checkin.php"><i class="fas fa-sign-in-alt me-2"></i> Check In</a></li>
			<li><a href = "checkout.php"><i class="fas fa-sign-out-alt me-2"></i> Check Out</a></li>
			<li><a href = "room.php"><i class="fas fa-bed me-2"></i> Rooms</a></li>
			<li><a href = "reports.php"><i class="fas fa-chart-line me-2"></i> Reports</a></li>
		</ul>
	</div>
	
	<br />
	
	<!-- LUXURY DASHBOARD CONTENT -->
	<div class = "container-fluid">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- WELCOME SECTION -->
				<div class="welcome-section">
					<span class="admin-badge">
						<i class="fas fa-crown"></i> ADMINISTRATOR
					</span>
					<h2>
						Welcome back, <span><?php echo explode(' ', $name)[0]; ?>!</span>
					</h2>
					<p>
						<i class="fas fa-calendar-alt" style="color: var(--eksa-gold);"></i> 
						<?php echo date('l, F d, Y'); ?>
					</p>
				</div>
				
				<!-- STATISTICS CARDS -->
				<?php
					// Get real statistics from database - FIXED: Using correct table names
					require_once 'connect.php';
					
					// Total rooms
					$rooms_query = $conn->query("SELECT COUNT(*) as count FROM `room`");
					$total_rooms = ($rooms_query && $rooms_query->num_rows > 0) ? $rooms_query->fetch_assoc()['count'] : 0;
					if ($total_rooms == 0) $total_rooms = 5; // Default if no data
					
					// Total reservations/transactions
					$reservations_query = $conn->query("SELECT COUNT(*) as count FROM `transaction`");
					$total_reservations = ($reservations_query && $reservations_query->num_rows > 0) ? $reservations_query->fetch_assoc()['count'] : 0;
					
					// Total guests (unique)
					$guests_query = $conn->query("SELECT COUNT(DISTINCT guest_id) as count FROM `transaction`");
					$total_guests = ($guests_query && $guests_query->num_rows > 0) ? $guests_query->fetch_assoc()['count'] : 0;
					
					// Today's check-ins
					$today = date('Y-m-d');
					$checkins_query = $conn->query("SELECT COUNT(*) as count FROM `transaction` WHERE `checkin` = '$today' AND `status` = 'Check In'");
					$today_checkins = ($checkins_query && $checkins_query->num_rows > 0) ? $checkins_query->fetch_assoc()['count'] : 0;
					
					// Pending reservations
					$pending_query = $conn->query("SELECT COUNT(*) as count FROM `transaction` WHERE `status` = 'Pending'");
					$pending_reservations = ($pending_query && $pending_query->num_rows > 0) ? $pending_query->fetch_assoc()['count'] : 0;
					
					// Checked in guests
					$checked_in_query = $conn->query("SELECT COUNT(*) as count FROM `transaction` WHERE `status` = 'Check In'");
					$checked_in = ($checked_in_query && $checked_in_query->num_rows > 0) ? $checked_in_query->fetch_assoc()['count'] : 0;
					
					// Monthly revenue - from transaction table
					$month_start = date('Y-m-01');
					$month_end = date('Y-m-t');
					$revenue_query = $conn->query("SELECT SUM(`bill`) as total FROM `transaction` WHERE `status` = 'Check Out' AND `checkout` BETWEEN '$month_start' AND '$month_end'");
					$revenue_result = $revenue_query->fetch_assoc();
					$monthly_revenue = ($revenue_result && $revenue_result['total'] != null) ? floatval($revenue_result['total']) : 0;
					
					// Occupied rooms
					$occupied_query = $conn->query("SELECT COUNT(DISTINCT room_no) as count FROM `transaction` WHERE `status` = 'Check In' AND `room_no` IS NOT NULL");
					$occupied_rooms = ($occupied_query && $occupied_query->num_rows > 0) ? $occupied_query->fetch_assoc()['count'] : 0;
					
					// Calculate occupancy percentage
					$occupancy_percentage = $total_rooms > 0 ? round(($occupied_rooms / $total_rooms) * 100) : 0;
				?>
				
				<div class="stats-grid">
					<div class="stat-card">
						<div class="stat-icon">
							<i class="fas fa-bed"></i>
						</div>
						<div class="stat-label">Total Rooms</div>
						<div class="stat-number"><?php echo $total_rooms; ?></div>
						<div class="stat-change">
							<i class="fas fa-door-open"></i> <?php echo $occupied_rooms; ?> occupied
						</div>
					</div>
					
					<div class="stat-card">
						<div class="stat-icon">
							<i class="fas fa-calendar-check"></i>
						</div>
						<div class="stat-label">Pending</div>
						<div class="stat-number"><?php echo $pending_reservations; ?></div>
						<div class="stat-change">
							<i class="fas fa-clock"></i> Awaiting confirmation
						</div>
					</div>
					
					<div class="stat-card">
						<div class="stat-icon">
							<i class="fas fa-sign-in-alt"></i>
						</div>
						<div class="stat-label">Checked In</div>
						<div class="stat-number"><?php echo $checked_in; ?></div>
						<div class="stat-change">
							<i class="fas fa-users"></i> Current guests
						</div>
					</div>
					
					<div class="stat-card">
						<div class="stat-icon">
							<i class="fas fa-coin"></i>
						</div>
						<div class="stat-label">Monthly Revenue</div>
						<div class="stat-number">Rs. <?php echo number_format($monthly_revenue, 2); ?></div>
						<div class="stat-change">
							<i class="fas fa-calendar-alt"></i> <?php echo date('M Y'); ?>
						</div>
					</div>
				</div>
				
				<!-- HERO IMAGE WITH OVERLAY -->
				<div class="hero-image-container">
					<img src = "../images/back.jpg" alt="Hotel Eksa Luxury" />
					<div class="image-overlay">
						<i class="fas fa-crown"></i>
						<h3>HOTEL EKSA</h3>
						<p>Luxury Beyond Ordinary</p>
					</div>
				</div>
				
				<!-- TODAY'S SUMMARY -->
				<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px;">
					<div style="background: rgba(196,164,132,0.05); padding: 25px; border-radius: 20px; border-left: 5px solid var(--eksa-gold);">
						<h4 style="color: var(--eksa-navy); margin-bottom: 15px;">
							<i class="fas fa-calendar-day" style="color: var(--eksa-gold);"></i> Today's Schedule
						</h4>
						<div style="display: flex; justify-content: space-between; align-items: center;">
							<div>
								<p style="margin: 0; color: var(--eksa-navy-light);">Check-ins</p>
								<h3 style="color: var(--eksa-gold-dark); font-size: 2rem; margin: 5px 0;"><?php echo $today_checkins; ?></h3>
							</div>
							<div>
								<p style="margin: 0; color: var(--eksa-navy-light);">Available Rooms</p>
								<h3 style="color: var(--eksa-gold-dark); font-size: 2rem; margin: 5px 0;"><?php echo $total_rooms - $occupied_rooms; ?></h3>
							</div>
							<div>
								<p style="margin: 0; color: var(--eksa-navy-light);">Occupancy</p>
								<h3 style="color: var(--eksa-gold-dark); font-size: 2rem; margin: 5px 0;"><?php echo $occupancy_percentage; ?>%</h3>
							</div>
						</div>
					</div>
					
					<div style="background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)); padding: 25px; border-radius: 20px; color: white;">
						<h4 style="color: var(--eksa-gold); margin-bottom: 15px;">
							<i class="fas fa-gift"></i> Quick Stats
						</h4>
						<div style="display: flex; justify-content: space-around; align-items: center;">
							<div>
								<p style="margin: 0; color: var(--eksa-cream);">Total Guests</p>
								<h3 style="color: var(--eksa-gold); font-size: 2rem; margin: 5px 0;"><?php echo $total_guests; ?></h3>
							</div>
							<div>
								<p style="margin: 0; color: var(--eksa-cream);">Bookings</p>
								<h3 style="color: var(--eksa-gold); font-size: 2rem; margin: 5px 0;"><?php echo $total_reservations; ?></h3>
							</div>
						</div>
					</div>
				</div>
				
				<!-- QUICK ACTIONS -->
				<h3 style="color: var(--eksa-navy); margin-bottom: 20px; font-family: 'Playfair Display';">
					<i class="fas fa-bolt" style="color: var(--eksa-gold);"></i> Quick Actions
				</h3>
				
				<div class="quick-actions">
					<a href="reserve.php" class="action-btn">
						<i class="fas fa-calendar-plus"></i>
						<h4>Pending Reservations</h4>
						<p><?php echo $pending_reservations; ?> awaiting confirmation</p>
					</a>
					<a href="checkin.php" class="action-btn">
						<i class="fas fa-sign-in-alt"></i>
						<h4>Check In</h4>
						<p>Manage guest check-ins</p>
					</a>
					<a href="checkout.php" class="action-btn">
						<i class="fas fa-sign-out-alt"></i>
						<h4>Check Out</h4>
						<p>Process guest check-outs</p>
					</a>
					<a href="room.php" class="action-btn">
						<i class="fas fa-door-open"></i>
						<h4>Manage Rooms</h4>
						<p>Add or update rooms</p>
					</a>
					<a href="account.php" class="action-btn">
						<i class="fas fa-user-plus"></i>
						<h4>Staff Accounts</h4>
						<p>Manage administrators</p>
					</a>
					<a href="reports.php" class="action-btn">
						<i class="fas fa-chart-line"></i>
						<h4>Reports</h4>
						<p>View analytics</p>
					</a>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • MANAGEMENT SYSTEM • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Welcome, <?php echo explode(' ', $name)[0]; ?>! <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script>
	// Add animation to stat cards
	$(document).ready(function() {
		$('.stat-card').each(function(index) {
			$(this).css({
				'opacity': '0',
				'transform': 'translateY(30px)'
			});
			
			setTimeout(() => {
				$(this).css({
					'transition': 'all 0.6s ease',
					'opacity': '1',
					'transform': 'translateY(0)'
				});
			}, 100 * index);
		});
	});
</script>
</html>