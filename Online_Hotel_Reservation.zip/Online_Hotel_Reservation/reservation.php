<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Eksa - Make a Reservation</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<!-- Font Awesome 6 -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<!-- Sweet Alert -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<!-- YOUR EXISTING CSS - NO PATH CHANGES -->
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
		
		<style>
			/* ===== HOTEL EKSA LUXURY THEME - NO PATH CHANGES ===== */
			:root {
				--eksa-gold: #C4A484;
				--eksa-gold-light: #E5D3B0;
				--eksa-gold-dark: #A67B5B;
				--eksa-navy: #0A1C2F;
				--eksa-navy-light: #1E3A5F;
				--eksa-navy-dark: #051220;
				--eksa-cream: #FAF7F2;
				--eksa-white: #FFFFFF;
				--eksa-shadow: rgba(10, 28, 47, 0.1);
				--eksa-shadow-dark: rgba(10, 28, 47, 0.2);
				--eksa-gold-glow: rgba(196, 164, 132, 0.3);
			}
			
			body {
				font-family: 'Poppins', sans-serif;
				background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
				color: var(--eksa-navy);
				overflow-x: hidden;
				padding-bottom: 100px;
			}
			
			h1, h2, h3, h4, h5, h6, .navbar-brand {
				font-family: 'Playfair Display', serif !important;
				font-weight: 700 !important;
			}
			
			/* ===== LUXURY NAVIGATION ===== */
			nav.navbar {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-bottom: 3px solid var(--eksa-gold) !important;
				padding: 15px 0 !important;
				margin-bottom: 0 !important;
				box-shadow: 0 5px 25px rgba(0,0,0,0.2) !important;
			}
			
			.navbar-brand {
				color: var(--eksa-gold) !important;
				font-size: 1.8rem !important;
				letter-spacing: 2px !important;
				text-shadow: 2px 2px 4px rgba(0,0,0,0.3) !important;
				position: relative;
				padding-left: 20px !important;
			}
			
			.navbar-brand::before {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				left: -5px;
				top: 5px;
			}
			
			.navbar-brand::after {
				content: '✦';
				color: var(--eksa-gold);
				font-size: 2rem;
				position: absolute;
				right: -15px;
				top: 5px;
			}
			
			/* ===== LUXURY MENU ===== */
			#menu {
				background: linear-gradient(135deg, var(--eksa-navy-light), var(--eksa-navy));
				padding: 15px 5% !important;
				margin: 0 !important;
				display: flex !important;
				flex-wrap: wrap !important;
				justify-content: center !important;
				align-items: center !important;
				gap: 10px !important;
				list-style: none !important;
				border-bottom: 1px solid var(--eksa-gold);
				box-shadow: 0 5px 15px var(--eksa-shadow);
			}
			
			#menu li {
				display: inline-block;
				margin: 0 5px;
			}
			
			#menu li a {
				color: var(--eksa-white) !important;
				text-decoration: none !important;
				font-size: 0.95rem;
				font-weight: 500;
				padding: 8px 18px !important;
				border-radius: 30px !important;
				transition: all 0.3s ease !important;
				position: relative;
				letter-spacing: 1px;
			}
			
			#menu li a:hover {
				background: var(--eksa-gold) !important;
				color: var(--eksa-navy) !important;
				transform: translateY(-2px);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			#menu li:not(:last-child)::after {
				content: "|";
				color: var(--eksa-gold);
				margin-left: 10px;
				font-weight: 300;
				opacity: 0.7;
			}
			
			/* ===== LUXURY RESERVATION CONTAINER ===== */
			.container {
				width: 95%;
				max-width: 1400px;
				margin: 40px auto !important;
				padding: 0 !important;
			}
			
			.panel {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
			}
			
			.panel-body {
				background: var(--eksa-white) !important;
				padding: 50px !important;
				border-radius: 30px !important;
				box-shadow: 0 30px 60px var(--eksa-shadow) !important;
				border: 1px solid rgba(196, 164, 132, 0.2) !important;
				position: relative;
				overflow: hidden;
			}
			
			.panel-body::before {
				content: '✦ ✦ ✦';
				position: absolute;
				bottom: -20px;
				right: -20px;
				font-size: 12rem;
				color: rgba(196, 164, 132, 0.05);
				font-family: serif;
				transform: rotate(-15deg);
			}
			
			/* ===== LUXURY RESERVATION HEADER ===== */
			.reservation-header {
				text-align: center;
				margin-bottom: 50px;
				position: relative;
			}
			
			.reservation-header h3 {
				font-size: 3rem !important;
				color: var(--eksa-navy) !important;
				margin: 0 0 20px 0 !important;
				position: relative;
				display: inline-block;
			}
			
			.reservation-header h3::before {
				content: '≼';
				color: var(--eksa-gold);
				margin-right: 20px;
				font-size: 2.5rem;
			}
			
			.reservation-header h3::after {
				content: '≽';
				color: var(--eksa-gold);
				margin-left: 20px;
				font-size: 2.5rem;
			}
			
			.reservation-header p {
				color: var(--eksa-navy-light);
				font-size: 1.1rem;
				max-width: 700px;
				margin: 0 auto;
			}
			
			/* ===== LUXURY ROOM CARDS ===== */
			.room-card {
				background: linear-gradient(135deg, var(--eksa-white), var(--eksa-cream));
				border-radius: 20px;
				overflow: hidden;
				box-shadow: 0 15px 40px var(--eksa-shadow);
				transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
				margin-bottom: 40px;
				position: relative;
				border: 1px solid rgba(196, 164, 132, 0.2);
				display: flex;
				flex-wrap: wrap;
			}
			
			.room-card:hover {
				transform: translateY(-10px);
				box-shadow: 0 30px 60px var(--eksa-shadow-dark);
				border-color: var(--eksa-gold);
			}
			
			.room-image {
				flex: 0 0 350px;
				position: relative;
				overflow: hidden;
			}
			
			.room-image img {
				width: 100%;
				height: 280px;
				object-fit: cover;
				transition: transform 0.8s ease;
				display: block;
			}
			
			.room-card:hover .room-image img {
				transform: scale(1.1);
			}
			
			.room-image::after {
				content: '';
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: linear-gradient(to right, rgba(10,28,47,0.2), transparent);
			}
			
			.room-badge {
				position: absolute;
				top: 20px;
				left: 20px;
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				padding: 8px 20px;
				border-radius: 50px;
				font-weight: 700;
				font-size: 0.9rem;
				z-index: 10;
				letter-spacing: 1px;
				box-shadow: 0 5px 15px rgba(0,0,0,0.2);
			}
			
			.room-details {
				flex: 1;
				padding: 30px;
				position: relative;
			}
			
			.room-details h3 {
				color: var(--eksa-navy);
				font-size: 2rem;
				margin-bottom: 15px;
				font-weight: 700;
			}
			
			.room-price {
				margin-bottom: 20px;
				display: flex;
				align-items: baseline;
				gap: 10px;
			}
			
			.price-label {
				font-size: 1rem;
				color: var(--eksa-navy-light);
				font-weight: 400;
			}
			
			.price-amount {
				font-size: 2.2rem;
				font-weight: 800;
				color: var(--eksa-gold-dark);
			}
			
			.price-currency {
				font-size: 1.2rem;
				color: var(--eksa-gold);
				font-weight: 600;
			}
			
			.price-period {
				font-size: 0.9rem;
				color: var(--eksa-navy-light);
				margin-left: 5px;
			}
			
			.room-amenities {
				display: flex;
				flex-wrap: wrap;
				gap: 20px;
				margin: 25px 0;
				padding: 20px 0;
				border-top: 1px solid rgba(196,164,132,0.2);
				border-bottom: 1px solid rgba(196,164,132,0.2);
			}
			
			.amenity {
				display: flex;
				align-items: center;
				gap: 10px;
			}
			
			.amenity i {
				font-size: 1.2rem;
				color: var(--eksa-gold);
			}
			
			.amenity span {
				font-size: 0.9rem;
				color: var(--eksa-navy-light);
			}
			
			.room-description {
				color: var(--eksa-navy-light);
				font-size: 0.95rem;
				line-height: 1.7;
				margin-bottom: 25px;
			}
			
			.btn-reserve {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
				color: var(--eksa-white);
				border: 2px solid var(--eksa-gold);
				padding: 14px 35px;
				border-radius: 50px;
				font-size: 1rem;
				font-weight: 700;
				letter-spacing: 2px;
				cursor: pointer;
				transition: all 0.4s ease;
				display: inline-flex;
				align-items: center;
				justify-content: center;
				gap: 12px;
				text-decoration: none;
				position: relative;
				overflow: hidden;
				z-index: 1;
			}
			
			.btn-reserve::before {
				content: '';
				position: absolute;
				top: 0;
				left: -100%;
				width: 100%;
				height: 100%;
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				transition: left 0.4s ease;
				z-index: -1;
			}
			
			.btn-reserve:hover::before {
				left: 0;
			}
			
			.btn-reserve:hover {
				color: var(--eksa-navy-dark);
				border-color: transparent;
				transform: translateY(-3px);
				box-shadow: 0 15px 30px var(--eksa-gold-glow);
			}
			
			.btn-reserve i {
				font-size: 1.1rem;
				transition: transform 0.3s ease;
			}
			
			.btn-reserve:hover i {
				transform: translateX(5px);
			}
			
			/* ===== LUXURY SPECIAL OFFER ===== */
			.special-offer {
				background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
				border-radius: 20px;
				padding: 40px;
				margin-top: 50px;
				display: flex;
				flex-wrap: wrap;
				align-items: center;
				justify-content: space-between;
				position: relative;
				overflow: hidden;
			}
			
			.special-offer::before {
				content: '%';
				position: absolute;
				bottom: -30px;
				right: -30px;
				font-size: 15rem;
				color: rgba(10,28,47,0.1);
				font-weight: 900;
				transform: rotate(20deg);
			}
			
			.offer-content {
				flex: 1;
				min-width: 250px;
			}
			
			.offer-content h4 {
				color: var(--eksa-navy-dark);
				font-size: 2rem;
				margin-bottom: 15px;
			}
			
			.offer-content p {
				color: var(--eksa-navy);
				font-size: 1rem;
				margin-bottom: 10px;
			}
			
			.offer-badge {
				background: var(--eksa-navy);
				color: var(--eksa-gold);
				padding: 15px 30px;
				border-radius: 50px;
				font-weight: 800;
				font-size: 1.8rem;
				display: inline-block;
				box-shadow: 0 10px 30px rgba(0,0,0,0.2);
			}
			
			.offer-badge small {
				font-size: 0.9rem;
				font-weight: 400;
				margin-left: 5px;
			}
			
			.offer-cta {
				background: var(--eksa-white);
				color: var(--eksa-navy);
				padding: 15px 35px;
				border-radius: 50px;
				font-weight: 700;
				text-decoration: none;
				transition: all 0.3s ease;
				display: inline-flex;
				align-items: center;
				gap: 10px;
				border: 2px solid var(--eksa-navy);
				margin-left: 30px;
			}
			
			.offer-cta:hover {
				background: var(--eksa-navy);
				color: var(--eksa-gold);
				transform: translateY(-3px);
				box-shadow: 0 10px 25px rgba(0,0,0,0.2);
			}
			
			/* ===== LUXURY BOOKING STEPS ===== */
			.booking-steps {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
				gap: 30px;
				margin: 60px 0 20px;
			}
			
			.step-item {
				text-align: center;
				padding: 30px;
				background: var(--eksa-cream);
				border-radius: 20px;
				position: relative;
			}
			
			.step-number {
				width: 50px;
				height: 50px;
				background: var(--eksa-gold);
				color: var(--eksa-navy);
				border-radius: 50%;
				display: flex;
				align-items: center;
				justify-content: center;
				font-size: 1.5rem;
				font-weight: 800;
				margin: 0 auto 20px;
				border: 3px solid var(--eksa-white);
				box-shadow: 0 5px 15px var(--eksa-gold-glow);
			}
			
			.step-item i {
				font-size: 2rem;
				color: var(--eksa-gold);
				margin-bottom: 15px;
			}
			
			.step-item h5 {
				color: var(--eksa-navy);
				font-size: 1.2rem;
				margin-bottom: 10px;
			}
			
			.step-item p {
				color: var(--eksa-navy-light);
				font-size: 0.9rem;
			}
			
			/* ===== LUXURY FOOTER ===== */
			.navbar-fixed-bottom {
				background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark)) !important;
				border: none !important;
				border-top: 2px solid var(--eksa-gold) !important;
				padding: 20px 0 !important;
				color: var(--eksa-white) !important;
				position: relative !important;
				margin-top: 50px !important;
			}
			
			.navbar-fixed-bottom label {
				color: var(--eksa-gold-light) !important;
				font-size: 1rem !important;
				font-weight: 400 !important;
				letter-spacing: 2px !important;
			}
			
			.navbar-fixed-bottom label::before {
				content: '✦ ';
				color: var(--eksa-gold);
			}
			
			.navbar-fixed-bottom label::after {
				content: ' ✦';
				color: var(--eksa-gold);
			}
			
			/* ===== RESPONSIVE ===== */
			@media (max-width: 992px) {
				.room-card {
					flex-direction: column;
				}
				
				.room-image {
					flex: 0 0 auto;
				}
				
				.room-image img {
					height: 300px;
				}
				
				.special-offer {
					flex-direction: column;
					text-align: center;
					gap: 30px;
				}
				
				.offer-cta {
					margin-left: 0;
				}
				
				.panel-body {
					padding: 40px !important;
				}
				
				.reservation-header h3 {
					font-size: 2.5rem !important;
				}
			}
			
			@media (max-width: 768px) {
				#menu {
					flex-direction: column;
					gap: 5px !important;
				}
				
				#menu li:not(:last-child)::after {
					display: none;
				}
				
				.navbar-brand {
					font-size: 1.2rem !important;
				}
				
				.panel-body {
					padding: 30px !important;
				}
				
				.reservation-header h3 {
					font-size: 2rem !important;
				}
				
				.reservation-header h3::before,
				.reservation-header h3::after {
					font-size: 1.8rem;
				}
				
				.room-details {
					padding: 25px;
				}
				
				.room-details h3 {
					font-size: 1.6rem;
				}
				
				.price-amount {
					font-size: 1.8rem;
				}
				
				.room-amenities {
					gap: 15px;
				}
				
				.booking-steps {
					grid-template-columns: 1fr;
				}
			}
			
			@media (max-width: 480px) {
				.panel-body {
					padding: 20px !important;
				}
				
				.room-image img {
					height: 220px;
				}
				
				.room-amenities {
					flex-direction: column;
					gap: 10px;
				}
				
				.btn-reserve {
					width: 100%;
				}
				
				.offer-badge {
					font-size: 1.5rem;
					padding: 12px 25px;
				}
			}
			
			/* Override Bootstrap defaults */
			.container-fluid {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			
			.navbar-default .navbar-brand:hover,
			.navbar-default .navbar-brand:focus {
				color: var(--eksa-gold-light) !important;
			}
			
			.well {
				background: transparent !important;
				border: none !important;
				box-shadow: none !important;
				margin-bottom: 0 !important;
				padding: 0 !important;
			}
		</style>
	</head>
<body>
	<!-- LUXURY NAVIGATION -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand">
					<i class="fas fa-h-square" style="color: var(--eksa-gold); margin-right: 10px;"></i>
					Hotel Eksa
				</a>
			</div>
		</div>
	</nav>
	
	<!-- LUXURY MENU -->
	<ul id = "menu">
		<li><a href = "index.php"><i class="fas fa-home me-2"></i> Home</a></li>
		<li><a href = "aboutus.php"><i class="fas fa-info-circle me-2"></i> About us</a></li>
		<li><a href = "contactus.php"><i class="fas fa-phone-alt me-2"></i> Contact us</a></li>
		<li><a href = "gallery.php"><i class="fas fa-images me-2"></i> Gallery</a></li>
		<li><a href = "dineandlounge.php"><i class="fas fa-utensils me-2"></i> Dine & Lounge</a></li>
		<li><a href = "reservation.php"><i class="fas fa-calendar-check me-2"></i> Make a reservation</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> Admin Login</a></li>
		<li><a href = "admin/index.php"><i class="fas fa-book me-2"></i> User Login</a></li>
	</ul>
	
	<!-- LUXURY RESERVATION CONTENT -->
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				
				<!-- RESERVATION HEADER -->
				<div class="reservation-header">
					<strong><h3>Book Your Stay</h3></strong>
					<p>Experience unparalleled luxury at Hotel Eksa. Select your preferred room and reserve your sanctuary.</p>
				</div>
				
				<?php
					require_once 'admin/connect.php';
					$query = $conn->query("SELECT * FROM `room` ORDER BY `price` ASC") or die(mysql_error());
					$room_count = 0;
					while($fetch = $query->fetch_array()){
						$room_count++;
				?>
					<div class = "well">
						<div class="room-card">
							<div class="room-image">
								<span class="room-badge">
									<?php 
										if($fetch['room_id'] == 1) echo "BEST VALUE";
										elseif($fetch['room_id'] == 5) echo "PREMIUM";
										elseif($fetch['room_id'] == 4) echo "LUXURY";
										else echo "FEATURED";
									?>
								</span>
								<img src = "photo/<?php echo $fetch['photo']?>" alt="<?php echo $fetch['room_type']?>"/>
							</div>
							<div class="room-details">
								<h3><?php echo $fetch['room_type']?></h3>
								
								<div class="room-price">
									<span class="price-label">Starting from</span>
									<span class="price-currency">Rs.</span>
									<span class="price-amount"><?php echo number_format($fetch['price'], 0)?></span>
									<span class="price-period">/ night</span>
								</div>
								
								<div class="room-amenities">
									<div class="amenity">
										<i class="fas fa-wifi"></i>
										<span>Free WiFi</span>
									</div>
									<div class="amenity">
										<i class="fas fa-snowflake"></i>
										<span>Air Conditioning</span>
									</div>
									<div class="amenity">
										<i class="fas fa-tv"></i>
										<span>Smart TV</span>
									</div>
									<div class="amenity">
										<i class="fas fa-coffee"></i>
										<span>Coffee Maker</span>
									</div>
									<div class="amenity">
										<i class="fas fa-bath"></i>
										<span>Private Bathroom</span>
									</div>
								</div>
								
								<div class="room-description">
									<?php
										// Generate room description based on room type
										switch($fetch['room_type']) {
											case 'Standard':
												echo 'Our Standard Room offers cozy comfort with modern amenities. Perfect for business travelers and solo adventurers seeking a relaxing stay.';
												break;
											case 'Superior':
												echo 'Superior Rooms provide enhanced comfort with medium-sized beds and upgraded amenities. Ideal for couples and discerning guests.';
												break;
											case 'Super Deluxe':
												echo 'Super Deluxe features two medium beds and premium amenities. Perfect for families or colleagues traveling together.';
												break;
											case 'Jr. Suite':
												echo 'Junior Suite offers matrimonial bedding and separate living area. Experience elevated luxury with exclusive amenities.';
												break;
											case 'Executive Suite':
												echo 'Our Executive Suite features a king-sized matrimonial bed, separate living and dining areas. The pinnacle of luxury living.';
												break;
											default:
												echo 'Experience the signature Hotel Eksa comfort with premium amenities and elegant design. Your perfect stay awaits.';
										}
									?>
								</div>
								
								<a href = "add_reserve.php?room_id=<?php echo $fetch['room_id']?>" class="btn-reserve">
									<i class="fas fa-calendar-check"></i> 
									Reserve Now
									<i class="fas fa-arrow-right"></i>
								</a>
							</div>
						</div>
					</div>
				<?php
					}
					
					// If no rooms found, display message
					if($room_count == 0) {
						echo '<div style="text-align: center; padding: 60px 20px;">';
						echo '<i class="fas fa-bed" style="font-size: 4rem; color: var(--eksa-gold); margin-bottom: 20px;"></i>';
						echo '<h3 style="color: var(--eksa-navy); margin-bottom: 15px;">No Rooms Available</h3>';
						echo '<p style="color: var(--eksa-navy-light);">Please check back later or contact our reservation team.</p>';
						echo '</div>';
					}
				?>
				
				<!-- BOOKING STEPS -->
				<div class="booking-steps">
					<div class="step-item">
						<div class="step-number">1</div>
						<i class="fas fa-calendar-alt"></i>
						<h5>Select Dates</h5>
						<p>Choose your check-in and check-out dates</p>
					</div>
					<div class="step-item">
						<div class="step-number">2</div>
						<i class="fas fa-bed"></i>
						<h5>Choose Room</h5>
						<p>Select your preferred room type</p>
					</div>
					<div class="step-item">
						<div class="step-number">3</div>
						<i class="fas fa-user"></i>
						<h5>Guest Details</h5>
						<p>Provide your contact information</p>
					</div>
					<div class="step-item">
						<div class="step-number">4</div>
						<i class="fas fa-credit-card"></i>
						<h5>Confirm Booking</h5>
						<p>Review and confirm your reservation</p>
					</div>
				</div>
				
				<!-- SPECIAL OFFER -->
				<div class="special-offer">
					<div class="offer-content">
						<h4>Special Offer</h4>
						<p>Book 3 nights or more and enjoy exclusive benefits</p>
						<div class="offer-badge">
							20% <small>OFF</small>
						</div>
					</div>
					<a href="reservation.php" class="offer-cta">
						<i class="fas fa-gift"></i> 
						Claim Offer
					</a>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- LUXURY FOOTER -->
	<div style = "text-align:center; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label>HOTEL EKSA • LUXURY BEYOND ORDINARY • EST. 2026 </label>
		<div style="margin-top: 5px; color: var(--eksa-gold-light); font-size: 0.8rem;">
			<i class="fas fa-heart"></i> Created by Pujan Pathak <i class="fas fa-heart"></i>
		</div>
	</div>
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>
<script>
	// Add active class to current menu item
	document.addEventListener('DOMContentLoaded', function() {
		var currentPage = window.location.pathname.split('/').pop();
		var menuItems = document.querySelectorAll('#menu li a');
		
		menuItems.forEach(function(item) {
			if (item.getAttribute('href') === currentPage) {
				item.style.background = 'var(--eksa-gold)';
				item.style.color = 'var(--eksa-navy)';
			}
		});
		
		// Add animation to room cards
		const roomCards = document.querySelectorAll('.room-card');
		roomCards.forEach((card, index) => {
			card.style.opacity = '0';
			card.style.transform = 'translateY(30px)';
			setTimeout(() => {
				card.style.transition = 'all 0.6s ease';
				card.style.opacity = '1';
				card.style.transform = 'translateY(0)';
			}, 100 * index);
		});
	});
</script>
</html>