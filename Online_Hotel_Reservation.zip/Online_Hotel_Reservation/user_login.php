<?php
session_start();
require_once 'admin/connect.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';

// Handle Login
if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if (empty($email) || empty($password)) {
        $error = "Please enter email and password.";
    } else {
        $query = $conn->query("SELECT * FROM `signup` WHERE `Email` = '$email'") or die(mysqli_error($conn));
        
        if ($query->num_rows > 0) {
            $user = $query->fetch_array();
            
            if (password_verify($password, $user['Password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['Username'];
                $_SESSION['user_email'] = $user['Email'];
                $_SESSION['logged_in'] = true;
                
                header("Location: index.php");
                exit();
            } else {
                $error = "Invalid email or password.";
            }
        } else {
            $error = "Account not found. Please register first.";
        }
    }
}

// Handle Registration
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    $errors = [];
    
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters.";
    } elseif (!preg_match('/^[A-Za-z0-9_]+$/', $username)) {
        $errors[] = "Username can only contain letters, numbers, and underscore.";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }
    
    if (empty($errors)) {
        $check_query = $conn->query("SELECT * FROM `signup` WHERE `Email` = '$email'");
        if ($check_query->num_rows > 0) {
            $errors[] = "Email already registered. Please login.";
        }
    }
    
    if (empty($errors)) {
        $check_user = $conn->query("SELECT * FROM `signup` WHERE `Username` = '$username'");
        if ($check_user->num_rows > 0) {
            $errors[] = "Username already taken. Please choose another.";
        }
    }
    
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $insert = $conn->query("INSERT INTO `signup` (`Username`, `Email`, `Password`) VALUES ('$username', '$email', '$hashed_password')");
        
        if ($insert) {
            $success = "Registration successful! Please login.";
        } else {
            $error = "Registration failed. Please try again.";
        }
    } else {
        $error = implode("<br>", $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Eksa - User Login</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
    <style>
        :root {
            --eksa-gold: #C4A484;
            --eksa-gold-light: #E5D3B0;
            --eksa-gold-dark: #A67B5B;
            --eksa-navy: #0A1C2F;
            --eksa-navy-light: #1E3A5F;
            --eksa-navy-dark: #051220;
            --eksa-cream: #FAF7F2;
            --eksa-white: #FFFFFF;
            --eksa-shadow: rgba(10, 28, 47, 0.1);
            --eksa-shadow-dark: rgba(10, 28, 47, 0.2);
            --eksa-gold-glow: rgba(196, 164, 132, 0.3);
            --eksa-danger: #dc3545;
            --eksa-success: #28a745;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--eksa-cream) 0%, var(--eksa-white) 100%);
            color: var(--eksa-navy);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
        }
        
        .login-card {
            background: var(--eksa-white);
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 30px 60px var(--eksa-shadow-dark);
            border: 1px solid rgba(196, 164, 132, 0.2);
            position: relative;
            overflow: hidden;
            animation: slideUp 0.6s ease-out;
        }
        
        .login-card::before {
            content: '✦ ✦ ✦';
            position: absolute;
            bottom: -20px;
            right: -20px;
            font-size: 8rem;
            color: rgba(196, 164, 132, 0.05);
            font-family: serif;
            transform: rotate(-15deg);
        }
        
        .hotel-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .hotel-logo i {
            font-size: 3.5rem;
            color: var(--eksa-gold);
            background: rgba(196, 164, 132, 0.1);
            padding: 20px;
            border-radius: 20px;
            margin-bottom: 15px;
        }
        
        .hotel-logo h1 {
            font-family: 'Playfair Display', serif;
            color: var(--eksa-navy);
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .hotel-logo p {
            color: var(--eksa-navy-light);
            font-size: 0.9rem;
        }
        
        .nav-tabs {
            border: none;
            margin-bottom: 30px;
            display: flex;
            gap: 10px;
            background: rgba(196, 164, 132, 0.05);
            padding: 10px;
            border-radius: 60px;
        }
        
        .nav-tabs .nav-link {
            border: none;
            color: var(--eksa-navy);
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 50px;
            transition: all 0.3s ease;
            flex: 1;
            text-align: center;
        }
        
        .nav-tabs .nav-link i {
            margin-right: 8px;
            color: var(--eksa-gold);
        }
        
        .nav-tabs .nav-link.active {
            background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
            color: var(--eksa-navy-dark);
        }
        
        .nav-tabs .nav-link.active i {
            color: var(--eksa-navy-dark);
        }
        
        .tab-content {
            padding: 20px 0;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--eksa-navy);
        }
        
        .form-group label i {
            color: var(--eksa-gold);
            margin-right: 8px;
        }
        
        .form-group label .required {
            color: var(--eksa-danger);
            margin-left: 3px;
        }
        
        .input-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            color: var(--eksa-gold);
            font-size: 1.1rem;
            z-index: 10;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid rgba(196, 164, 132, 0.2);
            border-radius: 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--eksa-cream);
            font-family: 'Poppins', sans-serif;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--eksa-gold);
            box-shadow: 0 0 0 5px var(--eksa-gold-glow);
            background: var(--eksa-white);
            transform: translateY(-2px);
        }
        
        .form-control.is-invalid {
            border-color: var(--eksa-danger);
            background: rgba(220, 53, 69, 0.05);
        }
        
        .form-control.is-valid {
            border-color: var(--eksa-success);
            background: rgba(40, 167, 69, 0.05);
        }
        
        .validation-icon {
            position: absolute;
            right: 45px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.1rem;
            display: none;
        }
        
        .validation-icon.show {
            display: block;
        }
        
        .validation-icon.valid {
            color: var(--eksa-success);
        }
        
        .validation-icon.invalid {
            color: var(--eksa-danger);
        }
        
        .password-toggle {
            position: absolute;
            right: 15px;
            color: var(--eksa-gold);
            cursor: pointer;
            z-index: 20;
            font-size: 1.1rem;
        }
        
        .invalid-feedback {
            color: var(--eksa-danger);
            font-size: 0.85rem;
            margin-top: 5px;
            display: none;
        }
        
        .invalid-feedback.show {
            display: block;
        }
        
        .valid-feedback {
            color: var(--eksa-success);
            font-size: 0.85rem;
            margin-top: 5px;
            display: none;
        }
        
        .valid-feedback.show {
            display: block;
        }
        
        .btn-login {
            background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
            color: var(--eksa-navy-dark);
            border: none;
            padding: 16px 30px;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 700;
            letter-spacing: 2px;
            cursor: pointer;
            transition: all 0.4s ease;
            width: 100%;
            position: relative;
            overflow: hidden;
            z-index: 1;
            margin-top: 20px;
        }
        
        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--eksa-navy), var(--eksa-navy-dark));
            transition: left 0.4s ease;
            z-index: -1;
        }
        
        .btn-login:hover::before {
            left: 0;
        }
        
        .btn-login:hover {
            color: var(--eksa-gold);
            border-color: var(--eksa-gold);
            transform: translateY(-3px);
            box-shadow: 0 15px 30px var(--eksa-gold-glow);
        }
        
        .btn-login i {
            margin-right: 10px;
        }
        
        .btn-login:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .alert {
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 25px;
            border: none;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.95rem;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border-left: 5px solid #dc3545;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
            border-left: 5px solid #28a745;
        }
        
        .alert i {
            font-size: 1.2rem;
        }
        
        .password-requirements {
            margin-top: 10px;
            padding: 15px;
            background: rgba(196, 164, 132, 0.05);
            border-radius: 12px;
            font-size: 0.85rem;
            display: none;
        }
        
        .password-requirements.show {
            display: block;
        }
        
        .requirement-item {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 5px;
            color: var(--eksa-navy-light);
        }
        
        .requirement-item i {
            font-size: 0.8rem;
        }
        
        .requirement-item.valid {
            color: var(--eksa-success);
        }
        
        .requirement-item.invalid {
            color: var(--eksa-danger);
        }
        
        .forgot-password {
            text-align: right;
            margin-top: 10px;
        }
        
        .forgot-password a {
            color: var(--eksa-gold-dark);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }
        
        .forgot-password a:hover {
            color: var(--eksa-navy);
            text-decoration: underline;
        }
        
        .back-home {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(196, 164, 132, 0.2);
        }
        
        .back-home a {
            color: var(--eksa-navy-light);
            text-decoration: none;
            font-size: 0.95rem;
            transition: color 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .back-home a:hover {
            color: var(--eksa-gold);
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 480px) {
            .login-card {
                padding: 30px 20px;
            }
            
            .nav-tabs .nav-link {
                padding: 10px 15px;
                font-size: 0.9rem;
            }
            
            .nav-tabs .nav-link i {
                margin-right: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            
            <!-- Hotel Logo -->
            <div class="hotel-logo">
                <i class="fas fa-h-square"></i>
                <h1>Hotel Eksa</h1>
                <p>Luxury Beyond Ordinary</p>
            </div>
            
            <!-- Error/Success Messages -->
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <!-- Login/Register Tabs -->
            <ul class="nav nav-tabs" id="authTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login" type="button" role="tab">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="register-tab" data-bs-toggle="tab" data-bs-target="#register" type="button" role="tab">
                        <i class="fas fa-user-plus"></i> Register
                    </button>
                </li>
            </ul>
            
            <!-- Tab Content -->
            <div class="tab-content" id="authTabContent">
                
                <!-- Login Form -->
                <div class="tab-pane fade show active" id="login" role="tabpanel">
                    <form method="POST" action="" id="loginForm" novalidate>
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email Address <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-envelope input-icon"></i>
                                <input type="email" class="form-control" name="email" id="login-email" 
                                       placeholder="Enter your email" required>
                                <span class="validation-icon" id="login-email-icon"></span>
                            </div>
                            <div class="invalid-feedback" id="login-email-error"></div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Password <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock input-icon"></i>
                                <input type="password" class="form-control" name="password" id="login-password" 
                                       placeholder="Enter your password" required minlength="6">
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('login-password', this)"></i>
                                <span class="validation-icon" id="login-password-icon"></span>
                            </div>
                            <div class="invalid-feedback" id="login-password-error"></div>
                        </div>
                        
                        <div class="forgot-password">
                            <a href="forgot_password.php"><i class="fas fa-question-circle"></i> Forgot Password?</a>
                        </div>
                        
                        <button type="submit" name="login" class="btn-login" id="loginBtn">
                            <i class="fas fa-sign-in-alt"></i> LOGIN TO ACCOUNT
                        </button>
                    </form>
                </div>
                
                <!-- Register Form -->
                <div class="tab-pane fade" id="register" role="tabpanel">
                    <form method="POST" action="" id="registerForm" novalidate>
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Username <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-user input-icon"></i>
                                <input type="text" class="form-control" name="username" id="username" 
                                       placeholder="Choose a username" required 
                                       minlength="3" maxlength="20"
                                       pattern="[A-Za-z0-9_]+"
                                       title="Username can only contain letters, numbers, and underscore">
                                <span class="validation-icon" id="username-icon"></span>
                            </div>
                            <div class="invalid-feedback" id="username-error"></div>
                            <small style="color: var(--eksa-navy-light);">3-20 characters, letters, numbers, underscore</small>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email Address <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-envelope input-icon"></i>
                                <input type="email" class="form-control" name="email" id="email" 
                                       placeholder="Enter your email" required>
                                <span class="validation-icon" id="email-icon"></span>
                            </div>
                            <div class="invalid-feedback" id="email-error"></div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Password <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock input-icon"></i>
                                <input type="password" class="form-control" name="password" id="register-password" 
                                       placeholder="Create a password" required minlength="6">
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('register-password', this)"></i>
                                <span class="validation-icon" id="register-password-icon"></span>
                            </div>
                            <div class="invalid-feedback" id="register-password-error"></div>
                            
                            <!-- Password Requirements -->
                            <div class="password-requirements" id="password-requirements">
                                <div class="requirement-item" id="req-length">
                                    <i class="fas fa-circle"></i> At least 6 characters
                                </div>
                                <div class="requirement-item" id="req-lowercase">
                                    <i class="fas fa-circle"></i> At least one lowercase letter
                                </div>
                                <div class="requirement-item" id="req-uppercase">
                                    <i class="fas fa-circle"></i> At least one uppercase letter
                                </div>
                                <div class="requirement-item" id="req-number">
                                    <i class="fas fa-circle"></i> At least one number
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Confirm Password <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock input-icon"></i>
                                <input type="password" class="form-control" name="confirm_password" id="confirm-password" 
                                       placeholder="Confirm your password" required>
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('confirm-password', this)"></i>
                                <span class="validation-icon" id="confirm-password-icon"></span>
                            </div>
                            <div class="invalid-feedback" id="confirm-password-error"></div>
                        </div>
                        
                        <!-- Terms and Conditions -->
                        <div style="margin: 25px 0; padding: 20px; background: rgba(196,164,132,0.03); border-radius: 15px; border: 1px dashed var(--eksa-gold);">
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <input type="checkbox" id="terms" required style="width: 20px; height: 20px; accent-color: var(--eksa-gold);">
                                <label for="terms" style="color: var(--eksa-navy); font-weight: 500;">
                                    I agree to the <a href="#" style="color: var(--eksa-gold);">terms and conditions</a> and <a href="#" style="color: var(--eksa-gold);">privacy policy</a>.
                                    <span class="required">*</span>
                                </label>
                            </div>
                            <div class="invalid-feedback" id="terms-error" style="margin-left: 35px;"></div>
                        </div>
                        
                        <button type="submit" name="register" class="btn-login" id="registerBtn">
                            <i class="fas fa-user-plus"></i> CREATE ACCOUNT
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Back to Home -->
            <div class="back-home">
                <a href="index.php">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
            </div>
            
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // ==================== TOGGLE PASSWORD VISIBILITY ====================
        function togglePassword(inputId, element) {
            const input = document.getElementById(inputId);
            const icon = element;
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        // ==================== FORM VALIDATION ====================
        document.addEventListener('DOMContentLoaded', function() {
            
            // ========== LOGIN FORM VALIDATION ==========
            const loginForm = document.getElementById('loginForm');
            
            if (loginForm) {
                const loginFields = [
                    { id: 'login-email', validator: 'email', errorMsg: 'Please enter a valid email address' },
                    { id: 'login-password', validator: 'password', errorMsg: 'Password must be at least 6 characters' }
                ];
                
                loginFields.forEach(field => {
                    const input = document.getElementById(field.id);
                    if (!input) return;
                    
                    input.addEventListener('input', function() {
                        validateLoginField(field);
                    });
                    
                    input.addEventListener('blur', function() {
                        validateLoginField(field);
                    });
                });
                
                function validateLoginField(field) {
                    const input = document.getElementById(field.id);
                    if (!input) return true;
                    
                    const value = input.value;
                    let isValid = false;
                    
                    if (field.validator === 'email') {
                        isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
                    } else if (field.validator === 'password') {
                        isValid = value.length >= 6;
                    }
                    
                    // Update input styling
                    if (isValid) {
                        input.classList.remove('is-invalid');
                        input.classList.add('is-valid');
                    } else {
                        input.classList.remove('is-valid');
                        input.classList.add('is-invalid');
                    }
                    
                    // Update icon
                    const icon = document.getElementById(field.id + '-icon');
                    if (icon) {
                        icon.className = 'validation-icon show ' + (isValid ? 'valid' : 'invalid');
                        icon.innerHTML = isValid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
                    }
                    
                    // Update error message
                    const error = document.getElementById(field.id + '-error');
                    if (error) {
                        error.textContent = isValid ? '' : field.errorMsg;
                        error.classList.toggle('show', !isValid && value.length > 0);
                    }
                    
                    return isValid;
                }
            }
            
            // ========== REGISTER FORM VALIDATION ==========
            const registerForm = document.getElementById('registerForm');
            
            if (registerForm) {
                // Username validation
                const usernameInput = document.getElementById('username');
                if (usernameInput) {
                    usernameInput.addEventListener('input', function() {
                        const value = this.value;
                        const isValid = /^[A-Za-z0-9_]{3,20}$/.test(value);
                        
                        if (isValid) {
                            this.classList.remove('is-invalid');
                            this.classList.add('is-valid');
                        } else {
                            this.classList.remove('is-valid');
                            this.classList.add('is-invalid');
                        }
                        
                        const icon = document.getElementById('username-icon');
                        if (icon) {
                            icon.className = 'validation-icon show ' + (isValid ? 'valid' : 'invalid');
                            icon.innerHTML = isValid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
                        }
                        
                        const error = document.getElementById('username-error');
                        if (error) {
                            if (!isValid && value.length > 0) {
                                error.textContent = 'Username must be 3-20 characters (letters, numbers, underscore only)';
                                error.classList.add('show');
                            } else {
                                error.classList.remove('show');
                            }
                        }
                    });
                }
                
                // Email validation
                const emailInput = document.getElementById('email');
                if (emailInput) {
                    emailInput.addEventListener('input', function() {
                        const value = this.value;
                        const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
                        
                        if (isValid) {
                            this.classList.remove('is-invalid');
                            this.classList.add('is-valid');
                        } else {
                            this.classList.remove('is-valid');
                            this.classList.add('is-invalid');
                        }
                        
                        const icon = document.getElementById('email-icon');
                        if (icon) {
                            icon.className = 'validation-icon show ' + (isValid ? 'valid' : 'invalid');
                            icon.innerHTML = isValid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
                        }
                        
                        const error = document.getElementById('email-error');
                        if (error) {
                            error.textContent = isValid ? '' : 'Please enter a valid email address';
                            error.classList.toggle('show', !isValid && value.length > 0);
                        }
                    });
                }
                
                // Password validation with requirements
                const passwordInput = document.getElementById('register-password');
                const passwordRequirements = document.getElementById('password-requirements');
                
                if (passwordInput) {
                    passwordInput.addEventListener('focus', function() {
                        passwordRequirements.classList.add('show');
                    });
                    
                    passwordInput.addEventListener('blur', function() {
                        if (!this.value.trim()) {
                            passwordRequirements.classList.remove('show');
                        }
                    });
                    
                    passwordInput.addEventListener('input', function() {
                        const value = this.value;
                        
                        // Check length
                        const lengthReq = document.getElementById('req-length');
                        if (value.length >= 6) {
                            lengthReq.innerHTML = '<i class="fas fa-check-circle"></i> At least 6 characters';
                            lengthReq.classList.add('valid');
                            lengthReq.classList.remove('invalid');
                        } else {
                            lengthReq.innerHTML = '<i class="fas fa-circle"></i> At least 6 characters';
                            lengthReq.classList.remove('valid');
                            lengthReq.classList.add('invalid');
                        }
                        
                        // Check lowercase
                        const lowerReq = document.getElementById('req-lowercase');
                        if (/[a-z]/.test(value)) {
                            lowerReq.innerHTML = '<i class="fas fa-check-circle"></i> At least one lowercase letter';
                            lowerReq.classList.add('valid');
                            lowerReq.classList.remove('invalid');
                        } else {
                            lowerReq.innerHTML = '<i class="fas fa-circle"></i> At least one lowercase letter';
                            lowerReq.classList.remove('valid');
                            lowerReq.classList.add('invalid');
                        }
                        
                        // Check uppercase
                        const upperReq = document.getElementById('req-uppercase');
                        if (/[A-Z]/.test(value)) {
                            upperReq.innerHTML = '<i class="fas fa-check-circle"></i> At least one uppercase letter';
                            upperReq.classList.add('valid');
                            upperReq.classList.remove('invalid');
                        } else {
                            upperReq.innerHTML = '<i class="fas fa-circle"></i> At least one uppercase letter';
                            upperReq.classList.remove('valid');
                            upperReq.classList.add('invalid');
                        }
                        
                        // Check number
                        const numReq = document.getElementById('req-number');
                        if (/[0-9]/.test(value)) {
                            numReq.innerHTML = '<i class="fas fa-check-circle"></i> At least one number';
                            numReq.classList.add('valid');
                            numReq.classList.remove('invalid');
                        } else {
                            numReq.innerHTML = '<i class="fas fa-circle"></i> At least one number';
                            numReq.classList.remove('valid');
                            numReq.classList.add('invalid');
                        }
                        
                        // Validate field
                        const isValid = value.length >= 6;
                        
                        if (isValid) {
                            this.classList.remove('is-invalid');
                            this.classList.add('is-valid');
                        } else {
                            this.classList.remove('is-valid');
                            this.classList.add('is-invalid');
                        }
                        
                        const icon = document.getElementById('register-password-icon');
                        if (icon) {
                            icon.className = 'validation-icon show ' + (isValid ? 'valid' : 'invalid');
                            icon.innerHTML = isValid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
                        }
                        
                        const error = document.getElementById('register-password-error');
                        if (error) {
                            error.textContent = isValid ? '' : 'Password must be at least 6 characters';
                            error.classList.toggle('show', !isValid && value.length > 0);
                        }
                        
                        // Also validate confirm password if it has value
                        const confirmInput = document.getElementById('confirm-password');
                        if (confirmInput && confirmInput.value) {
                            validateConfirmPassword();
                        }
                    });
                }
                
                // Confirm password validation
                const confirmInput = document.getElementById('confirm-password');
                
                function validateConfirmPassword() {
                    const password = passwordInput ? passwordInput.value : '';
                    const confirm = confirmInput ? confirmInput.value : '';
                    const isValid = password === confirm && password.length > 0;
                    
                    if (confirmInput) {
                        if (isValid) {
                            confirmInput.classList.remove('is-invalid');
                            confirmInput.classList.add('is-valid');
                        } else {
                            confirmInput.classList.remove('is-valid');
                            confirmInput.classList.add('is-invalid');
                        }
                        
                        const icon = document.getElementById('confirm-password-icon');
                        if (icon) {
                            icon.className = 'validation-icon show ' + (isValid ? 'valid' : 'invalid');
                            icon.innerHTML = isValid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
                        }
                        
                        const error = document.getElementById('confirm-password-error');
                        if (error) {
                            if (!isValid && confirm.length > 0) {
                                error.textContent = 'Passwords do not match';
                                error.classList.add('show');
                            } else {
                                error.classList.remove('show');
                            }
                        }
                    }
                    
                    return isValid;
                }
                
                if (confirmInput) {
                    confirmInput.addEventListener('input', validateConfirmPassword);
                    confirmInput.addEventListener('blur', validateConfirmPassword);
                }
                
                // Form submission validation
                registerForm.addEventListener('submit', function(e) {
                    let isValid = true;
                    
                    // Validate username
                    const username = document.getElementById('username');
                    if (!username.value || !/^[A-Za-z0-9_]{3,20}$/.test(username.value)) {
                        isValid = false;
                        username.classList.add('is-invalid');
                    }
                    
                    // Validate email
                    const email = document.getElementById('email');
                    if (!email.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
                        isValid = false;
                        email.classList.add('is-invalid');
                    }
                    
                    // Validate password
                    const password = document.getElementById('register-password');
                    if (!password.value || password.value.length < 6) {
                        isValid = false;
                        password.classList.add('is-invalid');
                    }
                    
                    // Validate confirm password
                    const confirm = document.getElementById('confirm-password');
                    if (!confirm.value || confirm.value !== password.value) {
                        isValid = false;
                        confirm.classList.add('is-invalid');
                    }
                    
                    // Validate terms
                    const terms = document.getElementById('terms');
                    const termsError = document.getElementById('terms-error');
                    
                    if (!terms.checked) {
                        termsError.textContent = 'You must agree to the terms and conditions';
                        termsError.classList.add('show');
                        isValid = false;
                    } else {
                        termsError.classList.remove('show');
                    }
                    
                    if (!isValid) {
                        e.preventDefault();
                        
                        // Scroll to first error
                        const firstError = document.querySelector('.is-invalid');
                        if (firstError) {
                            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }
                        
                        // Show error message
                        swal({
                            title: 'Validation Error',
                            text: 'Please fill in all fields correctly and agree to the terms.',
                            icon: 'error',
                            button: 'OK'
                        });
                        
                        return false;
                    }
                    
                    // Show confirmation before submit
                    e.preventDefault();
                    swal({
                        title: 'Create Account?',
                        text: 'Please verify your information before submitting.',
                        icon: 'info',
                        buttons: ['Cancel', 'Confirm'],
                        dangerMode: false,
                    }).then((willConfirm) => {
                        if (willConfirm) {
                            registerForm.submit();
                        }
                    });
                });
            }
            
            // Login form submission validation
            if (loginForm) {
                loginForm.addEventListener('submit', function(e) {
                    let isValid = true;
                    
                    const email = document.getElementById('login-email');
                    const password = document.getElementById('login-password');
                    
                    if (!email.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
                        isValid = false;
                        email.classList.add('is-invalid');
                    }
                    
                    if (!password.value || password.value.length < 6) {
                        isValid = false;
                        password.classList.add('is-invalid');
                    }
                    
                    if (!isValid) {
                        e.preventDefault();
                        
                        swal({
                            title: 'Validation Error',
                            text: 'Please enter a valid email and password.',
                            icon: 'error',
                            button: 'OK'
                        });
                        
                        return false;
                    }
                });
            }
        });
    </script>
</body>
</html>