<?php
session_start();
require_once 'admin/connect.php';

// Get reservation ID
$reservation_id = isset($_GET['reservation_id']) ? (int)$_GET['reservation_id'] : 0;

if ($reservation_id == 0) {
    header("Location: index.php");
    exit();
}

// Fetch from reservations table
$query = $conn->query("SELECT * FROM `reservations` WHERE `id` = '$reservation_id'");

if (!$query || $query->num_rows == 0) {
    // If not found in reservations, try to get from transaction
    $trans_query = $conn->query("SELECT t.*, g.firstname, g.middlename, g.lastname, g.address, g.contactno, r.room_type, r.price, r.photo 
                                FROM `transaction` t 
                                JOIN `guest` g ON t.guest_id = g.guest_id 
                                JOIN `room` r ON t.room_id = r.room_id 
                                WHERE t.transaction_id = '$reservation_id'");
    
    if ($trans_query && $trans_query->num_rows > 0) {
        $trans_data = $trans_query->fetch_array();
        
        // Generate invoice data
        $invoice_number = 'INV-' . date('Ymd') . '-' . str_pad($reservation_id, 4, '0', STR_PAD_LEFT);
        $reservation_code = 'EKS' . str_pad($reservation_id, 6, '0', STR_PAD_LEFT);
        $fullname = $trans_data['firstname'] . ' ' . $trans_data['middlename'] . ' ' . $trans_data['lastname'];
        $room_price = floatval($trans_data['price']);
        $days = $trans_data['days'] ?: 1;
        $subtotal = $room_price * $days;
        $service_charge = $subtotal * 0.10;
        $tax = $subtotal * 0.12;
        $total = $subtotal + $service_charge + $tax;
        $checkin_date = $trans_data['checkin'];
        $room_photo = $trans_data['photo'];
        
        // Create array similar to reservations table
        $reservation = [
            'id' => $reservation_id,
            'invoice_number' => $invoice_number,
            'reservation_code' => $reservation_code,
            'fullname' => $fullname,
            'firstname' => $trans_data['firstname'],
            'address' => $trans_data['address'],
            'contactno' => $trans_data['contactno'],
            'room_type' => $trans_data['room_type'],
            'room_price' => $room_price,
            'checkin_date' => $checkin_date,
            'nights' => $days,
            'subtotal' => $subtotal,
            'service_charge' => $service_charge,
            'tax' => $tax,
            'total' => $total,
            'status' => $trans_data['status'],
            'booking_date' => date('Y-m-d H:i:s'),
            'room_photo' => $room_photo
        ];
        
        $has_data = true;
    } else {
        $has_data = false;
    }
} else {
    $reservation = $query->fetch_array();
    $has_data = true;
    
    // Get room photo
    $room_photo_query = $conn->query("SELECT photo FROM `room` WHERE `room_id` = '{$reservation['room_id']}'");
    if ($room_photo_query && $room_photo_query->num_rows > 0) {
        $photo_row = $room_photo_query->fetch_array();
        $reservation['room_photo'] = $photo_row['photo'];
    } else {
        $reservation['room_photo'] = '1.jpg';
    }
}

if (!$has_data) {
    header("Location: index.php");
    exit();
}

// Extract variables for easy use
$invoice_number = $reservation['invoice_number'];
$reservation_code = $reservation['reservation_code'];
$fullname = $reservation['fullname'];
$firstname = $reservation['firstname'];
$address = $reservation['address'];
$contactno = $reservation['contactno'];
$room_type = $reservation['room_type'];
$room_price = floatval($reservation['room_price']);
$checkin_date = $reservation['checkin_date'];
$nights = $reservation['nights'];
$subtotal = floatval($reservation['subtotal']);
$service_charge = floatval($reservation['service_charge']);
$tax = floatval($reservation['tax']);
$total = floatval($reservation['total']);
$status = $reservation['status'];
$booking_date = $reservation['booking_date'];
$room_photo = isset($reservation['room_photo']) ? $reservation['room_photo'] : '1.jpg';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Eksa - Invoice</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    
    <style>
        :root {
            --eksa-gold: #C4A484;
            --eksa-gold-dark: #A67B5B;
            --eksa-navy: #0A1C2F;
            --eksa-cream: #FAF7F2;
            --eksa-white: #FFFFFF;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--eksa-cream), var(--eksa-white));
            color: var(--eksa-navy);
            padding: 40px 0 100px;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--eksa-navy), #051220) !important;
            border-bottom: 3px solid var(--eksa-gold) !important;
            margin-bottom: 40px !important;
        }
        
        .navbar-brand {
            color: var(--eksa-gold) !important;
            font-size: 1.8rem !important;
            font-family: 'Playfair Display', serif;
        }
        
        .invoice-card {
            background: var(--eksa-white);
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 30px 60px rgba(10,28,47,0.1);
            border: 1px solid rgba(196,164,132,0.2);
            max-width: 900px;
            margin: 0 auto;
        }
        
        .success-badge {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 10px 25px;
            border-radius: 50px;
            display: inline-block;
        }
        
        .guest-info {
            background: linear-gradient(135deg, var(--eksa-navy), #051220);
            color: white;
            padding: 25px;
            border-radius: 15px;
            margin: 30px 0;
        }
        
        .guest-info h4 { color: var(--eksa-gold); }
        .guest-item i { color: var(--eksa-gold); width: 20px; }
        
        .reservation-code-box {
            background: rgba(196,164,132,0.1);
            border: 2px dashed var(--eksa-gold);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            margin: 30px 0;
        }
        
        .reservation-code-box strong {
            font-size: 1.8rem;
            letter-spacing: 3px;
            font-family: monospace;
        }
        
        .room-card {
            display: flex;
            gap: 20px;
            padding: 20px;
            background: rgba(196,164,132,0.05);
            border-radius: 15px;
            margin: 30px 0;
        }
        
        .room-image {
            width: 120px;
            height: 120px;
            border-radius: 10px;
            overflow: hidden;
            border: 3px solid var(--eksa-gold);
        }
        
        .room-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .invoice-table {
            width: 100%;
            margin: 30px 0;
            border-collapse: collapse;
        }
        
        .invoice-table th {
            background: var(--eksa-cream);
            padding: 15px;
            border-bottom: 2px solid var(--eksa-gold);
        }
        
        .invoice-table td {
            padding: 15px;
            border-bottom: 1px solid rgba(196,164,132,0.2);
        }
        
        .total-row td {
            font-weight: 700;
            color: var(--eksa-gold-dark);
            font-size: 1.2rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 40px;
        }
        
        .btn-download, .btn-back {
            padding: 14px 35px;
            border-radius: 50px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.4s ease;
        }
        
        .btn-download {
            background: linear-gradient(135deg, var(--eksa-gold), var(--eksa-gold-dark));
            color: var(--eksa-navy-dark);
            border: 2px solid var(--eksa-white);
        }
        
        .btn-back {
            background: transparent;
            color: var(--eksa-navy);
            border: 2px solid var(--eksa-gold);
        }
        
        @media (max-width: 768px) {
            .room-card { flex-direction: column; align-items: center; text-align: center; }
            .room-image { width: 150px; height: 150px; }
            .action-buttons { flex-direction: column; }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-h-square"></i> Hotel Eksa
            </a>
        </div>
    </nav>
    
    <div class="container">
        <div class="invoice-card" id="invoiceContent">
            <div style="text-align: center;">
                <span class="success-badge">
                    <i class="fas fa-check-circle"></i> <?php echo $status; ?>
                </span>
            </div>
            
            <h2 style="text-align: center; font-family: 'Playfair Display'; margin: 30px 0;">
                ≼ Booking Invoice ≽
            </h2>
            
            <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
                <div>
                    <h5 style="color: var(--eksa-gold-dark);">HOTEL EKSA</h5>
                    <p style="margin: 0;">Khairahani-06, Parsa, Chitwan, Nepal</p>
                    <p>+977 9800000000 | reservations@hoteleksa.com</p>
                </div>
                <div style="text-align: right;">
                    <p><strong>Invoice:</strong> <?php echo $invoice_number; ?></p>
                    <p><strong>Date:</strong> <?php echo date('F d, Y', strtotime($booking_date)); ?></p>
                </div>
            </div>
            
            <div class="reservation-code-box">
                <span><i class="fas fa-ticket-alt"></i> RESERVATION CODE</span>
                <strong><?php echo $reservation_code; ?></strong>
            </div>
            
            <div class="guest-info">
                <h4><i class="fas fa-user-circle"></i> GUEST INFORMATION</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
                    <div class="guest-item"><i class="fas fa-user"></i> <?php echo $fullname; ?></div>
                    <div class="guest-item"><i class="fas fa-map-marker-alt"></i> <?php echo $address; ?></div>
                    <div class="guest-item"><i class="fas fa-phone-alt"></i> <?php echo $contactno; ?></div>
                    <div class="guest-item"><i class="fas fa-calendar-check"></i> <?php echo date('F d, Y', strtotime($checkin_date)); ?></div>
                </div>
            </div>
            
            <div class="room-card">
                <div class="room-image">
                    <img src="photo/<?php echo $room_photo; ?>" alt="<?php echo $room_type; ?>">
                </div>
                <div style="flex: 1;">
                    <h4 style="color: var(--eksa-navy);"><?php echo $room_type; ?></h4>
                    <p style="color: var(--eksa-gold-dark); font-size: 1.5rem; font-weight: 700;">
                        Rs. <?php echo number_format($room_price, 2); ?> <span style="font-size: 0.9rem; color: var(--eksa-navy-light);">/ night</span>
                    </p>
                </div>
            </div>
            
            <table class="invoice-table">
                <thead>
                    <tr><th>Description</th><th>Rate</th><th>Nights</th><th>Amount</th></tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $room_type; ?> - Standard Rate</td>
                        <td>Rs. <?php echo number_format($room_price, 2); ?></td>
                        <td><?php echo $nights; ?></td>
                        <td>Rs. <?php echo number_format($subtotal, 2); ?></td>
                    </tr>
                    <tr>
                        <td>Service Charge (10%)</td>
                        <td>-</td>
                        <td>-</td>
                        <td>Rs. <?php echo number_format($service_charge, 2); ?></td>
                    </tr>
                    <tr>
                        <td>Tax (12%)</td>
                        <td>-</td>
                        <td>-</td>
                        <td>Rs. <?php echo number_format($tax, 2); ?></td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="3" style="text-align: right;">TOTAL AMOUNT</td>
                        <td>Rs. <?php echo number_format($total, 2); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <div style="text-align: center; margin-top: 30px; padding-top: 30px; border-top: 1px dashed var(--eksa-gold);">
                <p><i class="fas fa-check-circle" style="color: #28a745;"></i> Check-in: 3:00 PM | Check-out: 12:00 PM</p>
                <p><i class="fas fa-credit-card"></i> Payment will be collected at the hotel.</p>
                <div style="font-family: 'Playfair Display'; color: var(--eksa-gold-dark); margin-top: 20px;">
                    Hotel Eksa Management
                </div>
            </div>
        </div>
        
        <div class="action-buttons">
            <button class="btn-download" id="downloadInvoice">
                <i class="fas fa-download"></i> Download PDF
            </button>
            <a href="index.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
        </div>
        
        <div style="text-align: center; margin-top: 30px; padding: 20px; background: rgba(196,164,132,0.05); border-radius: 15px;">
            <h4 style="color: var(--eksa-navy);">
                <i class="fas fa-heart" style="color: var(--eksa-gold);"></i> 
                THANK YOU, <?php echo strtoupper($firstname); ?>!
            </h4>
            <p>We look forward to welcoming you on <?php echo date('F d, Y', strtotime($checkin_date)); ?>.</p>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('downloadInvoice').addEventListener('click', function() {
            var element = document.getElementById('invoiceContent');
            html2pdf().set({
                margin: 0.5,
                filename: 'Hotel_Eksa_Invoice_<?php echo $invoice_number; ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            }).from(element).save();
        });
    </script>
</body>
</html>